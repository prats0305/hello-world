﻿using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Exceptions
{
    public sealed class DocumentParserExceptionHandler
    {
        /// <summary>
        ///     Private Constructor to ensure that the class cannot be instantiated
        /// </summary>
        private DocumentParserExceptionHandler()
        {
        }

        /// <summary>
        /// </summary>
        /// <param name="message"></param>
        /// <param name="isLogged"></param>
        /// <returns></returns>
        public static DocumentParserExceptionFaultContract HandleException(string message, string userId = null, bool isLogged = true)
        {
            return CreateExceptionFaultContract(message, ErrorCodeEnum.GenericError, userId, isLogged);
        }

        public static DocumentParserExceptionFaultContract CreateExceptionFaultContract(string message, ErrorCodeEnum errorCode, string userId, bool isLogged)
        {
            return CreateExceptionFaultContract(message, errorCode.GetHashCode(), userId, isLogged);
        }

        public static string GetErrorMessage(Exception ex)
        {
            string message = String.Empty;
            string stackStrace = String.Empty;
            if (ex.InnerException != null && ex.InnerException.InnerException != null)
            {
                message = ex.InnerException.InnerException.Message;
            }
            else if (ex.InnerException != null)
            {
                if (!string.IsNullOrEmpty(ex.Message) && !string.IsNullOrEmpty(ex.InnerException.Message) && ex.Message.Length > ex.InnerException.Message.Length)
                {
                    message = ex.Message;
                }
                else
                {
                    message = ex.InnerException.Message;
                }
            }
            else
            {
                message = ex.Message;
            }
            if (ex.InnerException != null)
            {
                stackStrace = String.Format("{0}\n{1}", ex.InnerException.StackTrace, ex.StackTrace);
            }
            else
            {
                stackStrace = ex.StackTrace;
            }

            return String.Format("{0} \n\n {1}", message, stackStrace);
        }

        /// <summary>
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="userId"></param>
        /// <param name="isLogged"></param>
        /// <returns></returns>
        public static DocumentParserExceptionFaultContract HandleException(Exception ex, string userId = null, bool isLogged = true)
        {
            return CreateExceptionFaultContract(ex.GetErrorMessage(), ErrorCodeEnum.GenericError, userId, isLogged);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="actionToExecute"></param>
        /// <returns></returns>
        public static Output ExecuteWithLogging<Output>(Func<Output> actionToExecute)
        {
            LoggingHelper.LogDebug(MessageHelper.GetMethodEnteredMessage(MethodBase.GetCurrentMethod().Name));
            try
            {
                var t = actionToExecute();
                return t;
            }
            catch (DocumentParserException ex)
            {
                throw new FaultException<DocumentParserExceptionFaultContract>(ex.HandleException());
            }
            catch (Exception ex)
            {
                throw new FaultException<DocumentParserExceptionFaultContract>(HandleException(ex));
            }
            finally
            {
                LoggingHelper.LogDebug(MessageHelper.GetMethodExitMessage(MethodBase.GetCurrentMethod().Name));
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="userId"></param>
        /// <param name="isLogged"></param>
        /// <returns></returns>
        public static DocumentParserExceptionFaultContract HandleException(DocumentParserException ex, string userId = null, bool isLogged = true)
        {
            return CreateExceptionFaultContract(ex.GetErrorMessage(), ex.ErrorCode, userId, isLogged, ex.ErrorDetails);
        }

        public static DocumentParserExceptionFaultContract CreateExceptionFaultContract(string message, int errorCode, string userId = null, bool isLogged = true, IEnumerable<string> errorDetails = null)
        {
            var serviceExceptionFaultContract = new DocumentParserExceptionFaultContract();
            serviceExceptionFaultContract.ErrorCode = errorCode.GetHashCode();
            serviceExceptionFaultContract.ErrorDetails = errorDetails == null ? new List<string>() : errorDetails.ToList();
            serviceExceptionFaultContract.UniqueId = Guid.NewGuid();

            //Log error if isLogged is true.
            if (isLogged)
                LoggingHelper.LogError(message, userId, serviceExceptionFaultContract.UniqueId);

            return serviceExceptionFaultContract;
        }
    }
}
