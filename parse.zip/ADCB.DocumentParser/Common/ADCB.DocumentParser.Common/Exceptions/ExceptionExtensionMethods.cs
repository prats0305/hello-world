﻿using ADCB.DocumentParser.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Exceptions
{
    public static class ExceptionExtensionMethods
    {
        public static string GetErrorMessage(this Exception ex)
        {
            StringBuilder messageBuilder = new StringBuilder();
            if (ex != null)
            {
                BuildExceptionMessage(ex, messageBuilder);
                messageBuilder.AppendLine();
                messageBuilder.AppendLine(ex.StackTrace);
            }
            return messageBuilder.ToString();
        }

        private static void BuildExceptionMessage(Exception ex, StringBuilder messageBuilder)
        {
            do
            {
                DocumentParserException interactException = ex as DocumentParserException;
                if (interactException != null)
                {
                    if (interactException.ErrorCode > 0)
                    {
                        messageBuilder.AppendLine();
                        string errorCode = interactException.ErrorCode.ToString();

                        if (Enum.IsDefined(typeof(ErrorCodeEnum), interactException.ErrorCode))
                        {
                            errorCode = Enum.GetName(typeof(ErrorCodeEnum), interactException.ErrorCode);
                        }
                        messageBuilder.AppendFormat("DocumentParserException Exception Error Code {0}", errorCode);
                    }

                    if (!string.IsNullOrEmpty(ex.Message))
                    {
                        messageBuilder.AppendLine(ex.Message);
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(ex.Message))
                    {
                        messageBuilder.AppendLine(ex.Message);
                    }
                }
                ex = ex.InnerException;
            }
            while (ex != null);
        }
    }
}
