﻿using ADCB.DocumentParser.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Exceptions
{
    [Serializable]
    public class DocumentParserException : Exception
    {
        public int ErrorCode { get; set; }
        public IEnumerable<string> ErrorDetails { get; set; }

        public DocumentParserException(int errorCode)
        {
            ErrorCode = errorCode;
        }

        public DocumentParserException(ErrorCodeEnum errorCode)
            : this(errorCode.GetHashCode())
        {

        }

        public DocumentParserException(ErrorCodeEnum errorCode, IEnumerable<string> errorDetails)
            : this(errorCode.GetHashCode())
        {
            ErrorDetails = errorDetails;
        }

        public DocumentParserException(int errorCode, Exception ex)
            : base(errorCode.ToString(), ex)
        {
            ErrorCode = errorCode;
        }

        public DocumentParserException(ErrorCodeEnum errorCode, Exception ex)
            : base(errorCode.ToString(), ex)
        {
            ErrorCode = errorCode.GetHashCode();
        }

        protected DocumentParserException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public DocumentParserExceptionFaultContract HandleException(string userId = null, bool isLogged = true)
        {
            return DocumentParserExceptionHandler.CreateExceptionFaultContract(this.GetErrorMessage(), ErrorCode, userId, isLogged, ErrorDetails);
        }



        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
                throw new ArgumentNullException("info");

            info.AddValue("ErrorCode", ErrorCode);
            base.GetObjectData(info, context);
        }
    }
}
