﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Exceptions
{
    [DataContract]
    public class DocumentParserExceptionFaultContract
    {
        [DataMember]
        public int ErrorCode { get; set; }

        [DataMember]
        public List<string> ErrorDetails { get; set; }

        [DataMember]
        public Guid UniqueId { get; set; }
    }
}
