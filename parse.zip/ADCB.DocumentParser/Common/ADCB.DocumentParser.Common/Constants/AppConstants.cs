﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Constants
{
    public static class AppConstants
    {
        public const string MRZParserDBConString = "MRZParserDBConString";        
        public const string FileNameFormat = "FileNameFormat";
        public const string TesseractFolder = "TesseractFolder";
        public const string TesseractChars = "TesseractChars";
        public const string TesseractLanguage = "TesseractLanguage";
        public const string TesseractBestChoices = "TesseractBestChoices";
        public static string KEY = "Key";
        public static string Gender = "Sex";
        public static string NotMatched = "NotMatched";

        public static string SQLTablePrefix = "SQLTablePrefix";
        public static IFormatProvider MethodEnteredMsg { get; set; }

        public static IFormatProvider MethodExitedMsg { get; set; }

        public const string VerificationScheduledTime = "VerificationScheduledTime";
        public const string VerificationScheduledTimeTill = "VerificationScheduledTimeTill";
        public const string VerificationIntervalMinutes = "VerificationIntervalMinutes";
        public const string VerificationMode = "VerificationMode";
        public const string VerificationSpecificDayOfWeek = "VerificationSpecificDayOfWeek";


        //Window service frequency.
        public const string Daily = "DAILY";
        public const string Interval = "INTERVAL";
        public const string Weekly = "WEEKLY";
        public const string SpecificDayOfWeek = "SPECIFICDAYOFWEEK";

        public const string ZeroE = "0E";
        public const string DE = "DE";

        public const string One = "1";
        public const string Two = "2";

        public const char ZeroChar = '0';
        public const char SevenChar = '7';
        public const char EightChar = '8';
        public const char FiveChar = '5';
        public const char O = 'O';
        public const char D = 'D';
        public const char Z = 'Z';
        public const char B = 'B';
        public const char S = 'S';
        

        public const int ZeroInt = 0;        
        public const int OneInt = 1;
        public const int TwoInt = 2;
        public const int ThreeInt = 3;
        public const int FourInt = 4;
        public const int FiveInt = 5;
        public const int SixInt = 6;
        public const int SevenInt = 7;
        public const int NineInt = 9;
        public const int SeventeenInt = 17;


        public const string HayyakDocumentReceiverScheduledTime = "HayyakDocumentReceiverScheduledTime";
        public const string HayyakDocumentReceiverMode = "HayyakDocumentReceiverMode";
        public const string HayyakDocumentReceiverIntervalMinutes = "HayyakDocumentReceiverIntervalMinutes";

        public const string NameSplittingDocumentReceiverScheduledTime = "NameSplittingDocumentReceiverScheduledTime";
        public const string NameSplittingDocumentReceiverMode = "NameSplittingDocumentReceiverMode";
        public const string NameSplittingDocumentReceiverIntervalMinutes = "NameSplittingDocumentReceiverIntervalMinutes";
        
        public const string DocumentDownloadScheduledTime = "DocumentDownloadScheduledTime";
        public const string DocumentDownloadMode = "DocumentDownloadMode";
        public const string DocumentDownloadIntervalMinutes = "DocumentDownloadIntervalMinutes";

        public const string GlareDetectionScheduledTime = "GlareDetectionScheduledTime";
        public const string GlareDetectionMode = "GlareDetectionMode";
        public const string GlareDetectionIntervalMinutes = "GlareDetectionIntervalMinutes";

        public const string PassportParserScheduledTime = "PassportParserScheduledTime";
        public const string PassportParserMode = "PassportParserMode";
        public const string PassportParserIntervalMinutes = "PassportParserIntervalMinutes";

        public const string EIDAParserScheduledTime = "EIDAParserScheduledTime";
        public const string EIDAParserMode = "EIDAParserMode";
        public const string EIDAParserIntervalMinutes = "EIDAParserIntervalMinutes";

        public const string LowPriorityPassportParserScheduledTime = "LowPriorityPassportParserScheduledTime";
        public const string LowPriorityPassportParserMode = "LowPriorityPassportParserMode";
        public const string LowPriorityPassportParserIntervalMinutes = "LowPriorityPassportParserIntervalMinutes";

        public const string LowPriorityEIDAParserScheduledTime = "LowPriorityEIDAParserScheduledTime";
        public const string LowPriorityEIDAParserMode = "LowPriorityEIDAParserMode";
        public const string LowPriorityEIDAParserIntervalMinutes = "LowPriorityEIDAParserIntervalMinutes";

        public const string SaveDocumentAttributeScheduledTime = "SaveDocumentAttributeScheduledTime";
        public const string SaveDocumentAttributeMode = "SaveDocumentAttributeMode";
        public const string SaveDocumentAttributeIntervalMinutes = "SaveDocumentAttributeIntervalMinutes";

        public const string LowPrioritySaveDocumentAttributeScheduledTime = "LowPrioritySaveDocumentAttributeScheduledTime";
        public const string LowPrioritySaveDocumentAttributeMode = "LowPrioritySaveDocumentAttributeMode";
        public const string LowPrioritySaveDocumentAttributeIntervalMinutes = "LowPrioritySaveDocumentAttributeIntervalMinutes";


        public const string DeleteAppzoneDocumentScheduledTime = "DeleteAppzoneDocumentScheduledTime";
        public const string DeleteAppzoneDocumentMode = "DeleteAppzoneDocumentMode";
        public const string DeleteAppzoneDocumentIntervalMinutes = "DeleteAppzoneDocumentIntervalMinutes";

        public const string PassportMRZParserStrategyMRZOnly = "PassportMRZParserStrategyMRZOnly";
        public const string PassportMRZParserStrategyDirect = "PassportMRZParserStrategyDirect";

        public const string EmiratesIdMRZParserStrategyMRZOnly = "EmiratesIdMRZParserStrategyMRZOnly";
        public const string EmiratesIdMRZParserStrategyDirect = "EmiratesIdMRZParserStrategyDirect";

        public const string Passport = "Passport";
        public const string Emirates = "Emirates";

        public const string Processing = "Processing";
    }
}
