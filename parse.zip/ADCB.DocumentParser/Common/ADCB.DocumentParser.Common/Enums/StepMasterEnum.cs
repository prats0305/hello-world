﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Enums
{
    public enum StepMasterEnum
    {
        [Description("DocumentReceiver")]
        DocumentReceiver = 1,
        [Description("DocumentDownload")]
        DocumentDownload = 2,
        [Description("GlareDetection")]
        GlareDetection = 3,
        [Description("PassportParser")]
        PassportParser = 4,
        [Description("EIDAParser")]
        EIDAParser = 5,
        [Description("SaveDocumentAttribute")]
        SaveDocumentAttribute = 6,
    }
}
