﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Enums
{
    public enum ErrorCodeEnum
    {
        [Description("An unexpected error occured in the application, Please contact application support team for details.")]
        GenericError = 1,
        Concurrency = 2

    }
}
