﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Enums
{
    public enum StatusEnum
    {
        [Description("Initiated")]
        Initiated = 1,
        [Description("Pending")]
        Pending = 2,
        [Description("Completed")]
        Completed = 3,
        [Description("Failed")]
        Failed = 4,
        [Description("GlarePassed")]
        GlarePassed = 5,
        [Description("GlareFailed")]
        GlareFailed = 6,
        [Description("Matched")]
        Matched = 7,
        [Description("NotMatched")]
        NotMatched = 8,
        [Description("PartialMatched")]
        PartialMatched = 9,
        [Description("PassportParser")]
        PassportParser = 10,
        [Description("EIDAParser")]
        EIDAParser = 11,
        [Description("LowPassportPars")]
        LowPassportPars = 12,
        [Description("LowEIDAPars")]
        LowEIDAPars = 13,
        [Description("SaveDocAttr")]
        SaveDocAttr = 14,
        [Description("PendingLowTask")]
        PendingLowTask = 15,
        [Description("NoDocIndex")]
        NoDocIndex = 16,
        [Description("TibcoFailed")]
        TibcoFailed = 17

    }
}
