﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Enums
{
    public enum DocumentTypeEnum
    {
        [Description("Passport")]
        Passport = 1,
        [Description("EIDA")]
        EIDA = 2,
    }
}
