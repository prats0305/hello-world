﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Enums
{
    public enum AttributeMasterEnum
    {
        [Description("PassportNo")]
        PassportNo = 1,
        [Description("EmiratesId")]
        EmiratesId = 2,
        [Description("FullName")]
        FullName = 3,
        [Description("DateOfBirth")]
        DateOfBirth = 4,
        [Description("Passport_DateOfExpiry")]
        Passport_DateOfExpiry = 5,
        [Description("EIDA_DateOfExpiry")]
        EIDA_DateOfExpiry = 6,
        [Description("Gender")]
        Gender = 7,
        [Description("Nationality")]
        Nationality = 8,
        [Description("GlareStatus")]
        GlareStatus = 9
 
    }
}
