﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ADCB.DocumentParser.Common.Extensions
{
    public static class ObjectExtension
    {
        /// <summary>
        /// Gets whether the given <see cref="object" /> is NOT null or Not.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsNotNull(this Object obj)
        {
            return obj != null;
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is NOT null or Not.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsNotZero(this long obj)
        {
            return !obj.Equals(0);
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is NOT null or Not.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsZero(this long obj)
        {
            return obj.Equals(0);
        }

        public static Boolean IsZero(this long? obj)
        {
            return obj.Equals(0);
        }

        public static Boolean IsZero(this int? obj)
        {
            return !obj.HasValue || obj.Equals(0);
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is NOT null or Not.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsZero(this int obj)
        {
            return obj.Equals(0);
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is Positive or not
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is Positive and not zero, otherwise false.</returns>
        public static Boolean IsPositive(this byte obj)
        {
            return obj > 0;
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is Positive or not
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is Positive and not zero, otherwise false.</returns>
        public static Boolean IsPositive(this int obj)
        {
            return obj > 0;
        }
        /// <summary>
        /// Gets whether the given <see cref="object" /> is Positive or not
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is Positive and not zero, otherwise false.</returns>
        public static Boolean IsPositive(this long obj)
        {
            return obj > 0;
        }
        /// <summary>
        /// Gets whether the given <see cref="object" /> is NOT null or Not.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsNotNull(this DateTime obj)
        {
            return obj != null;
        }

        /// <summary>
        /// Gets whether the given <see cref="Object" /> is null or not.
        /// </summary>
        /// <param name="obj">The <see cref="Object" /> to check.</param>
        /// <returns>A value of true if the <see cref="Object" /> is null, otherwise false.</returns>
        public static Boolean IsNull(this Object obj)
        {
            return obj == null;
        }

        /// <summary>
        ///     Cast the given object to the specified type.
        /// </summary>
        /// <typeparam name="T">The type.</typeparam>
        /// <param name="obj">The object to cast.</param>
        /// <returns>The object as the specified type.</returns>
        public static T As<T>(this Object obj)
        {
            return (T)obj;
        }

        public static T Chain<T>(this T obj, Action<T> action)
        {
            if (action.IsNull())
                throw new Exception("condition is null.");
            action(obj);
            return obj;
        }

        /// <summary>
        /// Gets whether the given <see cref="Object" /> is null or not.
        /// </summary>
        /// <param name="obj">The <see cref="Object" /> to check.</param>
        /// <returns>A value of true if the <see cref="Object" /> is null, otherwise false.</returns>
        public static string IsEmptyIfNull(this object obj)
        {
            return obj == null ? string.Empty : obj.ToString();
        }

        /// <summary>
        /// Gets whether the given <see cref="Object" /> is null or not.
        /// </summary>
        /// <param name="obj">The <see cref="Object" /> to check.</param>
        /// <returns>A value of true if the <see cref="Object" /> is null, otherwise false.</returns>
        public static string IsEmptyIfNullOrEmpty(this string obj)
        {
            return string.IsNullOrEmpty(obj) ? string.Empty : obj.ToString();
        }

        public static bool IfNotAnInt(this Object obj)
        {
            int value;
            try
            {
                return int.TryParse(obj.ToString(), out value);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static string GetuserName(this string obj)
        {
            return !string.IsNullOrEmpty(obj) && obj.Contains("-") ? obj.Split('-')[0].Trim() : obj.ToString();
        }

        /// <summary>
        /// Gets whether the given <see cref="object" /> is null or 0.
        /// </summary>
        /// <param name="obj">The <see cref="object" /> to check.</param>
        /// <returns>A value of true if the <see cref="object" /> is NOT null, otherwise false.</returns>
        public static Boolean IsZeroOrNull(this short? obj)
        {
            return obj.Equals(0);
        }

        /// <summary>
        /// Method to return the source if string source is not null and is greater than 0
        /// </summary>
        /// <param name="target"></param>
        /// <param name="source"></param>
        /// <returns></returns>
        public static string AssignIfIsNotNullOrEmpty(this string target, string source)
        {
            if (!string.IsNullOrEmpty(source))
            {
                return source;
            }
            else
            {
                return target;
            }
        }

        /// <summary>
        /// Method to return the source if short source is not null and is greater than 0
        /// </summary>
        /// <param name="target"></param>
        /// <param name="source"></param>
        /// <returns></returns>
        public static short? AssignIfIsNotNullOrZero(this short? target, short? source)
        {
            if (source != null && source > 0)
            {
                return source;
            }
            else
            {
                return target;
            }
        }

        /// <summary>
        /// Method to return the source if byte source is not null and is greater than 0 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="source"></param>
        /// <returns></returns>
        public static byte? AssignIfIsNotNullOrZero(this byte? target, byte? source)
        {
            if (source != null && source > 0)
            {
                return source;
            }
            else
            {
                return target;
            }
        }


        public static string ToXml(this object data)
        {
            StringWriter sw = new StringWriter();

            using (XmlTextWriter tw = new XmlTextWriter(sw))
            {
                XmlSerializer serializer = new XmlSerializer(data.GetType());
                serializer.Serialize(tw, data);
                return sw.ToString();
            }

        }
        public static T ToEnum<T>(this string param)
        {
            var info = typeof(T);
            if (info.IsEnum)
            {
                T result = (T)Enum.Parse(typeof(T), param.ToString(), true);
                return result;
            }

            return default(T);
        }

        public static T ToEnum<T>(this int param)
        {
            var info = typeof(T);
            if (info.IsEnum)
            {
                T result = (T)Enum.Parse(typeof(T), param.ToString(), true);
                return result;
            }
            return default(T);
        }
    }
}
