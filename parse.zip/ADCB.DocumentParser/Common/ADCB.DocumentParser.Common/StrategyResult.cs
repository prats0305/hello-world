﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common
{
    public class StrategyResult
    {
        public List<string> AllTexts { get; }
        public StrategyResult()
        {
            Values = new Dictionary<string, string>();
            AllTexts = new List<string>();
        }
        public Dictionary<string, string> Values { get; set; }
    }
}
