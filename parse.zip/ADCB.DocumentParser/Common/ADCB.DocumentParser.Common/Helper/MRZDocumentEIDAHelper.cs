﻿using ADCB.DocumentParser.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Helper
{
    public static class MRZDocumentEIDAHelper
    {
        public static string FormatEmiratesId(string value)
        {
            value = value.Contains(AppConstants.O) ? value.Replace(AppConstants.O, AppConstants.ZeroChar) : value;
            value = value.Contains(AppConstants.D) ? value.Replace(AppConstants.D, AppConstants.ZeroChar) : value;
            value = value.Contains(AppConstants.Z) ? value.Replace(AppConstants.Z, AppConstants.SevenChar) : value;
            value = value.Contains(AppConstants.B) ? value.Replace(AppConstants.B, AppConstants.EightChar) : value;
            value = value.Contains(AppConstants.S) ? value.Replace(AppConstants.S, AppConstants.FiveChar) : value;

            string firstIndexEid = string.Empty, secondIndexEid = string.Empty, thirdIndexEid = string.Empty, fourthIndexEid = string.Empty;
            switch (value.Length)
            {
                case 18:
                    firstIndexEid = value.Substring(AppConstants.ZeroInt, AppConstants.ThreeInt);
                    secondIndexEid = value.Substring(AppConstants.FourInt, AppConstants.FourInt);
                    thirdIndexEid = value.Substring(AppConstants.NineInt, AppConstants.SevenInt);
                    fourthIndexEid = value.Substring(AppConstants.SeventeenInt, AppConstants.OneInt);
                    return firstIndexEid + "-" + secondIndexEid + "-" + thirdIndexEid + "-" + fourthIndexEid;
                default:
                    break;
            }

            return value;
        }

    }
}
