﻿using ADCB.Cryptography;
using ADCB.DocumentParser.Common.Constants;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Helper
{
    public static class AppConfigHelper
    {
        public static bool ShouldLogSql
        {
            get { return GetValue("LogSql") == "true"; }
        }

        public static string ServiceLogTable
        {
            get { return GetSetting("ServiceLogTableName"); }
        }

        public static string MRZParserDBConString
        {
            get { return DecryptSetting(AppConstants.MRZParserDBConString); }
        }
        public static string SQLTablePrefix
        {
            get { return GetSetting(AppConstants.SQLTablePrefix); }
        }

        public static string TesseractFolder
        {
            get { return GetSetting(AppConstants.TesseractFolder); }
        }
        public static string TesseractChars
        {
            get { return GetSetting(AppConstants.TesseractChars); }
        }
        public static string TesseractBestChoices
        {
            get { return GetSetting(AppConstants.TesseractBestChoices); }
        }
        public static string TesseractLanguage
        {
            get { return GetSetting(AppConstants.TesseractLanguage); }
        }

        public static string FileNameFormat
        {
            get { return GetSetting(AppConstants.FileNameFormat); }
        }

        private static string DecryptSetting(string setting)
        {
            return EncryptionDecryption.Decrypt(GetSetting(setting), GetSetting(AppConstants.KEY));
        }

        private static string EncryptSetting(string setting)
        {
            return EncryptionDecryption.Encrypt(GetSetting(setting), GetSetting(AppConstants.KEY));
        }

        public static string GetSetting(string section, string key)
        {
            try
            {
                var nvcSection = (NameValueCollection)ConfigurationManager.GetSection(section);
                return nvcSection[key];
            }
            catch
            {
                throw;
            }
        }

        private static string GetSetting(string setting)
        {
            return ConfigurationManager.AppSettings[setting];
        }

        public static string DecryptEncryptedString(string text)
        {
            return EncryptionDecryption.Decrypt(text, GetSetting(AppConstants.KEY));
        }

        public static string EncryptString(string text)
        {
            return EncryptionDecryption.Encrypt(text, GetSetting(AppConstants.KEY));
        }

        public static string GetValue(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }

        public static Int32 CustomersToProcessCount
        {
            get
            {
                return Convert.ToInt32(GetSetting("CustomersToProcessCount"));
            }
        }

        public static string ImageOutPath
        {
            get
            {
                return GetSetting("ImageOutPath");
            }
        }

    }
}
