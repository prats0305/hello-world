﻿using ADCB.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Helper
{
    /// <summary>
    ///     This class is wrapper on ADCB.Logging library exposing different methods provided by library.
    /// </summary>
    public static class LoggingHelper
    {
        /// <summary>
        ///     This method is used to log error with optional parameter.
        /// </summary>
        /// <param name="message">message to lo</param>
        /// <param name="userId">userId of the logged in user.</param>
        /// <param name="customObject">custom object to log error.</param>
        public static void LogError(string message, string userId = null, object customObject = null)
        {
            LoggingProvider.Logger.Error(message, userId, customObject);
        }

        /// <summary>
        ///     This method is used to log debug with optional parameter.
        /// </summary>
        /// <param name="message">message to lo</param>
        /// <param name="userId">userId of the logged in user.</param>
        /// <param name="customObject">custom object to log error.</param>
        public static void LogDebug(string message, string userId = null, object customObject = null)
        {
            LoggingProvider.Logger.Debug(message, userId, customObject);
        }

        /// <summary>
        ///     This method is used to log warning with optional parameter.
        /// </summary>
        /// <param name="message">message to lo</param>
        /// <param name="userId">userId of the logged in user.</param>
        /// <param name="customObject">custom object to log error.</param>
        public static void LogWarning(string message, string userId = null, object customObject = null)
        {
            LoggingProvider.Logger.Warning(message, userId, customObject);
        }

        /// <summary>
        ///     This method is used to log information with optional parameter.
        /// </summary>
        /// <param name="message">message to lo</param>
        /// <param name="userId">userId of the logged in user.</param>
        /// <param name="customObject">custom object to log error.</param>
        public static void LogInformation(string message, string userId = null, object customObject = null)
        {
            LoggingProvider.Logger.Information(message, userId, customObject);
        }
    }
}
