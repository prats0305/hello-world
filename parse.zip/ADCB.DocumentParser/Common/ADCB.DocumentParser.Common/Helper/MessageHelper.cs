﻿using ADCB.DocumentParser.Common.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Helper
{
    public class MessageHelper
    {
        public static string GetMethodEnteredMessage(string methodName)
        {
            return string.Format(AppConstants.MethodEnteredMsg, methodName);
        }

        public static string GetMethodExitMessage(string methodName)
        {
            return string.Format(AppConstants.MethodExitedMsg, methodName);
        }
    }
}
