﻿using ADCB.DocumentParser.Common.Constants;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Helper
{
    public static class MRZDocumentDateHelper
    {
        public static string FormatExtractedDate(string value, out string format)
        {
            format = "dd-MM-yyyy";
            
            if (ValidateDate(value)) { return value; }

            value = value.Contains(AppConstants.O) ? value.Replace(AppConstants.O, AppConstants.ZeroChar) : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains(AppConstants.D) ? value.Replace(AppConstants.D, AppConstants.ZeroChar) : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains(AppConstants.Z) ? value.Replace(AppConstants.Z, AppConstants.SevenChar) : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains(AppConstants.B) ? value.Replace(AppConstants.B, AppConstants.EightChar) : value;
            if (ValidateDate(value)) { return value; }
            value = value.Contains(AppConstants.S) ? value.Replace(AppConstants.S, AppConstants.FiveChar) : value;
            if (ValidateDate(value)) { return value; }

            //dd1MM1YYYY
            //dd1MMM1YYYY
            //dd7MM7YYYY
            //Od-MM-YYYY
            //13Apr81
            string dt, mon, year = "";
            switch (value.Length)
            {
                case 7:
                    dt = value.Substring(AppConstants.ZeroInt, AppConstants.TwoInt);
                    mon = value.Substring(AppConstants.TwoInt, AppConstants.ThreeInt);
                    year = value.Substring(AppConstants.FiveInt, AppConstants.TwoInt);
                    format = "ddMMMyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 8:
                    dt = value.Substring(AppConstants.ZeroInt, AppConstants.TwoInt);
                    mon = value.Substring(AppConstants.TwoInt, AppConstants.TwoInt);
                    year = value.Substring(AppConstants.FourInt, AppConstants.FourInt);
                    format = "dd-MM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 9:
                    dt = value.Substring(AppConstants.ZeroInt, AppConstants.TwoInt);
                    mon = value.Substring(AppConstants.TwoInt, AppConstants.ThreeInt);
                    mon = mon.Replace(AppConstants.ZeroChar, AppConstants.O);
                    mon = mon.Replace(AppConstants.FiveChar, AppConstants.S);
                    mon = mon.Replace(AppConstants.EightChar, AppConstants.B);
                    mon = mon.Replace(AppConstants.ZeroE, AppConstants.DE);
                    year = value.Substring(AppConstants.FiveInt, AppConstants.FourInt);
                    format = "dd-MMM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year, format)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 10:
                    dt = value.Substring(AppConstants.ZeroInt, AppConstants.TwoInt);
                    mon = value.Substring(AppConstants.ThreeInt, AppConstants.TwoInt);
                    year = value.Substring(AppConstants.SixInt, AppConstants.FourInt);
                    format = "dd-MM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 11:
                    dt = value.Substring(AppConstants.ZeroInt, AppConstants.TwoInt);
                    mon = value.Substring(AppConstants.ThreeInt, AppConstants.ThreeInt);
                    mon = mon.Replace(AppConstants.ZeroChar, AppConstants.O);
                    mon = mon.Replace(AppConstants.FiveChar, AppConstants.S);
                    mon = mon.Replace(AppConstants.EightChar, AppConstants.B);
                    mon = mon.Replace(AppConstants.ZeroE, AppConstants.DE);
                    year = value.Substring(AppConstants.SevenInt, AppConstants.FourInt);
                    format = "dd-MMM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year, format)) { return dt + "-" + mon + "-" + year; }
                    break;
                default:
                    break;
            }
            bool ValidateDate(string dateValue, string format1 = "dd-MM-yyyy")
            {
                if (DateTime.TryParseExact(dateValue, format1, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dDate))
                {
                    return true;
                }
                return false;
            }
            return value;
        }
    }
}
