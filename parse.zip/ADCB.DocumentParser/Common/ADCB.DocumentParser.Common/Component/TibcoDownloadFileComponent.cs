﻿using ADCB.DocumentParser.Common.Helper;
using ADCB.ESB;
using ADCB.ESB.TIBCOServices.ModeDocumentManagement;
using System;
using System.Data;
using System.IO;
using System.Xml;

namespace ADCB.DocumentParser.Common.Component
{
    public static class TibcoDownloadFileComponent
    {
        public static string usercase;
        public static string servicename;
        public static string version;
        public static string servAction;
        public static string senderId;
        public static string reqTime;
        public static string URL;
        public static string sysRefNo;    
        public static string userName;
        public static string credentials;
        public static string correlationID;
        public static string consumer;
        public static string repTime;
        public static string DBconnection = AppConfigHelper.MRZParserDBConString;
        public static string logTable = AppConfigHelper.ServiceLogTable;


        private static void HeaderSettings(string configKey)
        {
            URL = AppConfigHelper.GetSetting(configKey, "URL");
            usercase = AppConfigHelper.GetSetting(configKey, "UserCaseID");
            servicename = AppConfigHelper.GetSetting(configKey, "ServiceName");
            version = AppConfigHelper.GetSetting(configKey, "VersionNo");
            servAction = AppConfigHelper.GetSetting(configKey, "ServiceAction");
            senderId = AppConfigHelper.GetSetting(configKey, "SenderID");
            double addMinutes = Convert.ToDouble(AppConfigHelper.GetValue("AddMinutesToTibcoRequest"));
            reqTime = System.DateTime.Now.AddMinutes(addMinutes).ToString("dd/MM/yyyy HH:mm:ss");
            userName = AppConfigHelper.GetSetting(configKey, "Username");
            credentials = AppConfigHelper.GetSetting(configKey, "Credentials");
            correlationID = AppConfigHelper.GetSetting(configKey, "CorrelationID");
            consumer = AppConfigHelper.GetSetting(configKey, "Consumer");
        }

        public static string GetTibcoSftpOutPath(string documentIndex, long? CID)
        {
            string EDMSsection = "TIBCO_ModeDocumentManagement";
            HeaderSettings(EDMSsection);

            //string docIndexID = lblDocIndexID.Text;

            ModeDocumentManagementParams input = new ModeDocumentManagementParams();
            ModeDocumentManagementAdapter modeDocumentManagementAdapter = new ModeDocumentManagementAdapter();
            ViewDocumentResMsg response = new ViewDocumentResMsg();
            input.ParamForAllOperations = new CommonEDMSParams();


            input.URL = URL;
            input.usecaseID = usercase;
            input.serviceName = servicename;
            input.versionNo = version;
            input.serviceAction = servAction;
            input.senderID = senderId;
            
            //System will generate the reference number if it's not passed. tbl_ServiceLog has to be existing in DB. ref 'tbl_ServiceLog.txt'
            //passsed parameter sysRefNumber should have empty row in  tbl_ServiceLog for saving logs
            //input.sysRefNumber = SystemRefNumberGenerator();
            input.reqTimeStamp = reqTime;
            input.username = userName;
            input.credentials = credentials;
            input.correlationID = correlationID;
            input.consumer = consumer;

            input.ServiceLog = new ServiceLogs();
            input.ServiceLog.SaveLog = true;
            input.ServiceLog.TypeOfDB = DBType.IsSQL;
            //Decrypt and send
            input.ServiceLog.ConnectionString = DBconnection;
            input.ServiceLog.LogTableName = logTable;
            input.ServiceLog.UserID = "User";

            string reqMsg, resMsg;


            input.ParamForAllOperations.FuncNameView = AppConfigHelper.GetSetting(EDMSsection, "funcNameView");
            input.ParamForAllOperations.Password = AppConfigHelper.GetSetting(EDMSsection, "password");
            input.ParamForAllOperations.SeqPrefix = AppConfigHelper.GetSetting(EDMSsection, "SeqPrefix");
            input.ParamForAllOperations.UserName = AppConfigHelper.GetSetting(EDMSsection, "userName");
            input.ParamForAllOperations.ApplicationName = AppConfigHelper.GetSetting(EDMSsection, "ApplicationName");
            input.ParamForAllOperations.ConvRequired = AppConfigHelper.GetSetting(EDMSsection, "convRequired");

            input.ParamForAllOperations.ImageAsAttachement = AppConfigHelper.GetSetting(EDMSsection, "imageAsAttachement");
            
            input.ParamForAllOperations.DocIndex = documentIndex;

            response = modeDocumentManagementAdapter.ViewDocument(input, out reqMsg, out resMsg);

            if (response != null && response.ViewDocumentRes != null)
            {

                DataSet dsEDMSDocs = new DataSet();
                dsEDMSDocs.ReadXml(new XmlTextReader(new StringReader(response.ToXmlString())));

                if (dsEDMSDocs != null && dsEDMSDocs.Tables.Count > 0)
                {
                    if (dsEDMSDocs.Tables.Contains("docProperty") && dsEDMSDocs.Tables.Contains("ViewDocumentRes"))
                    {
                        string strExt = dsEDMSDocs.Tables["docProperty"].Rows[0]["fileFormat"].ToString();
                        string strFileName = dsEDMSDocs.Tables["docProperty"].Rows[0]["documentName"].ToString() + "." + strExt;
                        string remoteFileDownloadPath = dsEDMSDocs.Tables["ViewDocumentRes"].Rows[0]["imagePat"].ToString();
                        string localFileDownloadPath = AppConfigHelper.GetSetting(EDMSsection, "TibcoSftpLocalDownloadFilePath");
                        string remoteFileDownloadFolder = AppConfigHelper.GetSetting(EDMSsection, "TibcoSftpRemoteDownloadedFilePath");
                        string strDownloadFileName = remoteFileDownloadPath.Remove(0, remoteFileDownloadFolder.Length);

                        var downloadPath = System.IO.Path.Combine(localFileDownloadPath, CID.ToString(),
                            System.IO.Path.GetFileNameWithoutExtension(remoteFileDownloadPath), System.IO.Path.GetFileName(remoteFileDownloadPath));
                        ADCB.SFTP.SFTP objSFTPHelper = new SFTP.SFTP();
                        bool isDowloaded = objSFTPHelper.DownloadFileFromSFTP(remoteFileDownloadPath, downloadPath);
                        if (isDowloaded)
                            return downloadPath;                 

                    }
                }
            }

            return string.Empty;

        }
    }

}

