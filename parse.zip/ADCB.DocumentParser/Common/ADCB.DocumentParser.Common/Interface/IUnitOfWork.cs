﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Interface
{
    public interface IUnitOfWork : IDisposable
    {
        /// <summary>
        ///     Saves all pending changes
        /// </summary>
        /// <returns>The number of objects in an Added, Modified, or Deleted state</returns>
        bool Commit();

        /// <summary>
        /// </summary>
        /// <returns></returns>
        bool SaveChanges(bool isAuditToBeSaved = false);

        /// <summary>
        /// </summary>
        void BeginTransaction();

        /// <summary>
        /// 
        /// </summary>
        void Rollback();
    }
}
