﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("Customer")]
    public partial class Customer
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Customer()
        {
            CustomerAttributes = new HashSet<CustomerAttribute>();
            CustomerDocumentAttributes = new HashSet<CustomerDocumentAttribute>();
            ProcessCustomers = new HashSet<ProcessCustomer>();
        }

        [Key]
        public long UId { get; set; }

        public long? CID { get; set; }

        [StringLength(200)]
        public string FullName { get; set; }

        [StringLength(200)]
        public string GivenName { get; set; }

        [StringLength(200)]
        public string SurName { get; set; }

        public long? ProcessUId { get; set; }

        public DateTime? CreatedOn { get; set; }

        public DateTime? LastModifiedOn { get; set; }

        public bool? IsHayaakCustomer { get; set; }

        public virtual Process Process { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerAttribute> CustomerAttributes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerDocumentAttribute> CustomerDocumentAttributes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProcessCustomer> ProcessCustomers { get; set; }
    }
}
