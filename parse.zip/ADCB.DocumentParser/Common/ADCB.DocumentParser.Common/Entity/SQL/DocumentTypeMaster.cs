﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("DocumentTypeMaster")]
    public partial class DocumentTypeMaster
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DocumentTypeMaster()
        {
            EDMSDocuments = new HashSet<EDMSDocument>();
        }

        [Key]
        public byte UId { get; set; }

        [Required]
        [StringLength(50)]
        public string DocumentType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EDMSDocument> EDMSDocuments { get; set; }
    }
}
