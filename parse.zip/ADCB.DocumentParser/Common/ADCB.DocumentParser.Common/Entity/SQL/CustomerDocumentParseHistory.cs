﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("CustomerDocumentParseHistory")]
    public partial class CustomerDocumentParseHistory
    {
        [Key]
        public long UId { get; set; }

        public long CustomerDocumentUId { get; set; }

        public DateTime ParsedOn { get; set; }

        [StringLength(5)]
        public string ParseStatus { get; set; }

        public string ErrorMessage { get; set; }

        [StringLength(50)]
        public string GivenName { get; set; }

        [StringLength(50)]
        public string SurName { get; set; }

        public virtual CustomerDocument CustomerDocument { get; set; }
    }
}
