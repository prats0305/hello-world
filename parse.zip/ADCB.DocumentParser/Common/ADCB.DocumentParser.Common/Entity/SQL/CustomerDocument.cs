﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("CustomerDocument")]
    public partial class CustomerDocument
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CustomerDocument()
        {
            CustomerDocumentParseHistories = new HashSet<CustomerDocumentParseHistory>();
        }

        [Key]
        public long UId { get; set; }

        public long CustomerUId { get; set; }

        public byte? DocumentTypeUId { get; set; }

        [StringLength(50)]
        public string EdmsDocumentIndex { get; set; }

        [StringLength(500)]
        public string DocumentName { get; set; }

        [StringLength(500)]
        public string DocumentPath { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        [StringLength(200)]
        public string GivenName { get; set; }

        [StringLength(200)]
        public string SurName { get; set; }

        public virtual Customer Customer { get; set; }

        public virtual DocumentTypeMaster DocumentTypeMaster { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerDocumentParseHistory> CustomerDocumentParseHistories { get; set; }
    }
}
