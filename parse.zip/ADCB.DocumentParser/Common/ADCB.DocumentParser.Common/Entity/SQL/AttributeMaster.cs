﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("AttributeMaster")]
    public partial class AttributeMaster
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public AttributeMaster()
        {
            CustomerAttributes = new HashSet<CustomerAttribute>();
            CustomerDocumentAttributes = new HashSet<CustomerDocumentAttribute>();
            ProcessStepAttributes = new HashSet<ProcessStepAttributes>();
        }

        [Key]
        public byte UId { get; set; }

        [Required]
        [StringLength(200)]
        public string AttributeName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerAttribute> CustomerAttributes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerDocumentAttribute> CustomerDocumentAttributes { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProcessStepAttributes> ProcessStepAttributes { get; set; }
    }
}
