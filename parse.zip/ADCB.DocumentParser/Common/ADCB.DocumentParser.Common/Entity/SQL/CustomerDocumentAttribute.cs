﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("CustomerDocumentAttribute")]
    public partial class CustomerDocumentAttribute
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long UId { get; set; }

        public long CustomerUId { get; set; }

        public long ProcessStepUId { get; set; }

        public byte AttributeUId { get; set; }

        [StringLength(1000)]
        public string Value { get; set; }

        public byte StatusUId { get; set; }

        public bool IsLowPriorityParserTaskRan { get; set; }

        public DateTime? UpdatedOn { get; set; }

        public virtual AttributeMaster AttributeMaster { get; set; }

        public virtual Customer Customer { get; set; }

        public virtual ProcessStep ProcessStep { get; set; }

        public virtual Status Status { get; set; }
    }
}
