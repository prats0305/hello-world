﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("CustomerProcessHistory")]
    public partial class CustomerProcessHistory
    {
        [Key]
        public long UId { get; set; }

        public long CustomerUId { get; set; }

        public long ProcessUId { get; set; }

        public virtual Customer Customer { get; set; }
    }
}
