﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("CountryMaster")]
    public partial class CountryMaster
    {
        [Key]
        public int UId { get; set; }

        [Required]
        [StringLength(1000)]
        public string Name { get; set; }

        [StringLength(1000)]
        public string Nationality { get; set; }

        [StringLength(2)]
        public string Aplha2Code { get; set; }

        [StringLength(3)]
        public string Aplha3Code { get; set; }

        public int? NumericCode { get; set; }
    }
}
