﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("ESBServiceLog")]
    public partial class ESBServiceLog
    {
        [Key]
        public long RefId { get; set; }

        [Required]
        [StringLength(150)]
        public string ServiceName { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public DateTime? RequestTime { get; set; }

        public DateTime? ResponseTime { get; set; }

        [StringLength(10)]
        public string ReturnCode { get; set; }

        [StringLength(500)]
        public string ErrorDescription { get; set; }

        [StringLength(100)]
        public string UserId { get; set; }
    }
}
