﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("EDMSDocument")]
    public partial class EDMSDocument
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public EDMSDocument()
        {
            ProcessCustomerDocuments = new HashSet<ProcessCustomerDocument>();
        }

        [Key]
        public long UId { get; set; }

        public long CID { get; set; }

        [Required]
        [StringLength(500)]
        public string DocumentName { get; set; }

        [Required]
        [StringLength(50)]
        public string DocumentIndex { get; set; }

        public byte? DocumentTypeUid { get; set; }

        public DateTime? CreatedDateTime { get; set; }

        [StringLength(500)]
        public string CustomerName { get; set; }

        public DateTime LastUpdatedOn { get; set; }

        public virtual DocumentTypeMaster DocumentTypeMaster { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProcessCustomerDocument> ProcessCustomerDocuments { get; set; }
    }
}
