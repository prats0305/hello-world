﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("ProcessCustomer")]
    public partial class ProcessCustomer
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ProcessCustomer()
        {
            ProcessCustomerDocuments = new HashSet<ProcessCustomerDocument>();
        }

        [Key]
        public long UId { get; set; }

        public long ProcessUId { get; set; }

        public long CustomerUId { get; set; }

        public byte StatusUId { get; set; }

        public int? RetryCount { get; set; }

        public DateTime? UpdatedOn { get; set; }

        public virtual Customer Customer { get; set; }

        public virtual Process Process { get; set; }

        public virtual Status Status { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProcessCustomerDocument> ProcessCustomerDocuments { get; set; }
    }
}
