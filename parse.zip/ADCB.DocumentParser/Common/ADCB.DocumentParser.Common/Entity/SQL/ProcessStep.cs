﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Common.Entity.SQL
{
    [Table("ProcessStep")]
    public partial class ProcessStep
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ProcessStep()
        {
            CustomerDocumentAttributes = new HashSet<CustomerDocumentAttribute>();
            ProcessStepAttributes = new HashSet<ProcessStepAttributes>();
        }

        [Key]
        public long UId { get; set; }

        public long ProcessUId { get; set; }

        public long? ProcessCustomerDocumentUId { get; set; }

        public byte StepUId { get; set; }

        public byte? StatusUId { get; set; }

        public DateTime StartedOn { get; set; }

        public DateTime? CompletedOn { get; set; }

        public string ErrorMessage { get; set; }

        //public virtual CustomerDocumentAttribute CustomerDocumentAttribute { get; set; }

 

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CustomerDocumentAttribute> CustomerDocumentAttributes { get; set; }

        public virtual Process Process { get; set; }
        public virtual ProcessCustomerDocument ProcessCustomerDocument { get; set; }
        
        public virtual Status Status { get; set; }

        public virtual StepMaster StepMaster { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ProcessStepAttributes> ProcessStepAttributes { get; set; }
    }
}
