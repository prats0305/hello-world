﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Exceptions;
using Microsoft.Practices.Unity;
using ADCB.DocumentParser.Common.Interface;
using System.Data.Entity;
using ADCB.DocumentParser.Common.Mapping;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.API.DAL.SqlRepository;
using ADCB.DocumentParser.API.DAL;
using ADCB.DocumentParser.API.BLL.DomainUnits;
using ADCB.DocumentParser.Common.Enums;

namespace ADCB.DocumentParser.API.Facade
{
    public class DocumentParserFacade 
    {
        UnityContainer _container = null;
               
        public DocumentParserFacade(UnityContainer container)
        {
            _container = container;
            RegisterByConvention();
            RegisterMapping();
        }

        private UnityContainer Container
        {
            get { return _container; }
        }

        private void RegisterByConvention()
        {
            _container.RegisterType<DbContext, DocumentParserDbContext>(new HierarchicalLifetimeManager(), new InjectionConstructor());
            _container.RegisterType<IUnitOfWork, UnitOfWork>();
            _container.RegisterType<ICustomerRepository, CustomerRepository>();
            _container.RegisterType<ICustomerAttributeRepository, CustomerAttributeRepository>();
            _container.RegisterType<ICountryMasterRepository, CountryMasterRepository>();
            _container.RegisterType<IProcessCustomerRepository, ProcessCustomerRepository>();
            _container.RegisterType<IProcessRepository, ProcessRepository>();
            _container.RegisterType<IEDMSDocumentRepository, EDMSDocumentRepository>();
            _container.RegisterType<IProcessCustomerDocumentRepository, ProcessCustomerDocumentRepository>();
            _container.RegisterType<ICustomerDocumentAttributeRepository, CustomerDocumentAttributeRepository>();
            _container.RegisterType<IProcessStepRepository, ProcessStepRepository>();
            _container.RegisterType<IProcessStepAttributesRepository, ProcessStepAttributesRepository>();
            _container.RegisterType<DocumentParserService>(new HierarchicalLifetimeManager());

        }

        private void RegisterMapping()
        {
            AutomapperMapping.CreateMapForDocumentParser();
        }        

        public bool ReceiveAndProcessCustomers(ProcessTypeEnum processTypeEnum)
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().ReceiveAndProcessCustomers(processTypeEnum)));
        }

        public bool DownloadProcessCustomersDocument()
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().DownloadProcessCustomersDocument()));
        }

        public bool GlareDetectionForPendingCustomers()
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().GlareDetectionForPendingCustomers()));
        }

        public bool ParseGlarePassedImages(DocumentTypeEnum docTypeEnum, bool isLowPriority = false)
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().ParseGlarePassedImages(docTypeEnum, isLowPriority)));
        }

        public bool SaveDocumentAttributeTask(bool isLowPriorityTask = false)
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().SaveDocumentAttributeTask(isLowPriorityTask)));
        }

        public bool DeleteAppzoneDocumentTask()
        {
            return DocumentParserExceptionHandler.ExecuteWithLogging<bool>(() =>
               (Container.Resolve<DocumentParserService>().DeleteAppzoneDocumentTask()));
        }

    }
}
