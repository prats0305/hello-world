﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using ADCB.DocumentParser.Common.Interface;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.Common.Extensions;
using System.Globalization;
using System.Text.RegularExpressions;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.ImageProcessing;
using System.IO;
using ADCB.DocumentParser.Common.Component;

namespace ADCB.DocumentParser.API.BLL.DomainUnits
{
    public class DocumentParserService
    {
        ICustomerRepository _dal;
        ICountryMasterRepository _dalCountryMaster;
        IProcessCustomerRepository _dalProcessCustomerRepository;
        IProcessRepository _dalProcessRepository;
        IUnitOfWork _iUnitOfWork;
        IEDMSDocumentRepository _dalEDMSDocumentRepository;
        IProcessCustomerDocumentRepository _dalProcessCustomerDocumentRepository;
        IProcessStepRepository _dalProcessStepRepository;
        ICustomerAttributeRepository _dalCustomerAttributeRepository;
        IProcessStepAttributesRepository _dalProcessStepAttributesRepository;
        ICustomerDocumentAttributeRepository _dalCustomerDocumentAttributeRepository;

        public DocumentParserService(IUnitOfWork iUnitOfWork, ICustomerRepository customerRepository, ICountryMasterRepository countryMasterRepository,
            IProcessCustomerRepository processCustomerRepository, IProcessRepository processRepository, IEDMSDocumentRepository edmsDocumentRepository,
            IProcessCustomerDocumentRepository processCustomerDocumentRepository, IProcessStepRepository processStepRepository,
            ICustomerAttributeRepository customerAttributeRepository, IProcessStepAttributesRepository processStepAttributesRepository,
            ICustomerDocumentAttributeRepository customerDocumentAttributeRepository)
        {
            _iUnitOfWork = iUnitOfWork;
            _dal = customerRepository;
            _dalCountryMaster = countryMasterRepository;
            _dalProcessCustomerRepository = processCustomerRepository;
            _dalProcessRepository = processRepository;
            _dalEDMSDocumentRepository = edmsDocumentRepository;
            _dalProcessCustomerDocumentRepository = processCustomerDocumentRepository;
            _dalProcessStepRepository = processStepRepository;
            _dalCustomerAttributeRepository = customerAttributeRepository;
            _dalProcessStepAttributesRepository = processStepAttributesRepository;
            _dalCustomerDocumentAttributeRepository = customerDocumentAttributeRepository;
        }

        /// <summary>
        /// This method takes configured number of customers for process which are in Customer table and not in ProcessCustomer table
        /// and then it initates new Process table entry and it save all fetched customers details in ProcessCustomer table
        /// </summary>
        /// <param name="processTypeEnum"></param>
        /// <returns></returns>
        public bool ReceiveAndProcessCustomers(ProcessTypeEnum processTypeEnum)
        {
            try
            {
                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method started :");

                // Get All CustomerUids which are present in Customer table but not present in ProcessCustomers table                    
                var custUids = _dal.GetCustomerUidsToProcess(processTypeEnum);

                if (custUids != null && custUids.Count() > 0)
                {
                    // Initiate New Process
                    Process process = new Process();
                    process.ProcessTypeUId = processTypeEnum.GetId<byte>();
                    process.StartedOn = DateTime.Now;
                    process.StatusUId = (byte)StatusEnum.Initiated;
                    _dalProcessRepository.AddProcessRepository(process);

                    // Add New ProcessCustomer entries
                    foreach (var custUid in custUids)
                    {
                        ProcessCustomer processCustomer = new ProcessCustomer();
                        processCustomer.StatusUId = (byte)StatusEnum.Initiated;                        
                        processCustomer.Process = process;
                        processCustomer.CustomerUId = custUid;
                        processCustomer.UpdatedOn = DateTime.Now;
                        _dalProcessCustomerRepository.AddProcessCustomerRepository(processCustomer);
                    }
                    _iUnitOfWork.SaveChanges();
                }

                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method ended :");

                return true;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
        }

        /// <summary>
        /// This method calls the TIBCO service for downloading the document images from Tibco sftp path
        /// and save it in localSftp path. After that it saves the local sftp path in ProcessCustomerDocument table
        /// and after success it update the ProcessCustomerDocument and ProcessCustomer with Pending status
        /// </summary>
        /// <returns></returns>
        public bool DownloadProcessCustomersDocument()
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;

            try
            {
                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method Started :");

                // Get All Initiated and NoDocIndex Status ProcessCustomer table records whose retrycount < = 2
                var processCustomers = _dalProcessCustomerRepository.GetProcessCustomers();

                if (processCustomers != null && processCustomers.Count() > 0)
                {
                    foreach (var processCustomer in processCustomers)
                    {
                        try
                        {
                            isExceptionOccur = false;
                            string fileName = string.Empty, destFile = string.Empty;
                            var edmsDocuments = _dalEDMSDocumentRepository.GetInitiatedCustomersEDMSDetails(processCustomer.Customer.CID);

                            if (edmsDocuments != null && edmsDocuments.Count() > 0)
                            {
                                bool isTibcoFailed = false;
                                foreach (var edmsDocument in edmsDocuments)
                                {
                                    isTibcoFailed = false;
                                    //string outPath = TibcoDownloadFileComponent.GetTibcoSftpOutPath(edmsDocument.DocumentIndex, edmsDocument.CID);
                                    //if (Directory.Exists(outPath))
                                    //{
                                    //    LoggingHelper.LogInformation(string.Format("TIBCO files copied to Appzone path for CID : {0}", edmsDocument.CID));

                                    //    ProcessCustomerDocument processCustomerDocument = new ProcessCustomerDocument();
                                    //    processCustomerDocument.ProcessCustomerUId = processCustomer.UId;
                                    //    processCustomerDocument.EDMSDocumentUId = edmsDocument.UId;
                                    //    processCustomerDocument.DocumentPath = outPath;
                                    //    processCustomerDocument.UpdatedOn = DateTime.Now;
                                    //    processCustomerDocument.StatusUId = (byte)StatusEnum.Pending;
                                    //    _dalProcessCustomerDocumentRepository.AddProcessCustomerDocument(processCustomerDocument);                                

                                    //}

                                    string tibcoInPath = string.Empty; string outPath = string.Empty;
                                    if (edmsDocument.DocumentTypeUid == (byte)DocumentTypeEnum.Passport)
                                    {
                                        tibcoInPath = @"\\adcm7108\d$\DocumentParser\TIBCOPath\" + edmsDocument.CID + @"\Passport";
                                        outPath = AppConfigHelper.ImageOutPath + edmsDocument.CID + "_" + "Passport_" + DateTime.Now.ToString("ddMMyyyyHHmmss");
                                    }
                                    if (edmsDocument.DocumentTypeUid == (byte)DocumentTypeEnum.EIDA)
                                    {
                                        tibcoInPath = @"\\adcm7108\d$\DocumentParser\TIBCOPath\" + edmsDocument.CID + @"\EIDA";
                                        outPath = AppConfigHelper.ImageOutPath + edmsDocument.CID + "_" + "EIDA_" + DateTime.Now.ToString("ddMMyyyyHHmmss");
                                    }


                                    if (Directory.Exists(tibcoInPath))
                                    {
                                        var outDir = Directory.CreateDirectory(outPath);
                                        string[] files = Directory.GetFiles(tibcoInPath);

                                        // Copy the files from TIBCO to Appzone path and overwrite destination files if they already exist.
                                        if (files != null && files.Count() > 0)
                                        {
                                            foreach (string file in files)
                                            {
                                                // Use static Path methods to extract only the file name from the path.
                                                fileName = Path.GetFileName(file);
                                                destFile = Path.Combine(outPath, fileName);
                                                File.Copy(file, destFile);
                                            }
                                        }

                                        LoggingHelper.LogInformation(string.Format("TIBCO files copied to Appzone path for CID : {0}", edmsDocument.CID));

                                        ProcessCustomerDocument processCustomerDocument = new ProcessCustomerDocument();
                                        processCustomerDocument.ProcessCustomerUId = processCustomer.UId;
                                        processCustomerDocument.EDMSDocumentUId = edmsDocument.UId;
                                        processCustomerDocument.DocumentPath = outPath;
                                        processCustomerDocument.UpdatedOn = DateTime.Now;
                                        processCustomerDocument.StatusUId = (byte)StatusEnum.Pending;
                                        _dalProcessCustomerDocumentRepository.AddProcessCustomerDocument(processCustomerDocument);
                                    }
                                    else
                                    {
                                        isTibcoFailed = true;
                                        UpdateProcessCustomer(processCustomer, (byte)StatusEnum.TibcoFailed);
                                        LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + string.Format("Exception :TIBCO InPath : {0} does not exist for CID:{1}", tibcoInPath, edmsDocument.CID));
                                        break;
                                    }
                                }

                                if (!isTibcoFailed)
                                    UpdateProcessCustomer(processCustomer, (byte)StatusEnum.Pending);
                            }
                            else
                            {
                                // Update ProcessCustomer record with No Document Index Found status
                                UpdateProcessCustomer(processCustomer, (byte)StatusEnum.NoDocIndex);
                                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + string.Format("Exception :DocumentIndex does not exist for CID:{0}", edmsDocuments.Select(x => x.CID).FirstOrDefault().ToString()));
                            }

                            _iUnitOfWork.SaveChanges();
                        }
                        catch (Exception ex)
                        {
                            isExceptionOccur = true;
                            errorMessage = ex.GetErrorMessage();
                            LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                        }
                        finally
                        {
                            try
                            {
                                if (isExceptionOccur)
                                {
                                    // Update ProcessCustomer record with Failed status
                                    if (processCustomer != null)
                                        UpdateProcessCustomerWithFailedStatus(processCustomer);
                                }
                            }
                            catch (Exception ex)
                            {
                                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                            }
                        }
                    }
                }

                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method ended :");
                return true;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
        }

        private void UpdateProcessCustomer(ProcessCustomer processCustomer, byte statusUid)
        {
            ProcessCustomer processCust = new ProcessCustomer();
            processCust.UId = processCustomer.UId;
            processCust.ProcessUId = processCustomer.ProcessUId;
            processCust.StatusUId = statusUid;
            processCust.CustomerUId = processCustomer.CustomerUId;
            processCust.UpdatedOn = DateTime.Now;
            if (statusUid == (byte)StatusEnum.NoDocIndex)
                processCust.RetryCount = processCustomer.RetryCount == null ? 1 : processCustomer.RetryCount + 1;
            _dalProcessCustomerRepository.UpdateProcessCustomer(processCust);
        }

        private void UpdateProcessCustomerWithFailedStatus(ProcessCustomer processCustomer)
        {
            try
            {
                processCustomer.StatusUId = (byte)StatusEnum.Failed;
                processCustomer.UpdatedOn = DateTime.Now;
                _dalProcessCustomerRepository.UpdateProcessCustomer(processCustomer);
                _iUnitOfWork.SaveChanges();
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        /// <summary>
        /// This method calls the python service to detect the Glare Status of images for all pending ProcessCustomerDocument records
        /// and initiate new ProcessStep record for each ProcessCustomerDocument and finally update the Glare status in ProcessStep
        /// and update the ProcessCustomerDocument records with completed status
        /// </summary>
        /// <returns></returns>
        public bool GlareDetectionForPendingCustomers()
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;

            try
            {
                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method started :");

                // Get All Pending Status ProcessCustomerDocument records
                var pendingProcessCustDocumentDetails = _dalProcessCustomerDocumentRepository.GetPendingProcessCustomerDocumentDetails();

                if (pendingProcessCustDocumentDetails != null && pendingProcessCustDocumentDetails.Count() > 0)
                {
                    foreach (var pendingProcessCustDocument in pendingProcessCustDocumentDetails)
                    {
                        ProcessStep processStep = new ProcessStep();
                        try
                        {
                            isExceptionOccur = false;
                            // TO DO: Call python code to detect the Image glare status and pass input as pendingCust.DocumentPath
                            //   string[] files = System.IO.Directory.GetFiles(pendingCust.DocumentPath);

                            processStep.ProcessUId = pendingProcessCustDocument.ProcessCustomer.ProcessUId;
                            processStep.ProcessCustomerDocumentUId = pendingProcessCustDocument.UId;
                            processStep.StepUId = (byte)StepMasterEnum.GlareDetection;
                            processStep.StatusUId = (byte)StatusEnum.GlarePassed;
                            processStep.StartedOn = DateTime.Now;
                            _dalProcessStepRepository.AddProcessStep(processStep);

                            ProcessCustomerDocument procCustDoc = new ProcessCustomerDocument();
                            procCustDoc.UId = pendingProcessCustDocument.UId;
                            procCustDoc.ProcessCustomerUId = pendingProcessCustDocument.ProcessCustomerUId;
                            procCustDoc.EDMSDocumentUId = pendingProcessCustDocument.EDMSDocumentUId;
                            procCustDoc.DocumentPath = pendingProcessCustDocument.DocumentPath;
                            procCustDoc.StatusUId = (byte)StatusEnum.Completed;
                            procCustDoc.UpdatedOn = DateTime.Now;
                            _dalProcessCustomerDocumentRepository.UpdateProcessCustomerDocument(procCustDoc);

                            _iUnitOfWork.SaveChanges();


                        }
                        catch (Exception ex)
                        {
                            isExceptionOccur = true;
                            errorMessage = ex.GetErrorMessage();
                            LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());                            
                        }
                        finally
                        {
                            try
                            {
                                if (isExceptionOccur)
                                {
                                    if (processStep != null)
                                        UpdateProcessStepWithFailedStatus(processStep.UId, errorMessage, (byte)StepMasterEnum.GlareDetection);
                                }
                            }
                            catch (Exception ex)
                            {
                                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                            }

                        }
                    }

                    // Retrieve all ProcessCustUids from ProcessCustomerDocument records
                    List<long> processCustUids = pendingProcessCustDocumentDetails.Select(x => x.ProcessCustomerUId).Distinct().ToList();

                    //Update ProcessCustomer table with completed status whose All ProcessCustomerDocument records are in completed state
                    if (processCustUids != null && processCustUids.Count() > 0)
                        UpdateProcessCustomerWithCompleteStatus(processCustUids);
                }

                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method ended :");
                return true;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }

        }

        private void UpdateProcessCustomerWithCompleteStatus(List<long> processCustUids)
        {
            bool isExceptionOccur = false;

            foreach (var processCustUid in processCustUids)
            {
                var processCustomer = new ProcessCustomer();
                try
                {
                    isExceptionOccur = false;

                    processCustomer = _dalProcessCustomerRepository.GetCompletedDocProcessCustomerByUId(processCustUid);

                    if (processCustomer != null)
                    {
                        processCustomer.StatusUId = (byte)StatusEnum.Completed;
                        processCustomer.UpdatedOn = DateTime.Now;
                        _dalProcessCustomerRepository.UpdateProcessCustomer(processCustomer);
                        _iUnitOfWork.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    isExceptionOccur = true;
                    LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                }
                finally
                {
                    try
                    {
                        if (isExceptionOccur)
                        {
                            if (processCustomer != null)
                                UpdateProcessCustomer(processCustomer, (byte)StatusEnum.Failed);
                            _iUnitOfWork.SaveChanges();
                        }
                    }
                    catch (Exception ex)
                    {
                        LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                    }

                }
            }
        }

        /// <summary>
        /// This method is called by High and Low SaveDocAttribute task and take the records from ProcessStep 
        /// for high priority task with status as PassportParser/EIDAParser 
        /// and for low priority task status as LowPassportParser/LowEIDAParser
        /// Save the final CustomerDocumentAttribues table and
        /// update the ProcessStep with SaveDocAttr / PendingLowTask depending on attributes matched 
        /// </summary>
        /// <param name="isLowPriorityTask"></param>
        /// <returns></returns>
        public bool SaveDocumentAttributeTask(bool isLowPriorityTask = false)
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;

            try
            {
                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method started :");

                List<long> processStepUids = null;
                // Get All ProcessStepUIds for High Priority Task which are not in IsMovedToCustDocAtrbTable and Status having either PassportParser/EIDAParser
                // Get All ProcessStepUIds for Low Priority Task which are IsLowPriorityParserTaskRan as true and Status having either LowPassportParser/LowEIDAParser
                processStepUids = GetProcessStepUIds(isLowPriorityTask);

                if (processStepUids != null && processStepUids.Count > 0)
                {
                    IEnumerable<ProcessStepAttributes> processStepAttributes = new List<ProcessStepAttributes>();

                    processStepAttributes = GetProcessStepAttributesForSaveTask(isLowPriorityTask, processStepUids);

                    if (processStepAttributes != null && processStepAttributes.Count() > 0)
                    {
                        foreach (var processStepAttribute in processStepAttributes)
                        {
                            try
                            {
                                isExceptionOccur = false;
                                if (!isLowPriorityTask)
                                    AddProcessCustomerDocumentAttribute(processStepAttribute);
                                else
                                    UpdateProcessCustomerDocumentAttribute(processStepAttribute);

                                _iUnitOfWork.SaveChanges();

                                UpdateProcessStepAttribute(processStepAttribute);

                                _iUnitOfWork.SaveChanges();
                            }
                            catch (Exception ex)
                            {
                                isExceptionOccur = true;
                                errorMessage = ex.GetErrorMessage();
                                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                                return false;
                            }
                            finally
                            {
                                try
                                {
                                    if (isExceptionOccur)
                                    {
                                        UpdateProcessStepWithFailedStatus(processStepAttribute.ProcessStepUId, errorMessage, (byte)StepMasterEnum.SaveDocumentAttribute);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                                }

                            }
                        }

                        // Update Process Step with status as SaveDocAttr / PendingLowTask depending on attributes matched 
                        //and priority task
                        UpdateProcessStepStaus(processStepUids, isLowPriorityTask);

                        // Delete AppZoneServerPathImage folder/directory of image document for customers
                        //which are having status as SaveDocAttr
                        DeleteAppZoneServerPathImageDocument(isLowPriorityTask, processStepUids);

                    }
                }

                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method ended :");

                return true;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
        }

        private List<long> GetProcessStepUIds(bool isLowPriorityTask)
        {
            List<long> processStepUids;
            if (!isLowPriorityTask)
                processStepUids = _dalProcessStepAttributesRepository.GetProcessStepAttributesUIds();
            else
                processStepUids = _dalProcessStepAttributesRepository.GetLowPriorityProcessStepAttributesUIds();
            return processStepUids;
        }

        private void DeleteAppZoneServerPathImageDocument(bool isLowPriorityTask, List<long> processStepUids)
        {
            try
            {
                IEnumerable<ProcessStepAttributes> processStepAttributes = GetProcessStepAttributesForSaveTask(isLowPriorityTask, processStepUids);

                if (processStepAttributes != null && processStepAttributes.Count() > 0)
                {
                    foreach (var processStepAttribute in processStepAttributes)
                    {
                        var tempProcessStepAttributes = processStepAttributes;
                        tempProcessStepAttributes = tempProcessStepAttributes.Where(x => x.ProcessStepUId == processStepAttribute.ProcessStepUId);

                        if (tempProcessStepAttributes.All(x => x.ProcessStepUId == processStepAttribute.ProcessStepUId &&
                        x.ProcessStep.StatusUId == (byte)StatusEnum.SaveDocAttr))
                        {
                            var processCustDoc = _dalProcessCustomerDocumentRepository.GetCustomerInfoFromProcCustDocUId(processStepAttribute.ProcessStep.ProcessCustomerDocumentUId);
                            if (processCustDoc != null && !string.IsNullOrEmpty(processCustDoc.DocumentPath))
                            {
                                if (System.IO.Directory.Exists(processCustDoc.DocumentPath))
                                {
                                    DeleteDirectory(processCustDoc.DocumentPath);
                                    LoggingHelper.LogInformation(MethodBase.GetCurrentMethod().Name + "Local Image folder and its files deleted from path: " + processCustDoc.DocumentPath);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        private IEnumerable<ProcessStepAttributes> GetProcessStepAttributesForSaveTask(bool isLowPriorityTask, List<long> processStepUids)
        {
            try
            {
                IEnumerable<ProcessStepAttributes> processStepAttributes;
                if (!isLowPriorityTask)
                    processStepAttributes = _dalProcessStepAttributesRepository.GetPendingProcessStepAttributes(processStepUids);
                else
                    processStepAttributes = _dalProcessStepAttributesRepository.GetLowPriorityProcessStepAttributes(processStepUids);
                return processStepAttributes;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        private void UpdateProcessStepStaus(List<long> processStepUids, bool isLowPriorityTask)
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;
            ProcessStep _processStep = null;
            foreach (var processStepUId in processStepUids)
            {
                try
                {
                    isExceptionOccur = false;
                    _processStep = _dalProcessStepRepository.GetProcessStepByUId(processStepUId);
                    if (_processStep != null && _processStep.StatusUId != (byte)StatusEnum.Failed)
                    {
                        if (isLowPriorityTask)
                            _processStep.StatusUId = (byte)StatusEnum.SaveDocAttr;
                        else
                            _processStep.StatusUId = _dalProcessStepAttributesRepository.IsAllMatchedProcessStepAttributes(processStepUId) ? (byte)StatusEnum.SaveDocAttr : (byte)StatusEnum.PendingLowTask;

                        _processStep.StepUId = (byte)StepMasterEnum.SaveDocumentAttribute;

                        if (_processStep.StatusUId == (byte)StatusEnum.SaveDocAttr)
                            _processStep.CompletedOn = DateTime.Now;

                        _dalProcessStepRepository.UpdateProcessStep(_processStep);
                        _iUnitOfWork.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    isExceptionOccur = true;
                    errorMessage = ex.GetErrorMessage();
                    LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                }
                finally
                {
                    try
                    {
                        if (isExceptionOccur)
                        {
                            UpdateProcessStepWithFailedStatus(_processStep.UId, errorMessage, (byte)StepMasterEnum.SaveDocumentAttribute);
                        }
                    }
                    catch (Exception ex)
                    {
                        LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                    }

                }
            }
        }

        private void AddProcessCustomerDocumentAttribute(ProcessStepAttributes processStepAttribute)
        {
            try
            {
                CustomerDocumentAttribute customerDocumentAttribute = new CustomerDocumentAttribute();
                var processCustDoc = _dalProcessCustomerDocumentRepository.GetCustomerInfoFromProcCustDocUId(processStepAttribute.ProcessStep.ProcessCustomerDocumentUId);
                if (processCustDoc != null)
                {
                    customerDocumentAttribute.CustomerUId = processCustDoc.ProcessCustomer.CustomerUId;
                    customerDocumentAttribute.ProcessStepUId = processStepAttribute.ProcessStepUId;
                    customerDocumentAttribute.AttributeUId = processStepAttribute.AttributeUId;

                    customerDocumentAttribute.Value = processStepAttribute.Value;
                    customerDocumentAttribute.StatusUId = processStepAttribute.StatusUId;
                    customerDocumentAttribute.IsLowPriorityParserTaskRan = processStepAttribute.IsLowPriorityParserTaskRan;
                    customerDocumentAttribute.UpdatedOn = DateTime.Now;
                    _dalCustomerDocumentAttributeRepository.AddCustomerDocumentAttribute(customerDocumentAttribute);
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        private void UpdateProcessCustomerDocumentAttribute(ProcessStepAttributes processStepAttribute)
        {
            try
            {
                var processCustDoc = _dalProcessCustomerDocumentRepository.GetCustomerInfoFromProcCustDocUId(processStepAttribute.ProcessStep.ProcessCustomerDocumentUId);

                var customerDocumentAttribute = _dalCustomerDocumentAttributeRepository.GetCustomerDocumentAttributeByProcessStepAndCustUId(processStepAttribute, processCustDoc.ProcessCustomer.CustomerUId);
                if (customerDocumentAttribute != null && processCustDoc != null)
                {
                    customerDocumentAttribute.CustomerUId = processCustDoc.ProcessCustomer.CustomerUId;
                    customerDocumentAttribute.ProcessStepUId = processStepAttribute.ProcessStepUId;
                    customerDocumentAttribute.AttributeUId = processStepAttribute.AttributeUId;

                    customerDocumentAttribute.Value = processStepAttribute.Value;
                    customerDocumentAttribute.StatusUId = processStepAttribute.StatusUId;
                    customerDocumentAttribute.IsLowPriorityParserTaskRan = processStepAttribute.IsLowPriorityParserTaskRan;
                    customerDocumentAttribute.UpdatedOn = DateTime.Now;
                    _dalCustomerDocumentAttributeRepository.UpdateCustomerDocumentAttribute(customerDocumentAttribute);
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        public void UpdateProcessStepAttribute(ProcessStepAttributes processStepAttribute)
        {
            try
            {
                var _processStepAttribute = _dalProcessStepAttributesRepository.GetProcessStepAttributesByUId(processStepAttribute.UId);
                if (_processStepAttribute != null)
                {
                    _processStepAttribute.UpdatedOn = DateTime.Now;
                    _processStepAttribute.IsMovedToCustDocAtrbTable = true;
                    _dalProcessStepAttributesRepository.UpdateProcessStepAttribute(_processStepAttribute);
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        /// <summary>
        /// This method takes Glared Passed Status ProcessStep records for Non Low Priotity task  
        /// and PendingLowTask Status ProcessStep records for Low Priotity task 
        /// Run high and low priority strategies for Passport / EIDA
        /// and save the matched, non matched and partial matched attributes in ProcessStepAttributes table
        /// an update the ProcessStep record with PassportParser / LowPassportParser / EIDAParser / LowEIDAParser status        
        /// </summary>
        /// <param name="documentTypeEnum"></param>
        /// <param name="isLowPriority"></param>
        /// <returns></returns>
        public bool ParseGlarePassedImages(DocumentTypeEnum documentTypeEnum, bool isLowPriority = false)
        {
            try
            {
                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method started :");

                IEnumerable<ProcessStep> processStepCustDetails;

                // Get Glared Passed Status ProcessStep records for Non Low Priotity task  
                // Get PendingLowTask Status ProcessStep records for Low Priotity task
                if (!isLowPriority)
                    processStepCustDetails = _dalProcessStepRepository.GetGlarePassedProcessStepDetails((byte)documentTypeEnum);
                else
                    processStepCustDetails = _dalProcessStepRepository.GetDocumentParsedProcessStepDetails((byte)documentTypeEnum);

                foreach (var custDetail in processStepCustDetails)
                {
                    var processCust = _dalProcessCustomerRepository.GetProcessCustomerByUId(custDetail.ProcessCustomerDocument.ProcessCustomerUId);

                    // Run strategies for Passport / EIDA document records and save in ProcessStepAttributes table
                    if (processCust != null)
                        ParseDocumentDetails(custDetail, processCust.CustomerUId, isLowPriority);
                }

                LoggingHelper.LogDebug(MethodBase.GetCurrentMethod().Name + " method ended :");

                return true;

            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }

        }


        private void ParseDocumentDetails(ProcessStep processStep, long custId, bool isLowPriority)
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;
            byte? documentTypeUId = processStep.ProcessCustomerDocument.EDMSDocument.DocumentTypeUid;

            try
            {
                string imagePath = processStep.ProcessCustomerDocument.DocumentPath;

                long processStepUId = processStep.UId;
                long? processCustDocUid = processStep.ProcessCustomerDocumentUId;

                // initalize OCR related classes
                var image = System.IO.Path.GetFileNameWithoutExtension(imagePath);
                var ocr = new ImageToTextReaderTessaractMICR();
                var imageProcessor = new ImageProcessor();

                IEnumerable<CustomerAttribute> actualData;

                actualData = _dalCustomerAttributeRepository.GetCustomerAttributeDetails(custId, documentTypeUId);

                //Take actual data which are having Not Matched status for Low Priority task
                if (isLowPriority)
                {
                    List<byte> processedStepAttributeUids = new List<byte>();
                    var processStepAttributes = _dalProcessStepAttributesRepository.GetProcessStepAttributesByProcessStepUId(processStepUId, true);
                    processedStepAttributeUids = processStepAttributes.Select(x => x.AttributeUId).ToList();
                    actualData = actualData.Where(x => processedStepAttributeUids.Any(y => x.AttributeUId == y));
                }


                if (actualData.Count() > 0)
                {
                    Dictionary<byte, string> matchDict = new Dictionary<byte, string>();
                    Dictionary<byte, string> nonMatchDict = new Dictionary<byte, string>();
                    Dictionary<string, string> nameDict = new Dictionary<string, string>();
                    Dictionary<byte, string> partialDict = new Dictionary<byte, string>();

                    var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                   .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();

                    var resultDict = new Dictionary<string, string>();
                    List<Type> strategiesFinal = new List<Type>();
                    strategiesFinal = SortStrategies(strategies, strategiesFinal, documentTypeUId, isLowPriority);
                    List<string> nonMatchingNodeLst = new List<string>();

                    // Execute Passport / EIDA Strategies one by one
                    foreach (var strategy in strategiesFinal)
                    {
                        isExceptionOccur = false;

                        // filter actual data having only NonMatch attributes (if any)
                        if (matchDict.Count > 0)
                        {
                            actualData = actualData.Where(x => !matchDict.Any(y => x.AttributeUId == y.Key));
                        }

                        string TempPath = GetTempPath(documentTypeUId, imagePath, strategy.Name);

                        if (System.IO.Directory.Exists(TempPath))
                        {
                            System.IO.Directory.Delete(TempPath, true);
                        }

                        var strategySpecific = (IDocumentParserStrategy)Activator.CreateInstance(strategy, TempPath, imageProcessor, ocr);

                        string[] file = System.IO.Directory.GetFiles(imagePath);

                        string fileName = string.Empty;
                        if (file != null && file.Count() > 0)
                            fileName = System.IO.Path.GetFileName(file[0]);

                        string finalImagePath = imagePath + @"\" + fileName;

                        // Execute the specific strategy and give the result
                        var resultSpecific = strategySpecific.Execute(finalImagePath);

                        resultDict.Clear();
                        foreach (var resultSpec in resultSpecific.Values)
                        {
                            resultDict.Add(resultSpec.Key, resultSpec.Value);
                        }

                        StrategyResult result = new StrategyResult();
                        result.Values = resultDict;

                        // Match attribute logic for Passport / EIDA image
                        foreach (var data in actualData)
                        {
                            AttributeMasterEnum customerAttribute = (AttributeMasterEnum)data.AttributeUId;
                            var valueToCompare = data.Value;                            
                            IEnumerable<KeyValuePair<string, string>> extractedValuesLst;

                            switch (customerAttribute)
                            {
                                case AttributeMasterEnum.DateOfBirth:
                                case AttributeMasterEnum.Passport_DateOfExpiry:
                                case AttributeMasterEnum.EIDA_DateOfExpiry:
                                    DateTime date = DateTime.Today;
                                    bool isMainNodeAdded = false;
                                    extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 12);
                                    if (extractedValuesLst.Any())
                                    {
                                        foreach (var extractedVal in extractedValuesLst)
                                        {
                                            string dateExtract = MRZDocumentDateHelper.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                                            if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                                            {
                                                continue;
                                            }
                                            if (Convert.ToDateTime(valueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                                            {
                                                //matched   
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }
                                        }
                                    }

                                    if (!isMainNodeAdded)
                                    {
                                        extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Contains("<"));
                                        var matchingVals = extractedValuesLst.Where(x => x.Value.Replace(@" ", "").Contains(Convert.ToDateTime(valueToCompare).ToString("yyMMdd"))).FirstOrDefault();

                                        if (!(string.IsNullOrEmpty(matchingVals.Key)))
                                        {
                                            isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                            break;
                                        }

                                        if (!isMainNodeAdded)
                                        {
                                            extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]"));
                                            matchingVals = extractedValuesLst.Where(x => x.Value.Replace(@" ", "").Contains(Convert.ToDateTime(valueToCompare).ToString("yyMMdd"))).FirstOrDefault();
                                            if (!(string.IsNullOrEmpty(matchingVals.Key)))
                                            {
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                case AttributeMasterEnum.EmiratesId:
                                    isMainNodeAdded = false;
                                    extractedValuesLst = null;
                                    extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                                    if (extractedValuesLst.Any())
                                    {
                                        foreach (var extractedVal in extractedValuesLst)
                                        {
                                            string emiratesIdExtract = MRZDocumentEIDAHelper.FormatEmiratesId(extractedVal.Value.ToUpper().Replace(@" ", ""));

                                            if (valueToCompare.Equals(emiratesIdExtract))
                                            {
                                                //matched   
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }

                                            else if (valueToCompare.Replace("-", "").Equals(emiratesIdExtract.Replace("-", "")))
                                            {
                                                //matched         
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }
                                            else
                                            {
                                                var distance = LevenshteinDistance.Compute(valueToCompare.Replace("-", ""), emiratesIdExtract.Replace("-", ""));
                                                if (distance < 4 || distance > 10)
                                                {
                                                    var extractedValuesLstMRZ = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                                                    if (extractedValuesLstMRZ.Any())
                                                    {
                                                        var matchVals = extractedValuesLstMRZ.Where(x => x.Value.Replace(" ", "").Trim().Contains(valueToCompare.Replace("-", "").Substring(3)));
                                                        if (!string.IsNullOrEmpty(matchVals.Select(x => x.Value).FirstOrDefault()))
                                                        {
                                                            //matched                                                            
                                                            isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    break;

                                case AttributeMasterEnum.PassportNo:
                                    extractedValuesLst = null;
                                    extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length > 6);
                                    isMainNodeAdded = false;

                                    if (extractedValuesLst.Any())
                                    {
                                        foreach (var extractedVal in extractedValuesLst)
                                        {
                                            if (valueToCompare.ToUpper().Equals(extractedVal.Value.ToUpper().Replace(@" ", "")))
                                            {
                                                //matched    
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }
                                        }
                                    }

                                    if (!isMainNodeAdded)
                                    {
                                        var extractedValuesList = result.Values.Where(v => v.Value.Contains("<"));
                                        var matchingvalue = extractedValuesList.Where(x => x.Value.Contains(valueToCompare)).FirstOrDefault();

                                        if (!(string.IsNullOrEmpty(matchingvalue.Key)))
                                        {
                                            //matched    
                                            isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                            break;
                                        }
                                    }
                                    break;

                                case AttributeMasterEnum.Nationality:
                                    var matchingvalues = result.Values.Where(x => x.Value.Replace(" ", "").Trim().Contains(valueToCompare)).FirstOrDefault();
                                    isMainNodeAdded = false;
                                    if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                                    {
                                        //matched    
                                        isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                        break;
                                    }

                                    if (!isMainNodeAdded)
                                    {
                                        string nationalityCode = _dalCountryMaster.GetNationalityCode(valueToCompare);
                                        if (!string.IsNullOrEmpty(nationalityCode))
                                        {
                                            var extractedValuesList = result.Values.Where(v => v.Value.Contains("<"));

                                            var matchingvalue = extractedValuesList.Where(x => x.Value.Contains(nationalityCode)).FirstOrDefault();

                                            if (!(string.IsNullOrEmpty(matchingvalue.Key)))
                                            {
                                                //matched    
                                                isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                                break;
                                            }
                                        }
                                    }
                                    break;

                                case AttributeMasterEnum.Gender:
                                    var matchvalues = result.Values.Where(x => x.Value.Contains(AppConstants.Gender) && x.Value.Contains(valueToCompare)).FirstOrDefault();
                                    isMainNodeAdded = false;
                                    if (!(string.IsNullOrEmpty(matchvalues.Key)))
                                    {
                                        //matched    
                                        isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                        break;
                                    }
                                    if (!isMainNodeAdded)
                                    {
                                        var matchingval = result.Values.Where(x => x.Value.ToUpper().Equals(valueToCompare.ToUpper())).FirstOrDefault();
                                        if (!(string.IsNullOrEmpty(matchingval.Key)))
                                        {
                                            //matched    
                                            isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                            break;
                                        }
                                    }

                                    var dateOfExpiry = documentTypeUId == (byte)DocumentTypeEnum.Passport ? AttributeMasterEnum.Passport_DateOfExpiry : AttributeMasterEnum.EIDA_DateOfExpiry;
                                    string expirydate = actualData.Where(x => x.AttributeUId == (byte)dateOfExpiry).Select(x => x.Value).FirstOrDefault();
                                    string genderString = !string.IsNullOrEmpty(expirydate) ? valueToCompare + Convert.ToDateTime(expirydate).ToString("yyMMdd") : string.Empty;

                                    if (!isMainNodeAdded)
                                    {
                                        var matchingval = result.Values.Where(x => x.Value.Replace(@" ", "").Contains("<") && x.Value.Contains(genderString)).FirstOrDefault();
                                        if (!(string.IsNullOrEmpty(matchingval.Key)))
                                        {
                                            //matched    
                                            isMainNodeAdded = MatchedEntry(data.AttributeUId, valueToCompare, matchDict);
                                            break;
                                        }
                                    }
                                    break;

                                case AttributeMasterEnum.FullName:
                                    var actualNameLst = data.Value.Split(' ').ToList();

                                    if (nameDict.Count == 0)
                                    {
                                        foreach (var actualName in actualNameLst)
                                        {
                                            if (nameDict.Where(x => (x.Key.Equals(actualName.ToUpper()))) == null ||
                                             nameDict.Where(x => (x.Key.Equals(actualName.ToUpper()))).Count() == 0)
                                                nameDict.Add(actualName.ToUpper(), string.Empty);
                                        }
                                    }

                                    var extractNamesLst = result.Values.Where(x => x.Value.Contains("<")).Select(x => x).ToList();
                                    if (extractNamesLst.Count > 0)
                                    {
                                        List<KeyValuePair<string, string>> extractNameArraySplit = new List<KeyValuePair<string, string>>();
                                        List<string> splittedNames = new List<string>();
                                        foreach (var name in extractNamesLst)
                                        {
                                            if (name.Value[0] == '<')
                                            {
                                                splittedNames = name.Value.Substring(1).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                            }
                                            else
                                            {
                                                if (name.Value.Length > 6 && documentTypeUId == (long)DocumentTypeEnum.Passport)
                                                    splittedNames = name.Value.Substring(5).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                                                if (documentTypeUId == (long)DocumentTypeEnum.EIDA)
                                                    splittedNames = name.Value.Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                            }
                                            foreach (var nameStr in splittedNames)
                                            {
                                                var keyValPair = new KeyValuePair<string, string>(name.Key, nameStr.Replace(" ", ""));
                                                extractNameArraySplit.Add(keyValPair);
                                            }
                                        }
                                        int counter = 0;
                                        foreach (var nameValueToCompare in actualNameLst)
                                        {
                                            var matchesNames = extractNameArraySplit.Where(v => v.Value.ToUpper().Contains(nameValueToCompare.ToUpper()));
                                            if (matchesNames.Any())
                                            {
                                                var imageKeys = matchesNames.
                                                                GroupBy(o => new { o.Value })
                                                                .Select(o => o.FirstOrDefault());
                                                foreach (var imgKey in imageKeys)
                                                {
                                                    string nameVal = imgKey.Value;
                                                    var tempDict = nameDict.Where(x => nameVal.ToUpper().Contains(x.Key));
                                                    string actualkey = tempDict.Select(x => x.Key).FirstOrDefault();
                                                    nameDict[actualkey] = actualkey;
                                                }
                                            }
                                            counter++;
                                        }
                                    }

                                    if (nameDict.Count > 0 && nameDict.All(x => !string.IsNullOrEmpty(x.Value)))
                                    {
                                        if (matchDict.Where(x => (x.Key == (byte)AttributeMasterEnum.FullName)) == null ||
                                            matchDict.Where(x => (x.Key == (byte)AttributeMasterEnum.FullName)).Count() == 0)
                                        {
                                            matchDict.Add(data.AttributeUId, String.Join(" ", nameDict.Select(x => x.Value).ToList()).Trim());
                                            partialDict.Clear();
                                        }
                                    }

                                    if (nameDict.Count > 0 && !nameDict.All(x => !string.IsNullOrEmpty(x.Value)) && nameDict.Any(x => !string.IsNullOrEmpty(x.Value)))
                                    {
                                        if (partialDict.Count == 0)
                                            partialDict.Add(data.AttributeUId, String.Join(" ", nameDict.Select(x => x.Value).ToList()).Trim());

                                    }
                                    break;
                            }                           
                        }
                    }

                    byte stepUId = documentTypeUId == (byte)DocumentTypeEnum.Passport ? (byte)StepMasterEnum.PassportParser : (byte)StepMasterEnum.EIDAParser;
                    
                    // Fetch all Non Match attributes
                    nonMatchDict = GetNonMatchDictionary(custId, documentTypeUId, matchDict, partialDict, actualData);

                    var finalDict = matchDict.Union(nonMatchDict).Union(partialDict).ToDictionary(k => k.Key, v => v.Value);
                    bool isNamePartial = partialDict.Count > 0 ? true : false;

                    // Save all the attributes in ProcessStepAttributes table and update ProcessStep table with required status
                    SaveProcessStepAttributeDetails(finalDict, processStepUId, processCustDocUid, stepUId, documentTypeUId, isLowPriority, isNamePartial);
                }
            }

            catch (Exception ex)
            {
                isExceptionOccur = true;
                errorMessage = ex.GetErrorMessage();
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
            finally
            {
                try
                {
                    if (isExceptionOccur)
                    {
                        byte stepUId = documentTypeUId == (byte)DocumentTypeEnum.Passport ? (byte)StepMasterEnum.PassportParser : (byte)StepMasterEnum.EIDAParser;
                        UpdateProcessStepWithFailedStatus(processStep.UId, errorMessage, stepUId);
                    }
                }
                catch (Exception ex)
                {
                    LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                }

            }
        }

        private Dictionary<byte, string> GetNonMatchDictionary(long custId, byte? documentTypeUId, Dictionary<byte, string> matchDict, Dictionary<byte, string> partialDict, IEnumerable<CustomerAttribute> actualData)
        {
            Dictionary<byte, string> nonMatchDict = new Dictionary<byte, string>();

            try
            {  
                var tempDict = matchDict.Union(partialDict).ToDictionary(k => k.Key, v => v.Value);               
                List<byte> nonMatchkeys = actualData.Where(x => !tempDict.Any(y => x.AttributeUId == y.Key)).Select(x => x.AttributeUId).ToList();
                foreach (var nonMatchkey in nonMatchkeys)
                    nonMatchDict.Add(nonMatchkey, string.Empty);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
            return nonMatchDict;
        }

        private void UpdateProcessStepWithFailedStatus(long processStepUId, string errorMessage, byte stepUId)
        {
            try
            {
                var _processStep = _dalProcessStepRepository.GetProcessStepByUId(processStepUId);
                _processStep.StepUId = stepUId;
                _processStep.StatusUId = (byte)StatusEnum.Failed;
                _processStep.ErrorMessage = errorMessage;
                _processStep.CompletedOn = DateTime.Now;

                _dalProcessStepRepository.UpdateProcessStep(_processStep);

                _iUnitOfWork.SaveChanges();
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        private bool SaveProcessStepAttributeDetails(Dictionary<byte, string> finalDict, long processStepUId, long? processCustDocUid
            , byte stepUId, byte? documentTypeUId, bool isLowPriority, bool isNamePartial)
        {
            bool isExceptionOccur = false;
            string errorMessage = string.Empty;

            try
            {
                //  TODO : Have to change below line of code
                isExceptionOccur = false;                
                if (finalDict.Count > 0)
                {
                    if (!isLowPriority)
                    {
                        foreach (var item in finalDict)
                            AddProcessStepAttribute(processStepUId, isNamePartial, item);
                        _iUnitOfWork.SaveChanges();
                    }
                    else
                    {
                        foreach (var item in finalDict)
                        {
                            UpdateLowPriorityProcessStepAttribute(processStepUId, isNamePartial, item);
                        }

                        _iUnitOfWork.SaveChanges();

                        UpdateLowPriorityTaskSuccessfullyRanStatus(processStepUId);

                        _iUnitOfWork.SaveChanges();
                    }

                    byte statusUId = 0;
                    if (documentTypeUId == (byte)DocumentTypeEnum.Passport)
                        statusUId = isLowPriority ? (byte)StatusEnum.LowPassportPars : (byte)StatusEnum.PassportParser;
                    if (documentTypeUId == (byte)DocumentTypeEnum.EIDA)
                        statusUId = isLowPriority ? (byte)StatusEnum.LowEIDAPars : (byte)StatusEnum.EIDAParser;

                    var _processStep = _dalProcessStepRepository.GetProcessStepByUId(processStepUId);
                    _processStep.StepUId = stepUId;
                    _processStep.StatusUId = statusUId;
                    _processStep.CompletedOn = DateTime.Now;

                    _dalProcessStepRepository.UpdateProcessStep(_processStep);

                    _iUnitOfWork.SaveChanges();
                }

                return true;
            }
            catch (Exception ex)
            {
                isExceptionOccur = true;
                errorMessage = ex.GetErrorMessage();
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
            finally
            {
                try
                {
                    if (isExceptionOccur)
                    {
                        var _processStep = _dalProcessStepRepository.GetProcessStepByUId(processStepUId);
                        UpdateProcessStepWithFailedStatus(_processStep.UId, errorMessage, stepUId);
                    }
                }
                catch (Exception ex)
                {
                    LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                }

            }
        }

        public void UpdateLowPriorityTaskSuccessfullyRanStatus(long processStepUId)
        {
            try
            {
                var _processStepAttributes = _dalProcessStepAttributesRepository.GetProcessStepAttributesByProcessStepUId(processStepUId);
                if (_processStepAttributes.Count() > 0)
                {
                    foreach (ProcessStepAttributes processStepAttr in _processStepAttributes)
                    {
                        processStepAttr.IsLowPriorityParserTaskRan = true;
                        processStepAttr.UpdatedOn = DateTime.Now;
                        _dalProcessStepAttributesRepository.UpdateProcessStepAttribute(processStepAttr);
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        public void UpdateLowPriorityProcessStepAttribute(long processStepUId, bool isNamePartial, KeyValuePair<byte, string> item)
        {
            try
            {
                var _processStepAttribute = _dalProcessStepAttributesRepository.GetProcessStepAttributesByProcessStepUId(processStepUId, true);
                ProcessStepAttributes processStepAttributes = _processStepAttribute.Where(x => x.AttributeUId.ToString().Equals(item.Key)).FirstOrDefault();
                processStepAttributes.ProcessStepUId = processStepUId;
                processStepAttributes.AttributeUId = item.Key;
                processStepAttributes.Value = item.Value;
                if (isNamePartial && item.Key == (byte)AttributeMasterEnum.FullName)
                    processStepAttributes.StatusUId = (byte)StatusEnum.PartialMatched;
                else
                    processStepAttributes.StatusUId = !string.IsNullOrEmpty(item.Value) ? (byte)StatusEnum.Matched : (byte)StatusEnum.NotMatched;

                processStepAttributes.UpdatedOn = DateTime.Now;
                processStepAttributes.IsMovedToCustDocAtrbTable = false;
                processStepAttributes.IsLowPriorityParserTaskRan = true;
                _dalProcessStepAttributesRepository.UpdateProcessStepAttribute(processStepAttributes);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        private void AddProcessStepAttribute(long processStepUId, bool isNamePartial, KeyValuePair<byte, string> item)
        {
            try
            {
                ProcessStepAttributes processStepAttribute = new ProcessStepAttributes();
                processStepAttribute.ProcessStepUId = processStepUId;
                processStepAttribute.AttributeUId = item.Key;
                processStepAttribute.Value = item.Value;
                if (isNamePartial && item.Key == (byte)AttributeMasterEnum.FullName)
                    processStepAttribute.StatusUId = (byte)StatusEnum.PartialMatched;
                else
                    processStepAttribute.StatusUId = !string.IsNullOrEmpty(item.Value) ? (byte)StatusEnum.Matched : (byte)StatusEnum.NotMatched;
                processStepAttribute.IsMovedToCustDocAtrbTable = false;
                processStepAttribute.UpdatedOn = DateTime.Now;
                _dalProcessStepAttributesRepository.AddProcessStepAttribute(processStepAttribute);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }

        private List<Type> SortStrategies(List<Type> strategies, List<Type> strategiesFinal, byte? documentTypeUId, bool isLowPriority)
        {
            try
            {
                if (documentTypeUId == (byte)DocumentTypeEnum.Passport)
                {
                    strategies = strategies.Where(x => (x.Name.Contains(AppConstants.Passport))).ToList();

                    if (!isLowPriority)
                    {
                        strategiesFinal.Add(strategies.Where(x => x.Name.Equals(AppConstants.PassportMRZParserStrategyMRZOnly)).FirstOrDefault());
                        strategiesFinal.Add(strategies.Where(x => x.Name.Equals(AppConstants.PassportMRZParserStrategyDirect)).FirstOrDefault());
                    }
                    else
                    {
                        strategiesFinal.AddRange(strategies.Where(x => !(x.Name.Equals(AppConstants.PassportMRZParserStrategyMRZOnly)) &&
                        !(x.Name.Equals(AppConstants.PassportMRZParserStrategyDirect))).ToList());
                    }
                }
                if (documentTypeUId == (byte)DocumentTypeEnum.EIDA)
                {
                    strategies = strategies.Where(x => (x.Name.Contains(AppConstants.Emirates))).ToList();

                    if (!isLowPriority)
                    {
                        strategiesFinal.Add(strategies.Where(x => x.Name.Equals(AppConstants.EmiratesIdMRZParserStrategyMRZOnly)).FirstOrDefault());
                        strategiesFinal.Add(strategies.Where(x => x.Name.Equals(AppConstants.EmiratesIdMRZParserStrategyDirect)).FirstOrDefault());
                    }
                    else
                    {
                        strategiesFinal.AddRange(strategies.Where(x => !(x.Name.Equals(AppConstants.EmiratesIdMRZParserStrategyMRZOnly)) &&
                        !(x.Name.Equals(AppConstants.EmiratesIdMRZParserStrategyDirect))).ToList());
                    }
                }

                return strategiesFinal;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        private string GetTempPath(byte? docTypeUId, string imagePath, string strategyName)
        {
            try
            {
                string image = string.Empty;
                string imageType = string.Empty;

                if (docTypeUId == (byte)DocumentTypeEnum.Passport)
                    imageType = DocumentTypeEnum.Passport.GetDescription().ToString();
                if (docTypeUId == (byte)DocumentTypeEnum.EIDA)
                    imageType = DocumentTypeEnum.EIDA.GetDescription().ToString();

                if (!string.IsNullOrEmpty(imagePath))
                    image = System.IO.Path.GetFileNameWithoutExtension(imagePath);

                if (!string.IsNullOrEmpty(imagePath) && !string.IsNullOrEmpty(image))
                {
                    string ProcessingFolder = System.IO.Path.Combine(imagePath, imageType, AppConstants.Processing);
                    return System.IO.Path.Combine(ProcessingFolder, image, strategyName);
                }
                else
                    return string.Empty;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return string.Empty;
            }
        }       
 
        private static bool MatchedEntry(byte dataKey, string matchingvalue, Dictionary<byte, string> matchDict)
        {
            try
            {
                matchDict.Add(dataKey, matchingvalue);
                return true;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
        }

        private void DeleteDirectory(string target_dir)
        {
            try
            {
                string[] files = Directory.GetFiles(target_dir);
                string[] dirs = Directory.GetDirectories(target_dir);

                foreach (string file in files)
                {
                    File.SetAttributes(file, FileAttributes.Normal);
                    File.Delete(file);
                }

                foreach (string dir in dirs)
                    DeleteDirectory(dir);

                Directory.Delete(target_dir, false);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
            }
        }


    }
}
