﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface ICustomerDocumentAttributeRepository
    {
        void AddCustomerDocumentAttribute(CustomerDocumentAttribute custDocAttr);

        void UpdateCustomerDocumentAttribute(CustomerDocumentAttribute custDocAttr);
        CustomerDocumentAttribute GetCustomerDocumentAttributeByProcessStepAndCustUId(ProcessStepAttributes processStep, long custUId);
    }
}
