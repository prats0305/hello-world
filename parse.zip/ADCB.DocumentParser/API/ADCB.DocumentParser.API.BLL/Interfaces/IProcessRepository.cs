﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IProcessRepository
    {
        //long? AddProcessRepository(byte processTypeUId, byte statusUId);

        void AddProcessRepository(Process process);
       
    }
}
