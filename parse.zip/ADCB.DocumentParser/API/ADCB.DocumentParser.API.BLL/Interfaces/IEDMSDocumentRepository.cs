﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IEDMSDocumentRepository
    {
        //EDMSDocumentDTO GetInitiatedCustomersEDMSDetails(long customerUId);
        IEnumerable<EDMSDocument> GetInitiatedCustomersEDMSDetails(long? cid);

    }
}
