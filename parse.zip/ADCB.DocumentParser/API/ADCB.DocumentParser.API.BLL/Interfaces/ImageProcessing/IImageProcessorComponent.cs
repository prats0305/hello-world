﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IImageProcessorComponent
    {
        object Parameter { get; }
        string Name { get; }
        void Process(IImageToProcess imageToProcess);
    }
}
