﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IDocumentParserStrategy
    {
        StrategyResult Execute(string fileName);
    }
}
