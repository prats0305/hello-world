﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IProcessStepAttributesRepository
    {
        void AddProcessStepAttribute(ProcessStepAttributes processStepAttribute);

        IEnumerable<ProcessStepAttributes> GetPendingProcessStepAttributes(List<long> processStepUids);

        IEnumerable<ProcessStepAttributes> GetLowPriorityProcessStepAttributes(List<long> processStepUids);

        void UpdateProcessStepAttribute(ProcessStepAttributes processStepAttribute);

        ProcessStepAttributes GetProcessStepAttributesByUId(long uId);

        IEnumerable<ProcessStepAttributes> GetProcessStepAttributesByProcessStepUId(long processStepUId, bool isStatusToCheck = false);

        List<long> GetProcessStepAttributesUIds();

        List<long> GetLowPriorityProcessStepAttributesUIds();

        bool IsAllMatchedProcessStepAttributes(long processStepUId);
    }
}
