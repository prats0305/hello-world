﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IImageToProcess : IDisposable
    {
        IImageToProcess Resize(int width);

        IImageToProcess GrayScale();

        string TempFolder { get; }

        IImageToProcess WithBlackBorder(int borderWidth = 1);

        IImageToProcess WithBorder(Color colorBorder, int borderLeft = 1, int borderTop = 1, int borderBottom = 1, int borderRight = 1);
        IImageToProcess GaussianBlur();

        IImageToProcess CopyTo(IImageToProcess imageTo);

        IImageToProcess Gradient();

        IImageToProcess RemoveNoise(int iterations = 1);

        IImageToProcess MarkAreasOfInterest(IEnumerable<Rectangle> rectanglesOfInterest);

        IImageToProcess AdaptiveThreshold(AdaptiveThresholdType adaptiveThresholdType, double maxValue = 255.0,
            int blockSize = 11, double param1 = 2, ThresholdType thresholdType = ThresholdType.Binary | ThresholdType.Otsu);
        IImageToProcess Threshold(double threshold = 0.0, double maxValue = 255.0, ThresholdType thresholdType = ThresholdType.Binary | ThresholdType.Otsu);

        IImageToProcess Deskew(bool crop, IColor color = null);



        IImageToProcess DeskewMax(bool crop, IColor color = null);

        IImageToProcess HorizontalConnected(int horzSize = 19);

        IEnumerable<Rectangle> FindAreasOfInterest(Func<Rectangle, bool> filter);

        List<IImageToProcess> ExtractAreasOfInterest(IEnumerable<Rectangle> rectanglesOfInterest);

        void AddInternalImage(IImageToProcess image);

        IImageToProcess Save(string fileName, bool debug = false);
    }
}
