﻿using ADCB.DocumentParser.Common.Helper;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tesseract;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{ 
    public interface IImageToTextReader : IDisposable
    {
        string Read(string fileName);
    }    
}
