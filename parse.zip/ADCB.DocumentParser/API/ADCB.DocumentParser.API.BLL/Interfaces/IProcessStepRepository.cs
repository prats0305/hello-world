﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface IProcessStepRepository
    {
        void AddProcessStep(ProcessStep processStep);
        
        void UpdateProcessStep(ProcessStep processStep);

        IEnumerable<ProcessStep> GetGlarePassedProcessStepDetails(byte docTypeUId);

        IEnumerable<ProcessStep> GetDocumentParsedProcessStepDetails(byte docTypeUId);

        ProcessStep GetProcessStepByUId(long processStepUId);

        IEnumerable<ProcessStep> GetSaveDocAttrStatusProcessStepDetails();
    }
}
