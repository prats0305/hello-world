﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.Interfaces
{
    public interface ICustomerAttributeRepository
    {
        IEnumerable<CustomerAttribute> GetCustomerAttributeDetails(long custUId, byte? docTypeUId);
    }
}
