﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class ThresholdImageProcessComponent : ImageProcessorDecoratorComponent
    {
        public ThresholdImageProcessComponent(IImageProcessorComponent imageProcessor, string key) : base(imageProcessor, key)
        {
        }

        public override object Parameter
        {
            get
            {
                return new ThresholdImageProcessComponentParameter();
            }
        }

        public override string Name => "GradientImageProcessComponent";

        protected override IImageToProcess process(IImageToProcess imageToProcess)
        {
            return imageToProcess.Threshold().Save($"{key}--threshold");
        }
    }

    public class ThresholdImageProcessComponentParameter
    {
        public decimal Threshold { get; set; }
    }
}
