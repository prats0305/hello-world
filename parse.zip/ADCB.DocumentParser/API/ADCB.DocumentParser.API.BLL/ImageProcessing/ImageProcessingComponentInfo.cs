﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    [Serializable]
    public class ImageProcessingComponentInfo
    {
        public string ComponentName { get; set; }
    }

    public static class ImageProcessingComponentSerializationHelper
    {
        public static void Serialize(this List<ImageProcessingComponentInfo> components, string fileName)
        {
            XmlSerializer x = new XmlSerializer(typeof(List<ImageProcessingComponentInfo>));
            using (TextWriter writer = new StreamWriter(fileName))
            {
                x.Serialize(writer, components);
            }
        }

        public static void Deserialize(this List<ImageProcessingComponentInfo> components, string fileName)
        {
            XmlSerializer x = new XmlSerializer(typeof(List<ImageProcessingComponentInfo>));
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                using (TextReader reader = new StreamReader(fs))
                {
                    var deserialized = (List<ImageProcessingComponentInfo>)x.Deserialize(reader);
                    components.AddRange(deserialized);
                }
            }
        }

        public static string Serialize(this object param)
        {
            XmlSerializer x = new XmlSerializer(param.GetType());
            using (StringWriter writer = new StringWriter())
            {
                x.Serialize(writer, param);
                return writer.ToString();
            }
        }

        public static object Deserialize(this Type type, string fileName)
        {
            XmlSerializer x = new XmlSerializer(type);
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                using (TextReader reader = new StreamReader(fs))
                {
                    var deserialized = x.Deserialize(reader);
                    return deserialized;
                }
            }
        }
    }
}
