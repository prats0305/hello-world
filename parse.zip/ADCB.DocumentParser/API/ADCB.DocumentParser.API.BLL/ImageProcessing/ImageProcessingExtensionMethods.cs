﻿using ADCB.DocumentParser.API.BLL.Interfaces;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public static class ImageProcessingExtensionMethods
    {
        public static IEnumerable<IImageToProcess> DeskewAll(this IEnumerable<IImageToProcess> images, bool crop = true)
        {
            foreach (var image in images)
            {
                yield return image.Deskew(crop);
            }
        }
        public static IEnumerable<IImageToProcess> Each(this IEnumerable<IImageToProcess> images, Func<IImageToProcess, IImageToProcess> action)
        {
            foreach (var image in images)
            {
                yield return action(image);
            }
        }

        public static List<string> SaveAll(this IEnumerable<IImageToProcess> images, Func<int, IImageToProcess, string> getFileName)
        {
            List<string> fileNames = new List<string>();

            var imagesToSave = images.ToList();
            foreach (var image in imagesToSave)
            {
                var fileName = getFileName(imagesToSave.IndexOf(image), image);

                // fileName = System.IO.Path.Combine(image.TempFolder, fileName+".jpeg");


                image.Save(fileName);

                fileNames.Add(fileName);
            }
            return fileNames;
        }

        public static double AspectRatio(this Rectangle rectangle)
        {
            return (double)rectangle.Width / (double)rectangle.Height;
        }
    }
}
