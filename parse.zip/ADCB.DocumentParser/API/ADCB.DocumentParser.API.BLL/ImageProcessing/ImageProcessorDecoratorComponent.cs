﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;


namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public abstract class ImageProcessorDecoratorComponent : IImageProcessorComponent
    {
        private readonly IImageProcessorComponent imageProcessor;
        protected readonly string key;

        public ImageProcessorDecoratorComponent(IImageProcessorComponent imageProcessor, string key)
        {
            this.imageProcessor = imageProcessor;
            this.key = key;
        }

        public abstract string Name { get; }

        public virtual object Parameter
        {
            get { return null; }
        }

        public void Process(IImageToProcess imageToProcess)
        {
            var imageProcessed = process(imageToProcess);

            if(imageProcessor != null)
            {
                imageProcessor.Process(imageProcessed);
            }
        }

        protected abstract IImageToProcess process(IImageToProcess imageToProcess);
    }
}
