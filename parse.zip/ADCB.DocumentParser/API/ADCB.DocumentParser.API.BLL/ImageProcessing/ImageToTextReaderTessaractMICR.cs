﻿using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tesseract;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class ImageToTextReaderTessaractMICR : IImageToTextReader
    {
        TesseractEngine engine;
        bool disposed = false;

        public ImageToTextReaderTessaractMICR()
        {
            var tessDataFolder = AppConfigHelper.TesseractFolder;

            engine = new TesseractEngine(tessDataFolder, AppConfigHelper.TesseractLanguage, EngineMode.TesseractOnly);
            initTessaract(engine);
        }

        private static void initTessaract(TesseractEngine engine)
        {
            engine.SetVariable("tessedit_char_whitelist", AppConfigHelper.TesseractChars);
            engine.SetVariable("save_best_choices", AppConfigHelper.TesseractBestChoices);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);//no need of finalization
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
            {
                return;
            }
            if (disposing)
            {
                engine.Dispose();
            }
            disposed = true;
        }

        public string Read(string fileName)
        {
            using (var img = Pix.LoadFromFile(fileName))
            using (var page = engine.Process(img))
            {
                var text = page.GetText();
                return text.Trim();
            }
        }
    }
}
