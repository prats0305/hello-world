﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class GrayScaleImageProcessComponent : ImageProcessorDecoratorComponent
    {
        public GrayScaleImageProcessComponent(IImageProcessorComponent imageProcessor, string key) : base(imageProcessor, key)
        {
        }

        public override string Name => "GrayScaleImageProcess";

        protected override IImageToProcess process(IImageToProcess imageToProcess)
        {
            return imageToProcess.GrayScale().Save($"{key}--gray");
        }
    }
}
