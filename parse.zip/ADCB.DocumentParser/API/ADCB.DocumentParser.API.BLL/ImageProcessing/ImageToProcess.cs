﻿using ADCB.DocumentParser.API.BLL.Interfaces;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class ImageToProcess<TColor, TDepth> : IImageToProcess
           where TColor : struct, global::Emgu.CV.IColor
           where TDepth : new()
    {
        Image<TColor, TDepth> _ImageOpenCV;
        Mat _Mat;
        List<IImageToProcess> _InternalImages = new List<IImageToProcess>();
        bool disposed = false;
        private readonly string tempFolder;

        public string TempFolder
        {
            get { return tempFolder; }
        }

        public ImageToProcess(string fileName, string tempFolder)
        {
            _ImageOpenCV = new Image<TColor, TDepth>(fileName);
            this.tempFolder = tempFolder;
        }



        public ImageToProcess(IImageToProcess parentImage, Image<TColor, TDepth> imageOpenCV, string tempFolder)
        {
            _ImageOpenCV = imageOpenCV;
            this.tempFolder = tempFolder;
            if (parentImage != null)
            {
                parentImage.AddInternalImage(this);
            }
        }

        public ImageToProcess(IImageToProcess parentImage, Mat matOpenCV, string tempFolder)
        {
            _Mat = matOpenCV;
            this.tempFolder = tempFolder;
            if (parentImage != null)
            {
                parentImage.AddInternalImage(this);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);//no need of finalization
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
            {
                return;
            }
            if (disposing)
            {
                foreach (var image in _InternalImages)
                {
                    image.Dispose();
                }
                if (_ImageOpenCV != null)
                {
                    _ImageOpenCV.Dispose();
                }
                if (_Mat != null)
                {
                    _Mat.Dispose();
                }
            }
            disposed = true;
        }
        public IImageToProcess Resize(int width)
        {
            if (_Mat != null)
            {
                if (_Mat.Width >= width)
                {

                    var imgGray = _Mat.ToImage<Gray, byte>().Resize(width, _Mat.Height, Inter.Area, true);
                    return new ImageToProcess<Gray, byte>(this, imgGray, tempFolder);
                }
                else
                {
                    return this;
                }
            }
            else
            {
                if (_ImageOpenCV.Width >= width)
                {
                    var imgGray = _ImageOpenCV.Resize(width, _Mat.Height, Inter.Area, true);
                    return new ImageToProcess<TColor, TDepth>(this, imgGray, tempFolder);
                }
                else { return this; }
            }
        }

        public IImageToProcess GrayScale()
        {
            if (_Mat != null)
            {
                var imgGray = _Mat.ToImage<Gray, byte>().Convert<Gray, byte>();
                return new ImageToProcess<Gray, byte>(this, imgGray, tempFolder);
            }
            else
            {
                var imgGray = _ImageOpenCV.Convert<Gray, byte>();
                return new ImageToProcess<Gray, byte>(this, imgGray, tempFolder);
            }
        }

        public IImageToProcess WithBlackBorder(int borderWidth = 1)
        {
            var imgThreshold = new Mat();
            if (_Mat != null)
            {
                CvInvoke.CopyMakeBorder(_Mat, imgThreshold, borderWidth, borderWidth, borderWidth, borderWidth, BorderType.Constant, new MCvScalar(0));
            }
            else
            {
                CvInvoke.CopyMakeBorder(_ImageOpenCV, imgThreshold, borderWidth, borderWidth, borderWidth, borderWidth, BorderType.Constant, new MCvScalar(0));
            }

            return new ImageToProcess<TColor, TDepth>(this, imgThreshold, tempFolder);
        }

        public IImageToProcess WithBorder(Color colorBorder, int borderLeft = 1, int borderTop = 1, int borderBottom = 1, int borderRight = 1)
        {
            var imgThreshold = new Mat();
            if (_Mat != null)
            {
                CvInvoke.CopyMakeBorder(_Mat, imgThreshold, borderTop, borderBottom, borderLeft, borderRight, BorderType.Constant, new Bgr(colorBorder).MCvScalar);
            }
            else
            {
                CvInvoke.CopyMakeBorder(_ImageOpenCV, imgThreshold, borderTop, borderBottom, borderLeft, borderRight, BorderType.Constant, new Bgr(colorBorder).MCvScalar);
            }

            return new ImageToProcess<TColor, TDepth>(this, imgThreshold, tempFolder);
        }

        public IImageToProcess Threshold(double threshold = 0.0, double maxValue = 255.0, ThresholdType thresholdType = ThresholdType.Binary | ThresholdType.Otsu)
        {
            var imgThreshold = new Mat();
            if (_Mat != null)
            {
                CvInvoke.Threshold(_Mat, imgThreshold, threshold, maxValue, thresholdType);
            }
            else
            {
                CvInvoke.Threshold(_ImageOpenCV, imgThreshold, threshold, maxValue, thresholdType);
            }
            return new ImageToProcess<TColor, TDepth>(this, imgThreshold, tempFolder);
        }


        public IImageToProcess AdaptiveThreshold(AdaptiveThresholdType adaptiveThresholdType, double maxValue = 255.0,
            int blockSize = 11, double param1 = 2,
            ThresholdType thresholdType = ThresholdType.Binary | ThresholdType.Otsu)
        {
            var imgThreshold = new Mat();
            if (_Mat != null)
            {
                CvInvoke.AdaptiveThreshold(_Mat, imgThreshold, maxValue, adaptiveThresholdType, thresholdType, blockSize, param1);
            }
            else
            {
                CvInvoke.AdaptiveThreshold(_ImageOpenCV, imgThreshold, maxValue, adaptiveThresholdType, thresholdType, blockSize, param1);
            }
            return new ImageToProcess<TColor, TDepth>(this, imgThreshold, tempFolder);
        }


        public IImageToProcess Gradient()
        {
            var imgGradient = new Mat();
            var structuringElement = CvInvoke.GetStructuringElement(ElementShape.Rectangle, new Size(3, 3),
                 new Point(-1, -1));

            if (_ImageOpenCV != null)
            {
                CvInvoke.MorphologyEx(_ImageOpenCV, imgGradient, MorphOp.Gradient, structuringElement,
                    new Point(-1, -1), 1, BorderType.Default, new MCvScalar());
            }
            else
            {
                CvInvoke.MorphologyEx(_Mat, imgGradient, MorphOp.Gradient, structuringElement,
                    new Point(-1, -1), 1, BorderType.Default, new MCvScalar());
            }

            return new ImageToProcess<Gray, byte>(this, imgGradient, tempFolder);
        }

        public IImageToProcess Save(string fileName, bool debug = false)
        {
            if (string.IsNullOrEmpty(tempFolder))
            {
                throw new Exception("Temp folder is not defined");
            }

            fileName = System.IO.Path.Combine(tempFolder, fileName + ".jpeg");

            if (_ImageOpenCV == null)
            {
                _Mat.Save(fileName);
            }
            else
            {
                _ImageOpenCV.Save(fileName);
            }
            return this;
        }


        public void AddInternalImage(IImageToProcess image)
        {
            _InternalImages.Add(image);
        }

        private IInputArray InputImage
        {
            get
            {
                if (_ImageOpenCV != null)
                {
                    return _ImageOpenCV;
                }
                return _Mat;
            }
        }

        public IImageToProcess HorizontalConnected(int horzSize = 19)
        {
            Mat imgConnected = new Mat();
            var horzStrucELem = CvInvoke.GetStructuringElement(ElementShape.Rectangle, new Size(horzSize, 1), new Point(-1, -1));
            CvInvoke.MorphologyEx(InputImage, imgConnected, MorphOp.Close, horzStrucELem, new Point(-1, -1), 1, BorderType.Default, new MCvScalar());
            return new ImageToProcess<Gray, byte>(this, imgConnected, tempFolder);
        }

        public List<IImageToProcess> ExtractAreasOfInterest(IEnumerable<Rectangle> rectanglesOfInterest)
        {
            var imagesToProcess = new List<IImageToProcess>();

            foreach (var rect in rectanglesOfInterest)
            {
                if (_ImageOpenCV != null)
                {
                    imagesToProcess.Add(new ImageToProcess<TColor, TDepth>(this, _ImageOpenCV.Copy(rect), tempFolder));
                }
                if (_Mat != null)
                {
                    imagesToProcess.Add(new ImageToProcess<TColor, TDepth>(this, _Mat.ToImage<TColor, TDepth>().Copy(rect), tempFolder));
                }
            }
            return imagesToProcess;
        }

        public IEnumerable<Rectangle> FindAreasOfInterest(Func<Rectangle, bool> filter)
        {
            VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint();
            Mat hierarchy = new Mat();
            Mat imgContours = null;
            if (_Mat != null)
            {
                imgContours = new Mat(_Mat.Height, _Mat.Width, _Mat.Depth, 1);
            }
            else if (_ImageOpenCV != null)
            {
                imgContours = new Mat(_ImageOpenCV.Height, _ImageOpenCV.Width, _ImageOpenCV.Mat.Depth, 1);
            }

            //Mat imgContours = new Mat(InputImage.Height, imageGray.Width, imageGray.Mat.Depth, 1);
            imgContours.SetTo(new MCvScalar(0.0));
            CvInvoke.FindContours(CurrentImageMat, contours, hierarchy, RetrType.Tree, ChainApproxMethod.ChainApproxSimple, Point.Empty);
            var contoursArray = contours.ToArrayOfArray();
            //int i = 0;
            //i = contoursArray.Length - 10;

            List<Rectangle> areasOfInterest = new List<Rectangle>();
            for (var x = 0; x < contoursArray.Length - 1; x++)
            {
                double a = CvInvoke.ContourArea(new VectorOfPoint(contoursArray[x]));
                Rectangle r = CvInvoke.BoundingRectangle(contours[x]);
                areasOfInterest.Add(r);
            }

            if (filter != null)
            {
                return areasOfInterest.Where(rect => filter(rect)).ToList();
            }

            return areasOfInterest;
        }

        public Mat CurrentImageMat
        {
            get
            {
                if (_Mat != null)
                {
                    return _Mat;
                }
                if (_ImageOpenCV != null)
                {
                    return _ImageOpenCV.Mat;
                }
                return null;// throw new Exception("Unknown");
            }
        }


        public IImageToProcess Deskew(bool crop = true, IColor bgColor = null)
        {
            var image = _ImageOpenCV == null ? _Mat.ToImage<TColor, TDepth>() : _ImageOpenCV;

            Image<Gray, Byte> cannyEdges = image.Canny(180, 120);
            LineSegment2D[] lines = cannyEdges.HoughLinesBinary(
            1, //Distance resolution in pixel-related units
            Math.PI / 45.0, //Angle resolution measured in radians. ******
            100, //threshold
            30, //min Line width
            10 //gap between lines
            )[0]; //Get the lines from the first channel
            double[] angle = new double[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                double result = (double)(lines[i].P2.Y - lines[i].P1.Y) / (lines[i].P2.X - lines[i].P1.X);
                angle[i] = Math.Atan(result) * 57.2957795;
            }
            double avg = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                //Image<Gray, byte> imageRotateX = image.Rotate(-1 * angle[i], new Gray(255));

                //imageRotateX.Save(newFileName(folder, "deskew_"+i.ToString()+"_an_"+angle[i].ToString().Replace(".","-")));

                avg += angle[i];
            }
            avg = avg / lines.Length;
            Gray g = new Gray(255);
            if (!angle.Any())
            {
                return this;
            }
            if (bgColor == null)
            {
                bgColor = new Gray(255);
            }


            Image<TColor, TDepth> imageRotate = image.Rotate(-1 * avg, (TColor)bgColor, crop);
            return new ImageToProcess<TColor, TDepth>(this, imageRotate, tempFolder);
        }

        public IImageToProcess DeskewWithBG(TColor bgColor, bool crop = true)
        {
            var image = _ImageOpenCV == null ? _Mat.ToImage<TColor, TDepth>() : _ImageOpenCV;

            Image<Gray, Byte> cannyEdges = image.Canny(180, 120);
            LineSegment2D[] lines = cannyEdges.HoughLinesBinary(
            1, //Distance resolution in pixel-related units
            Math.PI / 45.0, //Angle resolution measured in radians. ******
            100, //threshold
            30, //min Line width
            10 //gap between lines
            )[0]; //Get the lines from the first channel
            double[] angle = new double[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                double result = (double)(lines[i].P2.Y - lines[i].P1.Y) / (lines[i].P2.X - lines[i].P1.X);
                angle[i] = Math.Atan(result) * 57.2957795;
            }
            double avg = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                //Image<Gray, byte> imageRotateX = image.Rotate(-1 * angle[i], new Gray(255));

                //imageRotateX.Save(newFileName(folder, "deskew_"+i.ToString()+"_an_"+angle[i].ToString().Replace(".","-")));

                avg += angle[i];
            }
            avg = avg / lines.Length;
            Gray g = new Gray(255);
            if (!angle.Any())
            {
                return this;
            }

            Image<TColor, TDepth> imageRotate = image.Rotate(-1 * avg, bgColor, crop);
            return new ImageToProcess<TColor, TDepth>(this, imageRotate, tempFolder);
        }


        public IImageToProcess DeskewMax(bool crop = true, IColor bgColor = null)
        {
            var image = _ImageOpenCV == null ? _Mat.ToImage<TColor, TDepth>() : _ImageOpenCV;

            Image<Gray, Byte> cannyEdges = image.Canny(180, 120);
            LineSegment2D[] lines = cannyEdges.HoughLinesBinary(
            1, //Distance resolution in pixel-related units
            Math.PI / 45.0, //Angle resolution measured in radians. ******
            100, //threshold
            30, //min Line width
            10 //gap between lines
            )[0]; //Get the lines from the first channel
            double[] angle = new double[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                double result = (double)(lines[i].P2.Y - lines[i].P1.Y) / (lines[i].P2.X - lines[i].P1.X);
                angle[i] = Math.Atan(result) * 57.2957795;
            }
            double avg = 0;

            //for (int i = 0; i < lines.Length; i++)
            //{
            //    //Image<Gray, byte> imageRotateX = image.Rotate(-1 * angle[i], new Gray(255));

            //    //imageRotateX.Save(newFileName(folder, "deskew_"+i.ToString()+"_an_"+angle[i].ToString().Replace(".","-")));

            //    avg += angle[i];
            //}
            //avg = avg / lines.Length;
            Gray g = new Gray(255);
            if (!angle.Any())
            {
                return this;
            }
            avg = angle.Max();
            if (bgColor == null)
            {
                bgColor = new Gray(255);
            }


            Image<TColor, TDepth> imageRotate = image.Rotate(-1 * avg, default(TColor), crop);
            return new ImageToProcess<TColor, TDepth>(this, imageRotate, tempFolder);
        }
        public IImageToProcess MarkAreasOfInterest(IEnumerable<Rectangle> rectanglesOfInterest)
        {
            var col = _ImageOpenCV.Convert<Bgr, TDepth>();
            foreach (var rect in rectanglesOfInterest)
            {
                col.Draw(rect, new Bgr(Color.Red), 1);
                //var text = string.Format("(x:{0},y:{1},w:{2},h:{3})", rect.X, rect.Y, rect.Width, rect.Height);
                CvInvoke.PutText(col, $"ar:{rect.AspectRatio()},w:{rect.Width},h:{rect.Height}", rect.Location, FontFace.HersheySimplex, .5, new Bgr(Color.Green).MCvScalar);
            }
            return new ImageToProcess<Bgr, TDepth>(this, col, tempFolder);
        }


        public IImageToProcess GaussianBlur()
        {
            var imgBlur = new Mat();
            CvInvoke.GaussianBlur(_ImageOpenCV, imgBlur, new Size(5, 5), 1.5);
            return new ImageToProcess<TColor, TDepth>(this, imgBlur, tempFolder);
        }


        public IImageToProcess RemoveNoise(int iterations = 1)
        {
            var horzStrucELem = CvInvoke.GetStructuringElement(ElementShape.Rectangle, new Size(1, 1), new Point(-1, -1));
            Mat dilated2 = new Mat();
            CvInvoke.Erode(InputImage, dilated2, horzStrucELem, new Point(-1, -1), 1, BorderType.Reflect, default(MCvScalar));
            return new ImageToProcess<TColor, TDepth>(this, dilated2, tempFolder);
        }

        public IImageToProcess CopyTo(IImageToProcess imageTo)
        {
            var image = _ImageOpenCV == null ? _Mat.ToImage<TColor, TDepth>() : _ImageOpenCV;
            return this;
        }
    }
}
