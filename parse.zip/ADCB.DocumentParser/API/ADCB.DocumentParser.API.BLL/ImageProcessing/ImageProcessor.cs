﻿using ADCB.DocumentParser.API.BLL.Interfaces;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class ImageProcessor : IImageProcessor
    {
        public IImageToProcess NewImage(string fileName, string folder)
        {
            return new ImageToProcess<Bgr, byte>(fileName, folder).WithBlackBorder(1);
        }
    }

}
