﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;


namespace ADCB.DocumentParser.API.BLL.ImageProcessing
{
    public class GradientImageProcessComponent : ImageProcessorDecoratorComponent
    {
        public GradientImageProcessComponent(IImageProcessorComponent imageProcessor, string key) : base(imageProcessor, key)
        {
        }

        public override string Name => "GradientImageProcessComponent";

       

        protected override IImageToProcess process(IImageToProcess imageToProcess)
        {
            return imageToProcess.Gradient().Save($"{key}--gradient");
        }
    }
}
