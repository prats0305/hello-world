﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System.Data.Entity;

namespace ADCB.DocumentParser.API.DAL
{
    public partial class DocumentParserDbContext : DbContext
    {
        public virtual DbSet<CountryMaster> CountryMasters { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<CustomerDocument> CustomerDocuments { get; set; }
        public virtual DbSet<CustomerDocumentParseHistory> CustomerDocumentParseHistories { get; set; }
        public virtual DbSet<CustomerProcessHistory> CustomerProcessHistories { get; set; }
        public virtual DbSet<DocumentTypeMaster> DocumentTypeMasters { get; set; }

        public virtual DbSet<AttributeMaster> AttributeMasters { get; set; }
        public virtual DbSet<CustomerAttribute> CustomerAttributes { get; set; }
        public virtual DbSet<CustomerDocumentAttribute> CustomerDocumentAttributes { get; set; }

        public virtual DbSet<EDMSDocument> EDMSDocuments { get; set; }
        public virtual DbSet<ErrorConfigMaster> ErrorConfigMasters { get; set; }
        public virtual DbSet<ESBServiceLog> ESBServiceLogs { get; set; }
        public virtual DbSet<Process> Processes { get; set; }
        public virtual DbSet<ProcessCustomer> ProcessCustomers { get; set; }
        public virtual DbSet<ProcessCustomerDocument> ProcessCustomerDocuments { get; set; }
        public virtual DbSet<ProcessStep> ProcessSteps { get; set; }
        public virtual DbSet<ProcessStepAttributes> ProcessStepAttributes { get; set; }
        public virtual DbSet<ProcessType> ProcessTypes { get; set; }
        public virtual DbSet<Status> Status { get; set; }
        public virtual DbSet<StepMaster> StepMasters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CountryMaster>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<CountryMaster>()
                .Property(e => e.Nationality)
                .IsUnicode(false);

            modelBuilder.Entity<CountryMaster>()
                .Property(e => e.Aplha2Code)
                .IsUnicode(false);

            modelBuilder.Entity<CountryMaster>()
                .Property(e => e.Aplha3Code)
                .IsUnicode(false);

            modelBuilder.Entity<AttributeMaster>()
                  .Property(e => e.AttributeName)
                  .IsUnicode(false);

            modelBuilder.Entity<AttributeMaster>()
                .HasMany(e => e.CustomerAttributes)
                .WithRequired(e => e.AttributeMaster)
                .HasForeignKey(e => e.AttributeUId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AttributeMaster>()
                .HasMany(e => e.CustomerDocumentAttributes)
                .WithRequired(e => e.AttributeMaster)
                .HasForeignKey(e => e.AttributeUId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<AttributeMaster>()
                .HasMany(e => e.ProcessStepAttributes)
                .WithRequired(e => e.AttributeMaster)
                .HasForeignKey(e => e.AttributeUId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.FullName)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.GivenName)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .Property(e => e.SurName)
                .IsUnicode(false);

            modelBuilder.Entity<Customer>()
                .HasMany(e => e.CustomerAttributes)
                .WithRequired(e => e.Customer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Customer>()
                .HasMany(e => e.CustomerDocumentAttributes)
                .WithRequired(e => e.Customer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Customer>()
                .HasMany(e => e.ProcessCustomers)
                .WithRequired(e => e.Customer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CustomerAttribute>()
                .Property(e => e.Value)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocumentAttribute>()
                .Property(e => e.Value)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentTypeMaster>()
                .Property(e => e.DocumentType)
                .IsUnicode(false);

            modelBuilder.Entity<DocumentTypeMaster>()
                .HasMany(e => e.EDMSDocuments)
                .WithOptional(e => e.DocumentTypeMaster)
                .HasForeignKey(e => e.DocumentTypeUid);

            modelBuilder.Entity<EDMSDocument>()
                .Property(e => e.DocumentName)
                .IsUnicode(false);

            modelBuilder.Entity<EDMSDocument>()
                .Property(e => e.DocumentIndex)
                .IsUnicode(false);

            modelBuilder.Entity<EDMSDocument>()
                .Property(e => e.CustomerName)
                .IsUnicode(false);

            modelBuilder.Entity<EDMSDocument>()
                .HasMany(e => e.ProcessCustomerDocuments)
                .WithRequired(e => e.EDMSDocument)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ErrorConfigMaster>()
                .Property(e => e.ErrorName)
                .IsUnicode(false);

            modelBuilder.Entity<ErrorConfigMaster>()
                .Property(e => e.ErrorDescription)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.ServiceName)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.Request)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.Response)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.ReturnCode)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.ErrorDescription)
                .IsUnicode(false);

            modelBuilder.Entity<ESBServiceLog>()
                .Property(e => e.UserId)
                .IsUnicode(false);

            modelBuilder.Entity<Process>()
                .Property(e => e.FileName)
                .IsUnicode(false);

            modelBuilder.Entity<Process>()
                .Property(e => e.GefuReferenceNumber)
                .IsUnicode(false);

            modelBuilder.Entity<Process>()
                .HasMany(e => e.ProcessCustomers)
                .WithRequired(e => e.Process)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Process>()
                .HasMany(e => e.ProcessSteps)
                .WithRequired(e => e.Process)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessCustomer>()
                .HasMany(e => e.ProcessCustomerDocuments)
                .WithRequired(e => e.ProcessCustomer)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessCustomerDocument>()
                .Property(e => e.DocumentPath)
                .IsUnicode(false);

            modelBuilder.Entity<ProcessCustomerDocument>()
                .HasMany(e => e.ProcessSteps)
                .WithRequired(e => e.ProcessCustomerDocument)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessStep>()
                .Property(e => e.ErrorMessage)
                .IsUnicode(false);

            modelBuilder.Entity<ProcessStep>()
                   .HasMany(e => e.CustomerDocumentAttributes)
                   .WithRequired(e => e.ProcessStep)
                   .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessStep>()
                .HasMany(e => e.ProcessStepAttributes)
                .WithRequired(e => e.ProcessStep)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessStepAttributes>()
                .Property(e => e.Value)
                .IsUnicode(false);

            modelBuilder.Entity<ProcessType>()
                .Property(e => e.ProcessType1)
                .IsUnicode(false);

            modelBuilder.Entity<ProcessType>()
                .HasMany(e => e.Processes)
                .WithRequired(e => e.ProcessType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessType>()
                .HasMany(e => e.StepMasters)
                .WithRequired(e => e.ProcessType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Status>()
                .Property(e => e.Status1)
                .IsUnicode(false);

            modelBuilder.Entity<Status>()
           .HasMany(e => e.CustomerDocumentAttributes)
           .WithRequired(e => e.Status)
           .WillCascadeOnDelete(false);

            modelBuilder.Entity<Status>()
                .HasMany(e => e.ProcessCustomers)
                .WithRequired(e => e.Status)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Status>()
                .HasMany(e => e.ProcessSteps)
                .WithRequired(e => e.Status)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Status>()
    .HasMany(e => e.ProcessStepAttributes)
    .WithRequired(e => e.Status)
    .WillCascadeOnDelete(false);

            modelBuilder.Entity<StepMaster>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<StepMaster>()
                .HasMany(e => e.ProcessSteps)
                .WithRequired(e => e.StepMaster)
                .HasForeignKey(e => e.StepUId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.EdmsDocumentIndex)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.DocumentName)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.DocumentPath)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.GivenName)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .Property(e => e.SurName)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocument>()
                .HasMany(e => e.CustomerDocumentParseHistories)
                .WithRequired(e => e.CustomerDocument)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CustomerDocumentParseHistory>()
                .Property(e => e.ParseStatus)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocumentParseHistory>()
                .Property(e => e.ErrorMessage)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocumentParseHistory>()
                .Property(e => e.GivenName)
                .IsUnicode(false);

            modelBuilder.Entity<CustomerDocumentParseHistory>()
                .Property(e => e.SurName)
                .IsUnicode(false);


        }
    }
}
