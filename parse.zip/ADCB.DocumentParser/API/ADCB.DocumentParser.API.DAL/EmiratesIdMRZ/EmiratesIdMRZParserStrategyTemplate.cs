﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ
{
    public abstract class EmiratesIdMRZParserStrategyTemplate : IDocumentParserStrategy
    {
        protected readonly string tempfolder;
        protected readonly IImageProcessor imageProcessor;
        protected readonly IImageToTextReader imageToTextReader;

        public EmiratesIdMRZParserStrategyTemplate(string tempfolder, IImageProcessor imageProcessor, IImageToTextReader imageToTextReader)
        {
            this.tempfolder = tempfolder;
            this.imageProcessor = imageProcessor;
            this.imageToTextReader = imageToTextReader;
        }

        public StrategyResult Execute(string fileName)
        {
            if(!System.IO.Directory.Exists(this.tempfolder))
            {
                System.IO.Directory.CreateDirectory(this.tempfolder);
            }

            var result = new StrategyResult();

            using (var image = imageProcessor.NewImage(fileName, tempfolder))
            {
                extract(result, image);
            }
            return result;
        }

        protected abstract void extract(StrategyResult strategyResult, IImageToProcess imageToProcess);
    }
}
