﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.API.BLL.ImageProcessing;

namespace ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ.Strategies
{
    public class EmiratesIdMRZParserStrategyDirect : EmiratesIdMRZParserStrategyTemplate
    {
        public EmiratesIdMRZParserStrategyDirect(string tempfolder, IImageProcessor imageProcessor, 
            IImageToTextReader imageToTextReader) : base(tempfolder, imageProcessor, imageToTextReader)
        { }

        protected override void extract(StrategyResult strategyResult, IImageToProcess imageToProcess)
        {
            

            var imageIndex = 1;
            var imgGrayScale = imageToProcess.GrayScale();
            imgGrayScale.Save($"{++imageIndex}_gray", true);

            int _horzConnection = 22;

            var areasOfInterest = imgGrayScale
                    .Gradient()
                    .Save($"{++imageIndex}_gradient", true)
                    .Threshold()
                    .Save($"{++imageIndex}_Threshold", true)
                    .HorizontalConnected(_horzConnection)
                     .Save($"{++imageIndex}_HorizontalConnected", true)
                    .FindAreasOfInterest(r =>
                    {
                        
                        return true;
                    });

            var areasOfInterestFiltered =
                   areasOfInterest.Where(r =>
                   {
                       return
                         r.Width > 14 &&
                         r.Height > 2 &&                          
                         r.AspectRatio() > 0.5;
                   });

            imageToProcess
                    .GrayScale()
                    .MarkAreasOfInterest(areasOfInterestFiltered)
                    .Save($"{++imageIndex}_contours_filtered", true);


            imageToProcess
                    .GrayScale()
                    .MarkAreasOfInterest(areasOfInterest)
                    .Save($"{++imageIndex}_contours", true);


            List<string> files = new List<string>();
            var mrzFilePaths = imgGrayScale
                    .ExtractAreasOfInterest(areasOfInterestFiltered)
                    .DeskewAll()
                    .SaveAll((index, img) =>
                    {
                        var file = $"{++imageIndex}_extract";

                        img
                        .WithBorder(Color.White, 10, 100, 10, 50)
                        .Save(file);

                        files.Add(file);

                        return $"{++imageIndex}_extract_border";
                        //return NewFile(fileName, "extracted", index.ToString());
                    }).ToList();

            StringBuilder stringBuilder = new StringBuilder();

            List<string> textInImage = new List<string>();
            foreach (var file in mrzFilePaths)
            {
                var fileName = System.IO.Path.Combine(tempfolder, file + ".jpeg");
                var text = imageToTextReader.Read(fileName);

                if(!string.IsNullOrEmpty(text))
                {
                    strategyResult.Values.Add(file, text);
                }

                textInImage.Add(text);
            }
            foreach (var file in files)
            {
                var fileName = System.IO.Path.Combine(tempfolder, file + ".jpeg");

                var text = imageToTextReader.Read(fileName);
                textInImage.Add(text);
                if (!string.IsNullOrEmpty(text))
                {
                    strategyResult.Values.Add(System.IO.Path.GetFileNameWithoutExtension(file), text);
                }
            }
            strategyResult.AllTexts.AddRange(textInImage.Where(s => !string.IsNullOrEmpty(s)));
        }
    }
}
