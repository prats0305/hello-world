﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ.Strategies
{
    public class PassportMRZParserStrategyBlurAndThresholdWithSkew : PassportMRZParserStrategyTemplate
    {
        public PassportMRZParserStrategyBlurAndThresholdWithSkew(string tempfolder, IImageProcessor imageProcessor, IImageToTextReader imageToTextReader) : 
            base(tempfolder, imageProcessor, imageToTextReader)
        { }

        protected override void extract(StrategyResult strategyResult, IImageToProcess imageToProcess)
        {
            var imageIndex = 1;

            imageToProcess.Save($"{++imageIndex}_org", true);

            var imgGrayScale = imageToProcess.GrayScale();
            imgGrayScale.Save($"{++imageIndex}_gray", true);

            int _horzConnection = 19;

            var areasOfInterest = imgGrayScale
                    .GaussianBlur()
                    .Save($"{++imageIndex}_GaussianBlur", true)
                    .Gradient()
                    .Save($"{++imageIndex}_gradient", true)
                    .Threshold()
                    .Save($"{++imageIndex}_Threshold", true)
                    .HorizontalConnected(_horzConnection)
                     .Save($"{++imageIndex}_HorizontalConnected", true)
                    .FindAreasOfInterest(r =>
                    {
                        return true;
                    });


            imageToProcess
                    .GrayScale()
                    .MarkAreasOfInterest(areasOfInterest)
                    .Save($"{++imageIndex}contours", true);
        }
    }
}
