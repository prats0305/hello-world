﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ.Strategies
{
    public class PassportMRZParserStrategySkewed : PassportMRZParserStrategyTemplate
    {
        public PassportMRZParserStrategySkewed(string tempfolder) : base(tempfolder)
        { }
    }
}
