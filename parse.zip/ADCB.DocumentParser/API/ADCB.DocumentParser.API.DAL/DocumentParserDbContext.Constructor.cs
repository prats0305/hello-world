﻿using System.Data.Entity;
using ADCB.DocumentParser.Common.Helper;
using System.Diagnostics;

namespace ADCB.DocumentParser.API.DAL
{
    public partial class DocumentParserDbContext : DbContext
    {
        public DocumentParserDbContext()
            : base(AppConfigHelper.MRZParserDBConString)
        {
            //Enable it to see debug log of EntityFramework operations.
            Database.Log = l =>
            {
                LoggingHelper.LogDebug(l);
                Debug.WriteLine(l);
            };

            Database.SetInitializer<DocumentParserDbContext>(null);
            Configuration.LazyLoadingEnabled = false;
            Configuration.ProxyCreationEnabled = false;
        }

        void customOnModelCreating(DbModelBuilder modelBuilder)
        {

        }
    }
}
