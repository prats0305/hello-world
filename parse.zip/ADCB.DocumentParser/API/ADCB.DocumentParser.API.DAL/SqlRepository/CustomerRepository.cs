﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Enums;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class CustomerRepository : GenericRepository<Customer>, ICustomerRepository
    {
        public CustomerRepository(DocumentParserDbContext context)
      : base(context)
        { }

        public IEnumerable<long> GetCustomerUidsToProcess(ProcessTypeEnum processTypeEnum)
        {
            try
            {
                var customers = base.Queryable();
                List<long> customerUIds = customers.Where(c => !c.ProcessCustomers.Any(f => f.CustomerUId == c.UId && f.Process.ProcessTypeUId == (byte)processTypeEnum)).
                    Select(s => s.UId).Take(AppConfigHelper.CustomersToProcessCount).ToList();

                return customerUIds;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.GetErrorMessage());
                return null;
            }
        }
    }
}
