﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class CountryMasterRepository : GenericRepository<CountryMaster>, ICountryMasterRepository
    {

        public CountryMasterRepository(DocumentParserDbContext context)
: base(context)
        { }

        public string GetNationalityCode(string country)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(country))
                {
                    result =  _dbSet.Where(r => r.Name.ToUpper().Equals(country.ToUpper()) || r.Nationality.ToUpper().Equals(country)).Select(p => p.Aplha3Code).FirstOrDefault();                     
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.Message);               
            }
            return result;

        }

    }
}
