﻿using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class ProcessCustomerDocumentRepository : GenericRepository<ProcessCustomerDocument>, IProcessCustomerDocumentRepository
    {
        public ProcessCustomerDocumentRepository(DocumentParserDbContext context)
    : base(context)
        { }

        public void AddProcessCustomerDocument(ProcessCustomerDocument processCustomerDocument)
        {
            Add(processCustomerDocument);
        }

        public void UpdateProcessCustomerDocument(ProcessCustomerDocument processCustomerDocument)
        {
            Update(processCustomerDocument);
        }

        public IEnumerable<ProcessCustomerDocument> GetPendingProcessCustomerDocumentDetails()
        {
            try
            {
                var result = GetList(
                        dbContext => dbContext.ProcessCustomer.StatusUId == (byte)StatusEnum.Pending && dbContext.StatusUId == (byte)StatusEnum.Pending,
                        q => q.ProcessCustomer
                        ).Take(AppConfigHelper.CustomersToProcessCount * 2);

                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
            
        }

        public ProcessCustomerDocument GetCustomerInfoFromProcCustDocUId(long? processCustomerDocumentUId)
        {
            try
            {
                var result = GetFirstOrDefault(
                            dbContext => dbContext.UId == processCustomerDocumentUId,
                            q => q.ProcessCustomer
                            );

                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }  

    }
}
