﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Exceptions;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class ProcessCustomerRepository : GenericRepository<ProcessCustomer>, IProcessCustomerRepository
    {

        public ProcessCustomerRepository(DocumentParserDbContext context)
      : base(context)
        { }

        public void AddProcessCustomerRepository(ProcessCustomer processCustomer)
        {
                Add(processCustomer);            
        }

        public void UpdateProcessCustomer(ProcessCustomer processCustomer)
        {
            Update(processCustomer);
        }
      
        public IEnumerable<ProcessCustomer> GetProcessCustomers()
        {
            try
            {
                List<byte> lstStatus = new List<byte>();
                lstStatus.Add((byte)StatusEnum.Initiated);                
                lstStatus.Add((byte)StatusEnum.NoDocIndex);

                return GetList(r => lstStatus.Contains(r.StatusUId) && (r.RetryCount == null  || r.RetryCount <= 2), q => q.Customer).Take(AppConfigHelper.CustomersToProcessCount);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.GetErrorMessage());
                return null;
            }
        }

        public ProcessCustomer GetProcessCustomerByUId(long processCustomerUId)
        {
            try
            {
                return GetFirstOrDefault(
                       r => r.UId == processCustomerUId
                       );
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.GetErrorMessage());
                return null;
            }
        }

        public ProcessCustomer GetCompletedDocProcessCustomerByUId(long processCustomerUId)
        {
            try
            {
                return GetFirstOrDefault(
                       r => r.UId == processCustomerUId && r.ProcessCustomerDocuments.All(x=>x.StatusUId == (byte)StatusEnum.Completed)
                       );
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.GetErrorMessage());
                return null;
            }
        }

    }
}
