﻿using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Helper;
using ADCB.DocumentParser.Common.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class UnitOfWork : IDisposable, IUnitOfWork
    {


        private DbContext _dbContext;
        private bool _disposed;
        private DbContextTransaction _transaction;

        public UnitOfWork(DocumentParserDbContext context)
        {
            try
            {
                _dbContext = context;
            }
            catch
            {
                //Roll Back entire object changes.
                Rollback();
                throw;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void BeginTransaction()
        {
            try
            {
                if (_transaction == null)
                    _transaction = _dbContext.Database.BeginTransaction();
            }
            catch
            {
                //Roll Back entire object changes.
                Rollback();
                throw;
            }
        }

        public bool Commit()
        {
            var returnValue = -1;
            try
            {
                returnValue = _dbContext.SaveChanges();
                if (_transaction != null)
                    _transaction.Commit();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                //Roll Back entire object changes.
                Rollback();

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new Exception(exceptionMessage, ex);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                LoggingHelper.LogError(ex.Message);
                throw new DocumentParserException(ErrorCodeEnum.Concurrency, ex);
            }
            catch
            {
                //Roll Back entire object changes.
                Rollback();

                throw;
            }

            return returnValue > -1;
        }

        public bool SaveChanges(bool isAuditToBeSaved = false)
        {
            var returnValue = -1;
            try
            {
                returnValue = _dbContext.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("\n", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: \n", fullErrorMessage);

                //Roll Back entire object changes.
                Rollback();

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new Exception(exceptionMessage, ex);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                LoggingHelper.LogError(ex.Message);
                throw new DocumentParserException(ErrorCodeEnum.Concurrency, ex);
            }
            catch
            {
                //Roll Back entire object changes.
                Rollback();
                throw;
            }
            return returnValue > -1;
        }


        public void Rollback()
        {
            try
            {
                if (_transaction != null)
                    _transaction.Rollback();

                foreach (var entry in _dbContext.ChangeTracker.Entries())
                    switch (entry.State)
                    {
                        case EntityState.Modified:
                            entry.State = EntityState.Unchanged;
                            break;
                        case EntityState.Added:
                            entry.State = EntityState.Detached;
                            break;
                        case EntityState.Deleted:
                            entry.State = EntityState.Unchanged;
                            break;
                    }
            }
            catch
            {
                throw;
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (!_disposed)
                    if (disposing)
                    {
                        _dbContext.Dispose();
                        _dbContext = null;
                        if (_transaction != null)
                            _transaction.Dispose();
                    }
                _disposed = true;
            }
            catch
            {
                throw;
            }
        }



    }
}
