﻿using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Enums;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class CustomerAttributeRepository : GenericRepository<CustomerAttribute>, ICustomerAttributeRepository
    {
        public CustomerAttributeRepository(DocumentParserDbContext context)
: base(context)
        { }

        public IEnumerable<CustomerAttribute> GetCustomerAttributeDetails(long custUId, byte? docTypeUId)
        {
            try
            {
                if(docTypeUId == (byte)DocumentTypeEnum.Passport)
                return GetList(
                        t => (t.CustomerUId == custUId &&
                        (t.AttributeUId != (byte)AttributeMasterEnum.EmiratesId &&
                        t.AttributeUId != (byte)AttributeMasterEnum.EIDA_DateOfExpiry) 
                         ));

                if (docTypeUId == (byte)DocumentTypeEnum.EIDA)
                    return GetList(
                            t => (t.CustomerUId == custUId &&
                            (t.AttributeUId != (byte)AttributeMasterEnum.PassportNo &&
                            t.AttributeUId != (byte)AttributeMasterEnum.Passport_DateOfExpiry)
                             ));


                return null;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }
    }
}
