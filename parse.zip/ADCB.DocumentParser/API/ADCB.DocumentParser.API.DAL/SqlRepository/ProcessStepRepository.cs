﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Exceptions;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class ProcessStepRepository : GenericRepository<ProcessStep>, IProcessStepRepository
    {

        public ProcessStepRepository(DocumentParserDbContext context)
      : base(context)
        { }

        public void AddProcessStep(ProcessStep processStep)
        {
            Add(processStep);
        }

        public void UpdateProcessStep(ProcessStep processStep)
        {
            Update(processStep);
        }

        public IEnumerable<ProcessStep> GetGlarePassedProcessStepDetails(byte docTypeUId)
        {
            try
            {
                var result = GetList(
                    dbContext => dbContext.ProcessCustomerDocument.EDMSDocument.DocumentTypeUid == docTypeUId
                    && dbContext.StatusUId == (byte)StatusEnum.GlarePassed,
                    q => q.ProcessCustomerDocument, q => q.ProcessCustomerDocument.EDMSDocument
                    ).Take(AppConfigHelper.CustomersToProcessCount * 2);

                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public IEnumerable<ProcessStep> GetDocumentParsedProcessStepDetails(byte docTypeUId)
        {
            try
            {
                var result = GetList(
                        dbContext => dbContext.ProcessCustomerDocument.EDMSDocument.DocumentTypeUid == docTypeUId
                            && dbContext.StatusUId == (byte)StatusEnum.PendingLowTask,
                        q => q.ProcessCustomerDocument, q => q.ProcessCustomerDocument.EDMSDocument
                        ).Take(AppConfigHelper.CustomersToProcessCount);

                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public ProcessStep GetProcessStepByUId(long processStepUId)
        {
            return GetById(processStepUId);
        }


        public IEnumerable<ProcessStep> GetSaveDocAttrStatusProcessStepDetails()
        {
            try
            {
                var result = GetList(
                        dbContext => dbContext.StatusUId == (byte)StatusEnum.SaveDocAttr,
                        q => q.ProcessCustomerDocument
                        ).Take(AppConfigHelper.CustomersToProcessCount * 2);

                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }
    }
}
