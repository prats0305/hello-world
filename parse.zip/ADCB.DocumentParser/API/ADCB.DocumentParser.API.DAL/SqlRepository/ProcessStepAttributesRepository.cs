﻿using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.API.BLL.Interfaces;
using System.Collections.Generic;
using ADCB.DocumentParser.Common.Enums;
using System.Linq;
using ADCB.DocumentParser.Common.Helper;
using System;
using System.Reflection;
using ADCB.DocumentParser.Common.Exceptions;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class ProcessStepAttributesRepository : GenericRepository<ProcessStepAttributes>, IProcessStepAttributesRepository
    {
        public ProcessStepAttributesRepository(DocumentParserDbContext context)
     : base(context)
        { }

        public void AddProcessStepAttribute(ProcessStepAttributes processStepAttribute)
        {
            Add(processStepAttribute);
        }

        public IEnumerable<ProcessStepAttributes> GetPendingProcessStepAttributes(List<long> processStepUids)
        {
            try
            {
                return GetList(
                            t => (!t.IsMovedToCustDocAtrbTable && processStepUids.Contains(t.ProcessStepUId)), q => q.ProcessStep
                             );
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public IEnumerable<ProcessStepAttributes> GetLowPriorityProcessStepAttributes(List<long> processStepUids)
        {
            try
            {
                return GetList(
                        t => (t.IsLowPriorityParserTaskRan && processStepUids.Contains(t.ProcessStepUId)), q => q.ProcessStep
                         );
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public void UpdateProcessStepAttribute(ProcessStepAttributes processStepAttribute)
        {
            Update(processStepAttribute);
        }

        public ProcessStepAttributes GetProcessStepAttributesByUId(long uId)
        {
            try
            {
                return GetById(uId);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public IEnumerable<ProcessStepAttributes> GetProcessStepAttributesByProcessStepUId(long processStepUId, bool isStatusToCheck = false)
        {
            try
            {
                List<byte> lstStatus = new List<byte>();
                lstStatus.Add((byte)StatusEnum.NotMatched);
                lstStatus.Add((byte)StatusEnum.PartialMatched);

                if (isStatusToCheck)
                    return GetList(
                                    t => (!t.IsLowPriorityParserTaskRan && t.ProcessStepUId == processStepUId &&
                                  lstStatus.Contains(t.StatusUId))
                                     );
                else
                    return GetList(
                                   t => (!t.IsLowPriorityParserTaskRan && t.ProcessStepUId == processStepUId)
                                   );
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public List<long> GetProcessStepAttributesUIds()
        {
            try
            {
                List<byte?> lstStatus = new List<byte?>();
                lstStatus.Add((byte?)StatusEnum.EIDAParser);
                lstStatus.Add((byte?)StatusEnum.PassportParser);
                return GetList(x => !x.IsMovedToCustDocAtrbTable && lstStatus.Contains(x.ProcessStep.StatusUId), o => o.OrderBy(x => x.UpdatedOn), p => p.ProcessStep).Select(x => x.ProcessStepUId).Distinct().Take(AppConfigHelper.CustomersToProcessCount).ToList();
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public List<long> GetLowPriorityProcessStepAttributesUIds()
        {
            try
            {
                List<byte?> lstStatus = new List<byte?>();
                lstStatus.Add((byte?)StatusEnum.LowEIDAPars);
                lstStatus.Add((byte?)StatusEnum.LowPassportPars);
                return GetList(x => x.IsLowPriorityParserTaskRan && lstStatus.Contains(x.ProcessStep.StatusUId), o => o.OrderBy(x => x.UpdatedOn), p => p.ProcessStep).Select(x => x.ProcessStepUId).Distinct().Take(AppConfigHelper.CustomersToProcessCount).ToList();
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }
        }

        public bool IsAllMatchedProcessStepAttributes(long processStepUId)
        {
            try
            {
                List<byte> lstStatus = new List<byte>();
                lstStatus.Add((byte)StatusEnum.Matched);
                lstStatus.Add((byte)StatusEnum.PartialMatched);

                var processStepAttributes = GetList(x => x.ProcessStepUId == processStepUId);
                bool result = false;

                if (processStepAttributes != null && processStepAttributes.Count() > 0)
                    result = processStepAttributes.All(x => lstStatus.Contains(x.StatusUId));
               
                return result;
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return false;
            }
        }

    }
}
