﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Exceptions;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class CustomerDocumentAttributeRepository : GenericRepository<CustomerDocumentAttribute>, ICustomerDocumentAttributeRepository
    {
        public CustomerDocumentAttributeRepository(DocumentParserDbContext context)
   : base(context)
        { }

        public void AddCustomerDocumentAttribute(CustomerDocumentAttribute custDocAttr)
        {
            Add(custDocAttr);
        }

        public CustomerDocumentAttribute GetCustomerDocumentAttributeByProcessStepAndCustUId(ProcessStepAttributes processStep, long custUId)
        {
            try
            {
                return GetFirstOrDefault(x => x.CustomerUId == custUId && x.ProcessStepUId == processStep.ProcessStepUId &&
                x.AttributeUId == processStep.AttributeUId);
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception :" + ex.GetErrorMessage());
                return null;
            }

        }

        public void UpdateCustomerDocumentAttribute(CustomerDocumentAttribute custDocAttr)
        {
            Update(custDocAttr);
        }

    }
}
