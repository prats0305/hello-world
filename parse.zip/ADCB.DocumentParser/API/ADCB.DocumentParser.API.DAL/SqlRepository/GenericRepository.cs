﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common.Extensions;
using System.Data.Entity.Validation;


namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class GenericRepository<Input> where Input : class
    {

        protected readonly IDbSet<Input> _dbSet;
        protected DbContext dbContext;

        protected GenericRepository(DocumentParserDbContext context)
        {
            dbContext = context;
            _dbSet = context.Set<Input>();

        }

        protected IQueryable<Input> Queryable()
        {
            return _dbSet.AsQueryable<Input>();
        }

        protected virtual IEnumerable<Input> GetAll()
        {
            return _dbSet.AsEnumerable();
        }

        public IEnumerable<Output> GetAll<Output>(Expression<Func<Input, Output>> columns)
        {
            return _dbSet.AsQueryable<Input>().Select<Input, Output>(columns);
        }

        protected virtual Input GetById(object id)
        {
            return _dbSet.Find(id);
        }

        protected virtual Input GetFirstOrDefault(Expression<Func<Input, bool>> filter = null, Func<IQueryable<Input>, IOrderedQueryable<Input>> orderBy = null,
                                params Expression<Func<Input, object>>[] includeExpressions)
        {
            IQueryable<Input> query = _dbSet;

            foreach (Expression<Func<Input, object>> includeExpression in includeExpressions)
                query = query.Include(includeExpression);

            if (filter.IsNotNull())
                query = query.Where(filter);

            if (orderBy.IsNotNull())
                query = orderBy(query);

            return query.FirstOrDefault();
        }

        public IEnumerable<Input> ExecuteStoredProcedure(String command, params SqlParameter[] parameter)
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.Append("EXECUTE " + command);
            strBuilder.Append(string.Join(",", parameter.ToList().Select(s => " " + s.ParameterName)));
            return dbContext.Database.SqlQuery<Input>(strBuilder.ToString(), parameter).ToList();
        }

        protected virtual Input GetFirstOrDefault(Expression<Func<Input, bool>> filter, params Expression<Func<Input, object>>[] includeExpressions)
        {
            IQueryable<Input> query = _dbSet;

            if (filter.IsNotNull())
                query = query.Where(filter);

            foreach (Expression<Func<Input, object>> includeExpression in includeExpressions)
                query = query.Include(includeExpression);

            return query.FirstOrDefault();
        }

        protected virtual List<Input> GetList(
            Expression<Func<Input, bool>> filter = null,
            Func<IQueryable<Input>, IOrderedQueryable<Input>> orderBy = null,
            params Expression<Func<Input, object>>[] includeExpressions)
        {
            IQueryable<Input> query = _dbSet.AsQueryable();

            if (filter.IsNotNull())
                query = query.Where(filter);

            var t = query.ToList();

            if (includeExpressions.IsNotNull())
                foreach (Expression<Func<Input, object>> includeExpression in includeExpressions)
                    query = query.Include(includeExpression);

            if (orderBy.IsNotNull())
                return orderBy(query).ToList();
            return query.ToList();
        }

        protected virtual List<Input> GetList(Expression<Func<Input, bool>> filter = null,
            params Expression<Func<Input, object>>[] includeExpressions)
        {
            IQueryable<Input> query = _dbSet.AsNoTracking<Input>(); ;

            if (filter.IsNotNull())
                query = query.Where(filter);

            foreach (Expression<Func<Input, object>> includeExpression in includeExpressions)
                query = query.Include(includeExpression);

            return query.ToList();
        }

        protected virtual IEnumerable<Input> GetList(Expression<Func<Input, bool>> filter = null)
        {
            IQueryable<Input> query = _dbSet.AsNoTracking<Input>(); ;

            if (filter.IsNotNull())
                query = query.Where(filter);

            return query.ToList();
        }

        protected virtual Input Add(Input entity)
        {
            return _dbSet.Add(entity);
        }

        protected virtual Input Delete(Input entity)
        {
            return _dbSet.Remove(entity);
        }

        protected virtual Input Delete(object id)
        {
            return _dbSet.Remove(GetById(id));
        }

        protected virtual void Update(Input entity)
        {
            dbContext.Entry(entity).State = EntityState.Modified;
        }

        protected virtual void Update(Input entity, params Expression<Func<Input, object>>[] updatedProperties)
        {
            if (updatedProperties.Any())
            {
                dbContext.Entry(entity).State = EntityState.Unchanged;

                //update explicitly mentioned properties
                foreach (var property in updatedProperties)
                {
                    dbContext.Entry(entity).Property(property).IsModified = true;
                }
            }
            else
            {
                dbContext.Entry(entity).State = EntityState.Modified;
                //no items mentioned, so find out the updated entries
                foreach (var property in dbContext.Entry(entity).OriginalValues.PropertyNames)
                {
                    var original = dbContext.Entry(entity).OriginalValues.GetValue<object>(property);
                    var current = dbContext.Entry(entity).CurrentValues.GetValue<object>(property);
                    if (original != null && !original.Equals(current))
                        dbContext.Entry(entity).Property(property).IsModified = true;
                }
            }
        }

        protected virtual bool Save()
        {
            try
            {
                return dbContext.SaveChanges() > -1;
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("\n", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: \n", fullErrorMessage);

                //Roll Back entire object changes.
                // Throw a new DbEntityValidationException with the improved exception message.
                throw new Exception(exceptionMessage, ex);
            }
        }

        protected bool IsExist(Expression<Func<Input, bool>> filter)
        {
            return _dbSet.AsNoTracking<Input>().Where(filter).Any();
        }

        protected int GetCount()
        {
            return _dbSet.AsNoTracking<Input>().AsQueryable().Count();
        }

        protected int GetCount(Expression<Func<Input, bool>> filter)
        {
            return _dbSet.AsNoTracking<Input>().Where(filter).Count();
        }

        protected long GetNextSequenceValue(string sequenceName)
        {
            return dbContext.Database.SqlQuery<long>(String.Format("SELECT NEXT VALUE FOR {0};", sequenceName)).SingleOrDefault();
        }

    }

    public static class QueryableExtensions
    {
        public static IProjectionExpression Project<TSource>(
            this IQueryable<TSource> source)
        {
            return new ProjectionExpression<TSource>(source);
        }
    }
    public interface IProjectionExpression
    {
        IQueryable<TResult> To<TResult>();
    }
    public class ProjectionExpression<TSource>
    : IProjectionExpression
    {
        private readonly IQueryable<TSource> _source;

        public ProjectionExpression(IQueryable<TSource> source)
        {
            _source = source;
        }

        public IQueryable<TResult> To<TResult>()
        {
            Expression<Func<TSource, TResult>> expr = BuildExpression<TResult>();

            return _source.Select(expr);
        }

        public static Expression<Func<TSource, TResult>> BuildExpression<TResult>()
        {
            var sourceMembers = typeof(TSource).GetProperties();
            var destinationMembers = typeof(TResult).GetProperties();

            var name = "src";

            var parameterExpression = Expression.Parameter(typeof(TSource), name);

            return Expression.Lambda<Func<TSource, TResult>>(
                Expression.MemberInit(
                    Expression.New(typeof(TResult)),
                    destinationMembers.Select(dest => Expression.Bind(dest,
                        Expression.Property(
                            parameterExpression,
                            sourceMembers.First(pi => pi.Name == dest.Name)
                        )
                    )).ToArray()
                    ),
                parameterExpression
                );
        }
    }
}
