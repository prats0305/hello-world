﻿using ADCB.DocumentParser.Common.Entity.SQL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common.Helper;
using System.Reflection;
using ADCB.DocumentParser.Common.Exceptions;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class EDMSDocumentRepository : GenericRepository<EDMSDocument>, IEDMSDocumentRepository
    {
        public EDMSDocumentRepository(DocumentParserDbContext context)
     : base(context)
        { }

        public IEnumerable<EDMSDocument> GetInitiatedCustomersEDMSDetails(long? cid)
        {
            try
            {
                return GetList(r => r.CID == cid);              
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(MethodBase.GetCurrentMethod().Name + "Exception:" + ex.GetErrorMessage());
                return null;
            }
        }
    }
}
