﻿using ADCB.DocumentParser.Common.Entity.SQL;
using ADCB.DocumentParser.API.BLL.Interfaces;

namespace ADCB.DocumentParser.API.DAL.SqlRepository
{
    public class ProcessRepository : GenericRepository<Process>, IProcessRepository
    {
        public ProcessRepository(DocumentParserDbContext context)
    : base(context)
        { }
       
        public void AddProcessRepository(Process process)
        {           
            Add(process);
        }
    }
}
