﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class EmiratesIdMRZNameOnlyTest
    {
        DataTable csvData = null;
        string resultCSVFile, resultCSVFilePath;
        ImageToTextReaderTessaractMICR ocr;
        ImageProcessor imageProcessor;
        List<Type> strategies;

        [TestInitialize]
        public void Init()
        {
            TestParameters.ImageType = "EmiratesId";
            string expectedDataFilePath = @"C:\DevProject\MRZParser\Scripts\SampleDataV2\Source\EmiratesId\";
            string expectedDataCSV = "EIDA.csv";
            csvData = TestParameters.GetDataTableFromCsv(expectedDataCSV, expectedDataFilePath);
            resultCSVFilePath = @"C:\DevProject\MRZParser\Source\ADCB.DocumentParser\ADCB.DocumentParser.Test\UnitTestResult\";
            ocr = new ImageToTextReaderTessaractMICR();
            imageProcessor = new ImageProcessor();
            strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                              .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();
        }

        [TestMethod]
        public void TestNameInAllFiles()
        {
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedName, ExtractedName"
            };
            resultCSVFile = "ResultEmiratesIdName_All_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "EmiratesIdMRZParserStrategyMRZOnly";
            string extractedName = "", listItem = "";
            int counter = 0;
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                foreach (DataRow item in csvData.Rows)
                {
                    extractedName = "";
                    listItem = "";
                    listItem += Path.GetFileName(item["FileName"].ToString()) + ", " + item["Name"].ToString() + ", ";
                    string actualFilePath = TestParameters.PendingFolder + "\\" + item["FileName"].ToString();
                    TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(item["FileName"].ToString());
                    TestParameters.DeleteExistingTempPath();
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                    var result = strategy.Execute(actualFilePath);
                    List<string> lstValues = new List<string>();
                    foreach (var text in result.Values)
                    {
                        lstValues.Add($"{text.Key} - {text.Value}");
                    }
                    var actualNameLst = item["Name"].ToString().Split(' ').ToList();
                    var extractNamesLst = result.Values.Where(x => x.Value.Contains("<")).Select(x => x).ToList();
                    if (extractNamesLst.Count > 0)
                    {
                        List<KeyValuePair<string, string>> extractNameArraySplit = new List<KeyValuePair<string, string>>();
                        List<string> splittedNames = new List<string>();
                        foreach (var name in extractNamesLst)
                        {
                            if (name.Value[0] == '<')
                            {
                                splittedNames = name.Value.Substring(1).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            }
                            else
                            {
                                splittedNames = name.Value.Substring(5).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                            }
                            foreach (var nameStr in splittedNames)
                            {
                                var keyValPair = new KeyValuePair<string, string>(name.Key, nameStr.Replace(" ", ""));
                                extractNameArraySplit.Add(keyValPair);
                            }
                        }
                        counter = 0;
                        foreach (var nameValueToCompare in actualNameLst)
                        {
                            var matchesNames = extractNameArraySplit.Where(v => v.Value.Equals(nameValueToCompare, StringComparison.CurrentCultureIgnoreCase));
                            if (matchesNames.Any())
                            {
                                extractedName += string.Format("MatchedName {0}:", counter.ToString());
                                var imageKeys = matchesNames.
                                                GroupBy(o => new { o.Value })
                                                .Select(o => o.FirstOrDefault());
                                foreach (var imgKey in imageKeys)
                                {
                                    string imageFile = imgKey.Key;
                                    extractedName += " >> " + imgKey.Key + " ";
                                }
                                imageKeys = null;
                            }
                            else
                            {
                                extractedName += string.Format("Non-MatchedName {0} ", counter.ToString());
                            }
                            counter++;
                            matchesNames = null;
                        }
                    }
                    strategy = null;
                    result = null;
                    listItem += extractedName;
                    resultLst.Add(listItem);
                }
                Assert.IsFalse(true);
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
                Assert.IsFalse(false);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }
    }
}
