﻿using ADCB.DocumentParser.API.Facade;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FakeItEasy;
using System.IO;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Helper;
using System.Linq.Expressions;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class DocumentParserFacadeTest
    {

        [TestMethod]
        public void HayyakReceiveAndProcessCustomers()
        {           
            var result = A.Fake<DocumentParserFacade>().ReceiveAndProcessCustomers(ProcessTypeEnum.Hayaak);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void DownloadProcessCustomersDocument()
        {
            var result = A.Fake<DocumentParserFacade>().DownloadProcessCustomersDocument();
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void GlareDetectionForPendingCustomers()
        {
            var result = A.Fake<DocumentParserFacade>().GlareDetectionForPendingCustomers();
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void PassportParserForGlarePassedImages()
        {
           var path = Path.Combine(Environment.CurrentDirectory, Path.Combine("x86", "liblept172"));
            var result = A.Fake<DocumentParserFacade>().ParseGlarePassedImages(DocumentTypeEnum.Passport,false);
            Assert.IsTrue(result);
        }


        [TestMethod]
        public void LowPriorityPassportParserForGlarePassedImages()
        {
            var path = Path.Combine(Environment.CurrentDirectory, Path.Combine("x86", "liblept172"));
            var result = A.Fake<DocumentParserFacade>().ParseGlarePassedImages(DocumentTypeEnum.Passport, true);
            Assert.IsTrue(result);
        }


        [TestMethod]
        public void EIDAParserForGlarePassedImages()
        {
            var path = Path.Combine(Environment.CurrentDirectory, Path.Combine("x86", "liblept172"));
            var result = A.Fake<DocumentParserFacade>().ParseGlarePassedImages(DocumentTypeEnum.EIDA, false);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void LowPriorityEIDAParserForGlarePassedImages()
        {
            var path = Path.Combine(Environment.CurrentDirectory, Path.Combine("x86", "liblept172"));
            var result = A.Fake<DocumentParserFacade>().ParseGlarePassedImages(DocumentTypeEnum.EIDA, true);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void SaveDocumentAttributeTask()
        {            
            var result = A.Fake<DocumentParserFacade>().SaveDocumentAttributeTask();
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void LowPrioritySaveDocumentAttributeTask()
        {
            var result = A.Fake<DocumentParserFacade>().SaveDocumentAttributeTask(true);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void DeleteAppzoneDocumentTask()
        {
            var result = A.Fake<DocumentParserFacade>().DeleteAppzoneDocumentTask();
            Assert.IsTrue(result);
        }        

        [TestMethod]
        public void TestOutPath()
        {
            string fileName = string.Empty, destFile = string.Empty;
            string tibcoInPath = @"\\adcm7108\d$\DocumentParser\TIBCOPath\" + 1;
            string outPath = AppConfigHelper.ImageOutPath + 99 + "_" + DateTime.Now.ToString("ddMMyyyyHHmmss");

            var outDir = System.IO.Directory.CreateDirectory(outPath);
            if (System.IO.Directory.Exists(tibcoInPath))
            {
                string[] files = System.IO.Directory.GetFiles(tibcoInPath);

                // Copy the files and overwrite destination files if they already exist.
                if (files != null && files.Count() > 0)
                {
                    foreach (string file in files)
                    {
                        // Use static Path methods to extract only the file name from the path.
                        fileName = System.IO.Path.GetFileName(file);
                        destFile = System.IO.Path.Combine(outPath, fileName);
                        System.IO.File.Copy(file, destFile);
                    }
                }
            }
            else
            {
                Console.WriteLine("Source path does not exist!");
            }
       
        }

    }
}
