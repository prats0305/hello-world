﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Test
{
    public class TestParameters
    {
        private static string imageType;
        private static string strategyTypeStr;        
        private static string imgNameWithoutExt;

        public static string ImageType { get => imageType; set => imageType = value; }
        public static string ImgNameWithoutExt { get => imgNameWithoutExt; set => imgNameWithoutExt = value; }
        public static string StrategyTypeStr { get => strategyTypeStr; set => strategyTypeStr = value; }
        public static string DateFormat
        {
            get
            {
                return "yyyyMMddHHmmss";
            }
        }

        public static string SourceFolder
        {
            get
            {
                return Path.Combine(ConfigurationManager.AppSettings["SourceFolder"]);
            }
        }

        public static string PendingFolder
        {
            get
            {
                return Path.Combine(ConfigurationManager.AppSettings["WorkingFolder"], imageType, "Pending");
            }
        }
        public static string ProcessingFolder
        {
            get
            {
                return Path.Combine(ConfigurationManager.AppSettings["WorkingFolder"], imageType, "Processing");
            }
        }

        public static string SuccessFolder
        {
            get
            {
                return Path.Combine(ConfigurationManager.AppSettings["WorkingFolder"], imageType, "Success");
            }
        }

        public static string FailedFolder
        {
            get
            {
                return Path.Combine(ConfigurationManager.AppSettings["WorkingFolder"], imageType, "Failed");
            }
        }

        private void GetNewImagesFromSource()
        {
            var files = Directory.GetFiles(SourceFolder);

            foreach (var file in files)
            {
                CopyFile(file, PendingFolder);
            }
        }
        private void CopyFile(string fileName, string destinationFolder)
        {
            var destPath = Path.Combine(destinationFolder, Path.GetFileName(fileName));
            if (!File.Exists(destPath))
            {
                File.Copy(fileName, destPath);
            }
        }

        public static DataTable GetDataTableFromCsv(string fName, string filePath)
        {
            string path = filePath + fName;
            string header = "Yes";

            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);

            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                DataTable dataTable = new DataTable
                {
                    Locale = CultureInfo.CurrentCulture
                };
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        public static void WriteTextToCsv(List<string> resultLst, string resultFileName, string resultFilePath)
        {
            string filePathResult = resultFilePath + resultFileName;
            //after your loop       
            foreach (var item in resultLst)
            {
                File.AppendAllText(filePathResult, item + "\n");
            }
        }
        public static string TempPath
        {
            get
            {
                return Path.Combine(ProcessingFolder, imgNameWithoutExt, strategyTypeStr);
            }
        }

        public static void DeleteExistingTempPath()
        {
            try
            {
                //Delete existing Processing Folder path
                if (Directory.Exists(TempPath))
                {
                    Directory.Delete(TempPath, true);
                }
            }
            catch
            { }
        }

        public static string FormatExtractedDate(string value, out string format)
        {
            format = "dd-MM-yyyy";
            //Case1
            if (ValidateDate(value)) { return value; }

            value = value.Contains('O') ? value.Replace('O', '0') : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains('D') ? value.Replace('D', '0') : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains('Z') ? value.Replace('Z', '7') : value;
            if (ValidateDate(value)) { return value; }

            value = value.Contains('B') ? value.Replace('B', '8') : value;
            if (ValidateDate(value)) { return value; }
            value = value.Contains('S') ? value.Replace('S', '5') : value;
            if (ValidateDate(value)) { return value; }

            //dd1MM1YYYY
            //dd1MMM1YYYY
            //dd7MM7YYYY
            //Od-MM-YYYY
            string dt, mon, year = "";
            switch (value.Length)
            {
                case 8:
                    dt = value.Substring(0, 2);
                    mon = value.Substring(2, 2);
                    year = value.Substring(4, 4);
                    if (ValidateDate(dt + "-" + mon + "-" + year)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 9:
                    dt = value.Substring(0, 2);
                    mon = value.Substring(2, 3);
                    mon = mon.Replace('0', 'O');
                    mon = mon.Replace('5', 'S');
                    mon = mon.Replace('8', 'B');
                    mon = mon.Replace("0E", "DE");
                    year = value.Substring(5, 4);
                    format = "dd-MMM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year, format)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 10:
                    dt = value.Substring(0, 2);
                    mon = value.Substring(3, 2);
                    year = value.Substring(6, 4);
                    if (ValidateDate(dt + "-" + mon + "-" + year)) { return dt + "-" + mon + "-" + year; }
                    break;
                case 11:
                    dt = value.Substring(0, 2);
                    mon = value.Substring(3, 3);
                    mon = mon.Replace('0', 'O');
                    mon = mon.Replace('5', 'S');
                    mon = mon.Replace('8', 'B');
                    mon = mon.Replace("0E", "DE");
                    year = value.Substring(7, 4);
                    format = "dd-MMM-yyyy";
                    if (ValidateDate(dt + "-" + mon + "-" + year, format)) { return dt + "-" + mon + "-" + year; }
                    break;
                default:
                    break;
            }
            bool ValidateDate(string dateValue, string format1 = "dd-MM-yyyy")
            {
                if (DateTime.TryParseExact(dateValue, format1, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dDate))
                {
                    return true;
                }
                return false;
            }
            return value;
        }

        public static string FormatEmiratesId(string value)
        {
            value = value.Contains('O') ? value.Replace('O', '0') : value;
            value = value.Contains('D') ? value.Replace('D', '0') : value;
            value = value.Contains('Z') ? value.Replace('Z', '7') : value;
            value = value.Contains('B') ? value.Replace('B', '8') : value;
            value = value.Contains('S') ? value.Replace('S', '5') : value;

            string firstIndexEid = string.Empty, secondIndexEid = string.Empty, thirdIndexEid = string.Empty, fourthIndexEid = string.Empty;
            switch (value.Length)
            {
                case 18:
                    firstIndexEid = value.Substring(0, 3);
                    secondIndexEid = value.Substring(4, 4);
                    thirdIndexEid = value.Substring(9, 7);
                    fourthIndexEid = value.Substring(17, 1);
                    return firstIndexEid + "-" + secondIndexEid + "-" + thirdIndexEid + "-" + fourthIndexEid;
                default:
                    break;
            }

            return value;
        }
    }
}
