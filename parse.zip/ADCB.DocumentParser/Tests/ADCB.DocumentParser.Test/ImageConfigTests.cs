﻿
using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class ImageConfigTests
    {
        string resultCSVFile, resultCSVFilePath;
        ImageToTextReaderTessaractMICR ocr;
        ImageProcessor imageProcessor;
        List<Type> strategies;

        [TestInitialize]
        public void Init()
        {
            TestParameters.ImageType = "Passport";
            resultCSVFilePath = @"C:\DATAS\PROJECT\206\UnitTest\FinalCSVResultSet\";
            ocr = new ImageToTextReaderTessaractMICR();
            imageProcessor = new ImageProcessor();
            strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                              .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();
        }

        [TestMethod]
        public void TestPassportSpecificImageForNameStrategy()
        {
            var expectedResult = new Dictionary<string, string> {
                {"CID", "122110"},
                {"FileName", "1.jpeg"},
                {"Passport No", "L3606600"},
                {"Name", "NAVEEN MURALIDHAR BUXANI"},
                {"DOB", "27-Aug-90"},
                {"Expiry", "5-Aug-23"},
                {"Nationality", "INDIAN"},
                {"Gender", "M"}
            };
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedName, ExtractedName"
            };
            string extractedName = "", listItem = "";
            resultCSVFile = "ResultName_" + expectedResult["FileName"].Replace('.', '_') + "_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "PassportMRZParserStrategyMRZOnly";
            int counter = 0;
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                listItem += Path.GetFileName(expectedResult["FileName"]) + ", " + expectedResult["Name"].ToString() + ", ";
                string actualFilePath = TestParameters.PendingFolder + "\\" + expectedResult["FileName"].ToString();
                TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(expectedResult["FileName"].ToString());
                TestParameters.DeleteExistingTempPath();
                var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                //Execute Strategy for specific File
                var result = strategy.Execute(actualFilePath);
                List<string> lstValues = new List<string>();
                foreach (var text in result.Values)
                {
                    //Add image name and text value in key value pair result set
                    lstValues.Add($"{text.Key} - {text.Value}");
                }
                var actualNameLst = expectedResult["Name"].ToString().Split(' ').ToList();
                //Fetch only values that contain < sign, which is MRZ specific sign only
                var extractNamesLst = result.Values.Where(x => x.Value.Contains("<")).Select(x => x).ToList();
                if (extractNamesLst.Count > 0)
                {
                    List<KeyValuePair<string, string>> extractNameArraySplit = new List<KeyValuePair<string, string>>();
                    List<string> splittedNames = new List<string>();
                    foreach (var name in extractNamesLst)
                    {
                        if (name.Value[0] == '<')
                        {
                            splittedNames = name.Value.Substring(1).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        }
                        else
                        {
                            splittedNames = name.Value.Substring(5).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        }
                        foreach (var nameStr in splittedNames)
                        {
                            var keyValPair = new KeyValuePair<string, string>(name.Key, nameStr.Replace(" ", ""));
                            extractNameArraySplit.Add(keyValPair);
                        }
                    }
                    counter = 0;
                    foreach (var nameValueToCompare in actualNameLst)
                    {
                        var matchesNames = extractNameArraySplit.Where(v => v.Value.Equals(nameValueToCompare, StringComparison.CurrentCultureIgnoreCase));
                        if (matchesNames.Any())
                        {
                            extractedName += string.Format("MatchedName {0}:", counter.ToString());
                            var imageKeys = matchesNames.
                                            GroupBy(o => new { o.Value })
                                            .Select(o => o.FirstOrDefault());
                            foreach (var imgKey in imageKeys)
                            {
                                string imageFile = imgKey.Key;
                                extractedName += " >> " + imgKey.Key + " ";
                            }
                            imageKeys = null;
                        }
                        else
                        {
                            extractedName += string.Format("Non-MatchedName {0} ", counter.ToString());
                        }
                        counter++;
                        matchesNames = null;
                    }
                }
                strategy = null;
                result = null;
                listItem += extractedName;
                resultLst.Add(listItem);
                Assert.IsFalse(false);
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
                Assert.IsFalse(true);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }

        [TestMethod]
        public void TestPassportSpecificImageForDateStrategyForDOB()
        {
            var expectedResult = new Dictionary<string, string> {
                {"CID", "122112"},
                {"FileName", "3.jpeg"},
                {"Passport No", "S3153864"},
                {"Name", "AERNIKAL PARAMAL ANJALI"},
                {"DOB", "25-Dec-93"},
                {"Expiry", "7-Aug-28"},
                {"Nationality", "INDIAN"},
                {"Gender", "F"}
            };

            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedDOB, ExtractedDOB"
            };
            resultCSVFile = "ResultDOB_" + expectedResult["FileName"].Replace('.', '_') + "_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            string extractedDOB = "", listItem = "";
            TestParameters.StrategyTypeStr = "PassportMRZParserStrategyDateOnly";
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                List<string> lstValues = new List<string>();
                listItem += Path.GetFileName(expectedResult["FileName"].ToString()) + ", " + expectedResult["DOB"].ToString() + ", ";
                //Expected Result
                string dobValueToCompare = expectedResult["DOB"].ToString();
                //ActualFilePath
                string actualFilePath = TestParameters.PendingFolder + "\\" + expectedResult["FileName"].ToString();
                TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(expectedResult["FileName"].ToString());
                TestParameters.DeleteExistingTempPath();
                var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                //Execute Strategy for filename
                var strategyExecRes = strategy.Execute(actualFilePath);
                foreach (var text in strategyExecRes.Values)
                {
                    lstValues.Add($"{text.Key} - {text.Value}");
                }
                //Filter out only desired resultset for date
                var extractedValuesLst = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 11);
                if (extractedValuesLst.Any())
                {
                    foreach (var extractedVal in extractedValuesLst)
                    {
                        string dateExtract = TestParameters.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                        if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                        {
                            continue;
                        }
                        if (Convert.ToDateTime(dobValueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                        {
                            extractedDOB += string.Format("MatchedDOB >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                        }
                        else
                        {
                            extractedDOB += string.Format("Non-MatchedDOB  >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                        }
                    }
                }
                strategy = null;
                listItem += extractedDOB;
                resultLst.Add(listItem);
                Assert.IsFalse(false);
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
                Assert.IsFalse(true);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }
        [TestMethod]
        public void TestPassportSpecificImageForDateStrategyForDOE()
        {
            var expectedResult = new Dictionary<string, string> {
                {"CID", "122110"},
                {"FileName", "1.jpeg"},
                {"Passport No", "L3606600"},
                {"Name", "NAVEEN MURALIDHAR BUXANI"},
                {"DOB", "27-Aug-90"},
                {"Expiry", "5-Aug-23"},
                {"Nationality", "INDIAN"},
                {"Gender", "M"}
            };
            string extractedDOE = "", listItem = "";
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedDOE, ExtractedDOE"
            };
            resultCSVFile = "ResultDOE_" + expectedResult["FileName"].Replace('.', '_') + "_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "PassportMRZParserStrategyDateOnly";
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                List<string> lstValues = new List<string>();
                listItem += Path.GetFileName(expectedResult["FileName"].ToString()) + ", " + expectedResult["Expiry"].ToString() + ", ";
                //Expected Result
                string doeValueToCompare = expectedResult["Expiry"].ToString();
                //ActualFilePath
                string actualFilePath = TestParameters.PendingFolder + "\\" + expectedResult["FileName"].ToString();
                TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(expectedResult["FileName"].ToString());
                TestParameters.DeleteExistingTempPath();
                var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                //Execute Strategy for filename
                var strategyExecRes = strategy.Execute(actualFilePath);
                foreach (var text in strategyExecRes.Values)
                {
                    lstValues.Add($"{text.Key} - {text.Value}");
                }
                //Filter out only desired resultset for date
                var extractedValuesLst = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 11);
                if (extractedValuesLst.Any())
                {
                    foreach (var extractedVal in extractedValuesLst)
                    {
                        string dateExtract = TestParameters.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                        if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                        {
                            continue;
                        }
                        if (Convert.ToDateTime(doeValueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                        {
                            extractedDOE += string.Format("MatchedDOE >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                        }
                        else
                        {
                            extractedDOE += string.Format("Non-MatchedDOE  >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                        }
                    }
                }
                strategy = null;
                listItem += extractedDOE;
                resultLst.Add(listItem);
                Assert.IsFalse(false);
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
                Assert.IsFalse(true);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }

        [TestMethod]
        public void ReadImageFromTesseract()
        {
            string filePath = @"C:\DATAS\PROJECT\206\DataSet\Working\Passport\Processing\3\PassportMRZParserStrategyDateOnly\";
            string fileName = "149_extract_adaptive_41_blk_15.jpeg";
            var text = ocr.Read(filePath+fileName);
        }
    }
}