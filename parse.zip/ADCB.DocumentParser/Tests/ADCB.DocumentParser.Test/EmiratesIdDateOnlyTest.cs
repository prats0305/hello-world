﻿using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class EmiratesIdDateOnlyTest
    {
        DataTable csvData = null;
        string resultCSVFile, resultCSVFilePath;
        ImageToTextReaderTessaractMICR ocr;
        ImageProcessor imageProcessor;
        List<Type> strategies;
        [TestInitialize]
        public void Init()
        {
            TestParameters.ImageType = "EmiratesId";
            string expectedDataFilePath = @"C:\DevProject\MRZParser\Scripts\SampleDataV2\Source\EmiratesId\";
            string expectedDataCSV = "EIDA.csv";
            csvData = TestParameters.GetDataTableFromCsv(expectedDataCSV, expectedDataFilePath);
            resultCSVFilePath = @"C:\DevProject\MRZParser\Source\ADCB.DocumentParser\ADCB.DocumentParser.Test\UnitTestResult\";
            ocr = new ImageToTextReaderTessaractMICR();
            imageProcessor = new ImageProcessor();
            strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                              .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();
        }

        [TestMethod]
        public void TestDOBInAllFiles()
        {
            string extractedDOB = "", listItem = "";
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedDOB, ExtractedDOB"
            };
            resultCSVFile = "ResultEmiratesIdDOB_All_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "EmiratesIdMRZParserStrategyDateOnly";
            try
            {                
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);                                
                foreach (DataRow item in csvData.Rows)
                {
                    List<string> lstValues = new List<string>();
                    extractedDOB = listItem = "";     
                    listItem += Path.GetFileName(item["FileName"].ToString()) + ", " + item["DOB"].ToString() + ", ";
                    //Expected Result
                    string dobValueToCompare = item["DOB"].ToString();
                    //ActualFilePath
                    string actualFilePath = TestParameters.PendingFolder + "\\" + item["FileName"].ToString();
                    TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(item["FileName"].ToString());
                    TestParameters.DeleteExistingTempPath();
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                    //Execute Strategy for filename
                    var strategyExecRes = strategy.Execute(actualFilePath);                    
                    foreach (var text in strategyExecRes.Values)
                    {
                        lstValues.Add($"{text.Key} - {text.Value}");
                    }
                    //Filter out only desired resultset for date
                    var extractedValuesLst = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 11);
                    if (extractedValuesLst.Any())
                    {
                        foreach (var extractedVal in extractedValuesLst)
                        {
                            string dateExtract = TestParameters.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                            if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                            {
                                continue;
                            }
                            if (Convert.ToDateTime(dobValueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                            {
                                extractedDOB += string.Format("MatchedDOB >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                            }
                            else
                            {
                                extractedDOB += string.Format("Non-MatchedDOB  >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                            }
                        }
                    }
                    strategy = null;
                    listItem += extractedDOB;
                    resultLst.Add(listItem);
                }
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }

        [TestMethod]
        public void TestDOEInAllFiles()
        {
            string extractedDOE = "", listItem = "";
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedDOE, ExtractedDOE"
            };
            resultCSVFile = "ResultDOE_All_"+  DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "EmiratesIdMRZParserStrategyDateOnly";
            try
            {                
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);                               
                foreach (DataRow item in csvData.Rows)
                {                    
                    List<string> lstValues = new List<string>();
                    extractedDOE = listItem = "";
                    listItem += Path.GetFileName(item["FileName"].ToString()) + ", ";
                    listItem += item["Expiry"].ToString() + ", ";
                    //Expected Result
                    string dobValueToCompare = item["Expiry"].ToString();
                    //ActualFile
                    string actualFilePath = TestParameters.PendingFolder + "\\" + item["FileName"].ToString();
                    TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(item["FileName"].ToString());
                    
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                    //Execute Strategy for filename
                    var strategyExecRes = strategy.Execute(actualFilePath);
                    foreach (var text in strategyExecRes.Values)
                    {
                        lstValues.Add($"{text.Key} - {text.Value}");
                    }
                    //Filter out only desired resultset for date
                    var extractedValuesLst = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 11);
                    if (extractedValuesLst.Any())
                    {
                        foreach (var extractedVal in extractedValuesLst)
                        {
                            string dateExtract = TestParameters.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                            if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                            {
                                continue;
                            }
                            if (Convert.ToDateTime(dobValueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                            {
                                extractedDOE += string.Format("MatchedDOE >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                            }
                            else
                            {
                                extractedDOE += string.Format("Non-MatchedDOE  >> {0} >> {1}", extractedVal.Key, extractedVal.Value);
                            }
                        }
                    }
                    strategy = null;
                    listItem += extractedDOE;
                    resultLst.Add(listItem);
                }
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }                               
    }
}
