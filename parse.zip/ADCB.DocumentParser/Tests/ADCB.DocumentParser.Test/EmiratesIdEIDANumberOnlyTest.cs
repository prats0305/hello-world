﻿using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class EmiratesIdEIDANumberOnlyTest
    {
        DataTable csvData = null;
        string resultCSVFile, resultCSVFilePath;
        ImageToTextReaderTessaractMICR ocr;
        ImageProcessor imageProcessor;
        List<Type> strategies;
        [TestInitialize]
        public void Init()
        {
            TestParameters.ImageType = "EmiratesId";
            string expectedDataFilePath = @"C:\DevProject\MRZParser\Scripts\SampleDataV2\Source\EmiratesId\";
            string expectedDataCSV = "EIDA.csv";
            csvData = TestParameters.GetDataTableFromCsv(expectedDataCSV, expectedDataFilePath);
            resultCSVFilePath = @"C:\DevProject\MRZParser\Source\ADCB.DocumentParser\ADCB.DocumentParser.Test\UnitTestResult\";
            ocr = new ImageToTextReaderTessaractMICR();
            imageProcessor = new ImageProcessor();
            strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                              .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();
        }

        [TestMethod]
        public void TestEIDANumberInAllFiles()
        {
            string extractedEIDA = "", listItem = "";
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedEIDA, ExtractedEIDA"
            };
            resultCSVFile = "ResultEmiratesIdEIDA_All_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "EmiratesIdMRZParserStrategyDirect";
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                foreach (DataRow item in csvData.Rows)
                {
                    List<string> lstValues = new List<string>();
                    extractedEIDA = listItem = "";
                    listItem += Path.GetFileName(item["FileName"].ToString()) + ", " + item["EmiratesId"].ToString() + ", ";
                    //Expected Result
                    string eidaValueToCompare = item["EmiratesId"].ToString();
                    //ActualFilePath
                    string actualFilePath = TestParameters.PendingFolder + "\\" + item["FileName"].ToString();
                    TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(item["FileName"].ToString());
                    TestParameters.DeleteExistingTempPath();
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                    //Execute Strategy for filename
                    var strategyExecRes = strategy.Execute(actualFilePath);
                    foreach (var text in strategyExecRes.Values)
                    {
                        lstValues.Add($"{text.Key} - {text.Value}");
                    }
                    //Filter out only desired resultset for EIDA
                    var extractedValuesLst = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                    if (extractedValuesLst.Any())
                    {
                        if (extractedValuesLst.Any())
                        {
                            foreach (var extractedVal in extractedValuesLst)
                            {
                                string emiratesIdExtract = TestParameters.FormatEmiratesId(extractedVal.Value.ToUpper().Replace(@" ", ""));

                                if (eidaValueToCompare.Equals(emiratesIdExtract))
                                {
                                    extractedEIDA += string.Format("MatchedEIDA >> {0} ", extractedVal.Key);
                                    break;
                                }

                                else if (eidaValueToCompare.Replace("-", "").Equals(emiratesIdExtract.Replace("-", "")))
                                {
                                    //matched              
                                    extractedEIDA += string.Format("MatchedEIDA >> {0} ", extractedVal.Key);
                                    break;
                                }
                                else
                                {
                                    var distance = LevenshteinDistance.Compute(eidaValueToCompare.Replace("-", ""), emiratesIdExtract.Replace("-", ""));
                                    if (distance < 4 || distance > 10)
                                    {
                                        var extractedValuesLstMRZ = strategyExecRes.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                                        if (extractedValuesLstMRZ.Any())
                                        {
                                            var matchingvalues = extractedValuesLstMRZ.Where(x => x.Value.Replace(" ", "").Trim().Contains(eidaValueToCompare.Replace("-", "").Substring(3)));
                                            if (!string.IsNullOrEmpty(matchingvalues.Select(x => x.Value).FirstOrDefault()))
                                            {
                                                extractedEIDA += string.Format("MatchedEIDA >> {0} ", matchingvalues.FirstOrDefault().Key);
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    strategy = null;
                    listItem += extractedEIDA;
                    resultLst.Add(listItem);
                }
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }

    }
}
