﻿using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.Common.Constants;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.Test
{
    [TestClass]
    public class EmiratesIdGenderOnlyTest
    {
        DataTable csvData = null;
        string resultCSVFile, resultCSVFilePath;
        ImageToTextReaderTessaractMICR ocr;
        ImageProcessor imageProcessor;
        List<Type> strategies;
        [TestInitialize]
        public void Init()
        {
            TestParameters.ImageType = "EmiratesId";
            string expectedDataFilePath = @"C:\DevProject\MRZParser\Scripts\SampleDataV2\Source\EmiratesId\";
            string expectedDataCSV = "EIDA.csv";
            csvData = TestParameters.GetDataTableFromCsv(expectedDataCSV, expectedDataFilePath);
            resultCSVFilePath = @"C:\DevProject\MRZParser\Source\ADCB.DocumentParser\ADCB.DocumentParser.Test\UnitTestResult\";
            ocr = new ImageToTextReaderTessaractMICR();
            imageProcessor = new ImageProcessor();
            strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                              .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();
        }

        [TestMethod]
        public void TestGenderInAllFiles()
        {
            string extractedGender = "", listItem = "";
            List<string> resultLst = new List<string>
            {
                "FileName, ExpectedGender, ExtractedGender"
            };
            resultCSVFile = "ResultEmiratesIdGender_All_" + DateTime.Now.ToString(TestParameters.DateFormat) + ".csv";
            TestParameters.StrategyTypeStr = "EmiratesIdMRZParserStrategyGenderOnly";
            try
            {
                var strategyType = strategies.FirstOrDefault(s => s.Name == TestParameters.StrategyTypeStr);
                foreach (DataRow item in csvData.Rows)
                {
                    List<string> lstValues = new List<string>();
                    extractedGender = listItem = "";
                    listItem += Path.GetFileName(item["FileName"].ToString()) + ", " + item["Gender"].ToString() + ", ";
                    //Expected Result
                    string genderValueToCompare = item["Gender"].ToString();
                    //ActualFilePath
                    string actualFilePath = TestParameters.PendingFolder + "\\" + item["FileName"].ToString();
                    TestParameters.ImgNameWithoutExt = Path.GetFileNameWithoutExtension(item["FileName"].ToString());
                    TestParameters.DeleteExistingTempPath();
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TestParameters.TempPath, imageProcessor, ocr);
                    //Execute Strategy for filename
                    var strategyExecRes = strategy.Execute(actualFilePath);
                    foreach (var text in strategyExecRes.Values)
                    {
                        lstValues.Add($"{text.Key} - {text.Value}");
                    }
                    //Filter out only desired resultset for Gender                

                    var matchingvalues = strategyExecRes.Values.Where(x => x.Value.Contains(AppConstants.Gender) && x.Value.Contains(genderValueToCompare)).FirstOrDefault();

                    if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                    {
                        extractedGender += string.Format("MatchedGender >> {0}", matchingvalues.Key);
                    }

                    else
                    {
                        var matches = strategyExecRes.Values.Where(v => v.Value.Equals(genderValueToCompare, StringComparison.CurrentCultureIgnoreCase));
                        if (matches.Any())
                        {
                            foreach (var match in matches)
                            {
                                extractedGender += string.Format("MatchedGender >> {0}", match.Key);                             
                            }
                        }
                    }

                    strategy = null;
                    listItem += extractedGender;
                    resultLst.Add(listItem);
                }
            }
            catch (Exception Ex)
            {
                string exc = Ex.ToString();
                resultLst.Add(exc);
            }
            finally
            {
                TestParameters.WriteTextToCsv(resultLst, resultCSVFile, resultCSVFilePath);
            }
        }

    }
}
