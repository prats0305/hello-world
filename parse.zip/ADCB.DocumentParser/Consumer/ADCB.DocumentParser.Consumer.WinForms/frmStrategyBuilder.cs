﻿using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ.Strategies;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADCB.DocumentParser.Consumer.WinForms
{
    public partial class frmStrategyBuilder : Form
    {
        public frmStrategyBuilder()
        {
            InitializeComponent();
        }

        public string FileName { get; set; }
        private List<string> selectedImageProcessor = new List<string>();

        private List<ImageProcessingComponentInfo> imageProcessingComponents = new List<ImageProcessingComponentInfo>();

        public void Init()
        {
            //pcBxMain.ImageLocation = FileName;
            //pcBxMain.SizeMode = PictureBoxSizeMode.StretchImage;
            loadImageProcessors();

            loadStrategies();
        }

        private void loadStrategies()
        {
            var strategies = System.IO.Directory.GetFiles(StrategiesFolder, "*.xml");
            cmbBxStrategies.Items.Clear();
            foreach (var strategy in strategies)
            {
                cmbBxStrategies.Items.Add(System.IO.Path.GetFileNameWithoutExtension(strategy));
            }
        }

        private void loadImageProcessors()
        {
            try
            {
                //string path = @"C:\WF\MRZParser\Dev\Source\ADCB.DocumentParser\ADCB.DocumentParser.API.DAL.DocumentParser\bin\Debug\ADCB.DocumentParser.API.DAL.DocumentParser.dll";
                //byte[] buffer = File.ReadAllBytes(path);
                //appDomain = AppDomain.CreateDomain("StrategiesDomain");
                //Assembly assm = appDomain.Load(buffer);

                var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                   .Where(p => typeof(IImageProcessorComponent).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();

                cmbBxComponents.Items.Clear();
                foreach (var strategy in strategies)
                {
                    cmbBxComponents.Items.Add(strategy.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                //if (appDomain != null)
                //    AppDomain.Unload(appDomain);
            }
        }

       


        private void btnMoveUp_Click(object sender, EventArgs e)
        {

        }

        private void btnMoveDown_Click(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

        }
        public string ProcessingFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], "Passport", "Processing");
            }
        }
        public string StrategiesFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], "StrategiesFolder");
            }
        }
        public string TempPath
        {
            get
            {
                var image = System.IO.Path.GetFileNameWithoutExtension(FileName);
                return System.IO.Path.Combine(ProcessingFolder, image, "StrategyBuilder");
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            try
            {
                IImageProcessorComponent component = null;

                var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                  .Where(p => typeof(IImageProcessorComponent).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();


                for (int i = lstBxComponents.Items.Count -1; i>=0; i--)
                {
                    var componentName = lstBxComponents.Items[i].ToString().Split('-')[1];

                    var strategyCompType = strategies.FirstOrDefault(s => s.Name == componentName);

                    component = (IImageProcessorComponent)Activator.CreateInstance(strategyCompType, component, lstBxComponents.Items[i].ToString());
                }

                if(!System.IO.Directory.Exists(TempPath))
                {
                    System.IO.Directory.CreateDirectory(TempPath);
                }
                else
                {
                    System.IO.Directory.Delete(TempPath, true);
                }

                component.Process(new ImageToProcess<Bgr, byte>(FileName, TempPath));


                imgList.Images.Clear();
                lstVwItems.Items.Clear();

                var images = System.IO.Directory.GetFiles(TempPath);
                lstVwItems.View = View.LargeIcon;
                lstVwItems.LargeImageList = imgList;

                var size = 64;

                imgList.ImageSize = new Size(size, size);
                // imgList.ColorDepth = ColorDepth.Depth32Bit;

                var strategyImages = images.Select(img => new {
                    Name = System.IO.Path.GetFileNameWithoutExtension(img),
                    FullPath = img,
                    Group = System.IO.Path.GetFileNameWithoutExtension(img).Split(new string[] { "--" }, StringSplitOptions.RemoveEmptyEntries)[0]
                });

                

                foreach (var img in strategyImages)
                {
                    imgList.Images.Add(img.Name, Image.FromFile(img.FullPath));
                    var item = lstVwItems.Items.Add(img.Name);
                    ListViewGroup lstVwGroup = null;
                    foreach(ListViewGroup group in lstVwItems.Groups)
                    {
                        if(group.Header == img.Group)
                        {
                            lstVwGroup = group;
                            break;
                        }
                    }
                    if(lstVwGroup == null)
                    {
                        lstVwGroup = new ListViewGroup(img.Group);
                        lstVwItems.Groups.Add(lstVwGroup);
                    }

                    item.Group = lstVwGroup;
                    item.ImageKey = img.Name;
                }
            }
            catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnSaveStrategy_Click(object sender, EventArgs e)
        {
            try
            {
                var savePath = System.IO.Path.Combine(StrategiesFolder, txtBxStrategyName.Text + ".xml");

                imageProcessingComponents.Serialize(savePath);

                loadStrategies();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                var component = $"{lstBxComponents.Items.Count}-{cmbBxComponents.SelectedItem}";
                selectedImageProcessor.Add(component);

                imageProcessingComponents.Add(new ImageProcessingComponentInfo()
                {
                    ComponentName = cmbBxComponents.SelectedItem.ToString()
                });

                lstBxComponents.DataSource = null;
                lstBxComponents.DataSource = selectedImageProcessor;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void cmbBxComponents_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var strategyXml = System.IO.Path.Combine(StrategiesFolder, cmbBxStrategies.SelectedItem.ToString() +".xml");

                imageProcessingComponents.Clear();
                imageProcessingComponents.Deserialize(strategyXml);

                selectedImageProcessor.Clear();
                selectedImageProcessor.AddRange(imageProcessingComponents.Select((p, i) => $"{i}-{p.ComponentName}"));

                lstBxComponents.DataSource = null;
                lstBxComponents.DataSource = selectedImageProcessor;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void lstVwItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var fileName = System.IO.Path.Combine(TempPath, lstVwItems.SelectedItems[0].ImageKey + ".jpeg");
                System.Diagnostics.Process.Start(fileName);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void lstBxComponents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstBxComponents.SelectedIndex >= -1)
            {
                IImageProcessorComponent component = null;

                var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                  .Where(p => typeof(IImageProcessorComponent).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();

                var componentName = lstBxComponents.SelectedItem.ToString().Split('-')[1];

                var strategyCompType = strategies.FirstOrDefault(s => s.Name == componentName);

                component = (IImageProcessorComponent)Activator.CreateInstance(strategyCompType, component, componentName);

                var param = component.Parameter;
                if (param != null)
                {
                    txtBxParams.Text = param.Serialize();
                }
                else
                {
                    txtBxParams.Text = "";
                }
            }
        }
    }
}
