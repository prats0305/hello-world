﻿namespace ADCB.DocumentParser.Consumer.WinForms
{
    partial class frmStrategyBuilder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.lstBxComponents = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbBxComponents = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cmbBxStrategies = new System.Windows.Forms.ComboBox();
            this.btnLoadStrategy = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBxStrategyName = new System.Windows.Forms.TextBox();
            this.btnSaveStrategy = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExecute = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMoveDown = new System.Windows.Forms.Button();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.lstVwItems = new System.Windows.Forms.ListView();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.txtBxParams = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lstVwItems);
            this.splitContainer1.Size = new System.Drawing.Size(800, 450);
            this.splitContainer1.SplitterDistance = 266;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.lstBxComponents);
            this.splitContainer2.Panel1.Controls.Add(this.panel1);
            this.splitContainer2.Panel1.Controls.Add(this.panel4);
            this.splitContainer2.Panel1.Controls.Add(this.panel3);
            this.splitContainer2.Panel1.Controls.Add(this.panel2);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.txtBxParams);
            this.splitContainer2.Size = new System.Drawing.Size(266, 450);
            this.splitContainer2.SplitterDistance = 271;
            this.splitContainer2.TabIndex = 0;
            // 
            // lstBxComponents
            // 
            this.lstBxComponents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxComponents.FormattingEnabled = true;
            this.lstBxComponents.Location = new System.Drawing.Point(0, 46);
            this.lstBxComponents.Name = "lstBxComponents";
            this.lstBxComponents.Size = new System.Drawing.Size(218, 202);
            this.lstBxComponents.TabIndex = 2;
            this.lstBxComponents.SelectedIndexChanged += new System.EventHandler(this.lstBxComponents_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmbBxComponents);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 23);
            this.panel1.TabIndex = 5;
            // 
            // cmbBxComponents
            // 
            this.cmbBxComponents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbBxComponents.FormattingEnabled = true;
            this.cmbBxComponents.Location = new System.Drawing.Point(0, 0);
            this.cmbBxComponents.Name = "cmbBxComponents";
            this.cmbBxComponents.Size = new System.Drawing.Size(170, 21);
            this.cmbBxComponents.TabIndex = 0;
            this.cmbBxComponents.SelectedIndexChanged += new System.EventHandler(this.cmbBxComponents_SelectedIndexChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnAdd.Location = new System.Drawing.Point(170, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(48, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click_1);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cmbBxStrategies);
            this.panel4.Controls.Add(this.btnLoadStrategy);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(218, 23);
            this.panel4.TabIndex = 4;
            // 
            // cmbBxStrategies
            // 
            this.cmbBxStrategies.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbBxStrategies.FormattingEnabled = true;
            this.cmbBxStrategies.Location = new System.Drawing.Point(0, 0);
            this.cmbBxStrategies.Name = "cmbBxStrategies";
            this.cmbBxStrategies.Size = new System.Drawing.Size(170, 21);
            this.cmbBxStrategies.TabIndex = 0;
            // 
            // btnLoadStrategy
            // 
            this.btnLoadStrategy.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLoadStrategy.Location = new System.Drawing.Point(170, 0);
            this.btnLoadStrategy.Name = "btnLoadStrategy";
            this.btnLoadStrategy.Size = new System.Drawing.Size(48, 23);
            this.btnLoadStrategy.TabIndex = 2;
            this.btnLoadStrategy.Text = "Load";
            this.btnLoadStrategy.UseVisualStyleBackColor = true;
            this.btnLoadStrategy.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtBxStrategyName);
            this.panel3.Controls.Add(this.btnSaveStrategy);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 248);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(218, 23);
            this.panel3.TabIndex = 3;
            // 
            // txtBxStrategyName
            // 
            this.txtBxStrategyName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBxStrategyName.Location = new System.Drawing.Point(0, 0);
            this.txtBxStrategyName.Name = "txtBxStrategyName";
            this.txtBxStrategyName.Size = new System.Drawing.Size(170, 20);
            this.txtBxStrategyName.TabIndex = 2;
            // 
            // btnSaveStrategy
            // 
            this.btnSaveStrategy.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSaveStrategy.Location = new System.Drawing.Point(170, 0);
            this.btnSaveStrategy.Name = "btnSaveStrategy";
            this.btnSaveStrategy.Size = new System.Drawing.Size(48, 23);
            this.btnSaveStrategy.TabIndex = 1;
            this.btnSaveStrategy.Text = "Save Strategy";
            this.btnSaveStrategy.UseVisualStyleBackColor = true;
            this.btnSaveStrategy.Click += new System.EventHandler(this.btnSaveStrategy_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnExecute);
            this.panel2.Controls.Add(this.btnRemove);
            this.panel2.Controls.Add(this.btnMoveDown);
            this.panel2.Controls.Add(this.btnMoveUp);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(218, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(48, 271);
            this.panel2.TabIndex = 1;
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(1, 200);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(44, 23);
            this.btnExecute.TabIndex = 3;
            this.btnExecute.Text = "Execute";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(0, 157);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(44, 23);
            this.btnRemove.TabIndex = 2;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnMoveDown
            // 
            this.btnMoveDown.Location = new System.Drawing.Point(2, 113);
            this.btnMoveDown.Name = "btnMoveDown";
            this.btnMoveDown.Size = new System.Drawing.Size(44, 23);
            this.btnMoveDown.TabIndex = 1;
            this.btnMoveDown.Text = "Down";
            this.btnMoveDown.UseVisualStyleBackColor = true;
            this.btnMoveDown.Click += new System.EventHandler(this.btnMoveDown_Click);
            // 
            // btnMoveUp
            // 
            this.btnMoveUp.Location = new System.Drawing.Point(2, 66);
            this.btnMoveUp.Name = "btnMoveUp";
            this.btnMoveUp.Size = new System.Drawing.Size(44, 23);
            this.btnMoveUp.TabIndex = 0;
            this.btnMoveUp.Text = "Up";
            this.btnMoveUp.UseVisualStyleBackColor = true;
            this.btnMoveUp.Click += new System.EventHandler(this.btnMoveUp_Click);
            // 
            // lstVwItems
            // 
            this.lstVwItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstVwItems.Location = new System.Drawing.Point(0, 0);
            this.lstVwItems.Name = "lstVwItems";
            this.lstVwItems.Size = new System.Drawing.Size(530, 450);
            this.lstVwItems.TabIndex = 0;
            this.lstVwItems.UseCompatibleStateImageBehavior = false;
            this.lstVwItems.SelectedIndexChanged += new System.EventHandler(this.lstVwItems_SelectedIndexChanged);
            // 
            // imgList
            // 
            this.imgList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imgList.ImageSize = new System.Drawing.Size(16, 16);
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // txtBxParams
            // 
            this.txtBxParams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBxParams.Location = new System.Drawing.Point(0, 0);
            this.txtBxParams.Multiline = true;
            this.txtBxParams.Name = "txtBxParams";
            this.txtBxParams.Size = new System.Drawing.Size(266, 175);
            this.txtBxParams.TabIndex = 0;
            // 
            // frmStrategyBuilder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer1);
            this.Name = "frmStrategyBuilder";
            this.Text = "frmStrategyBuilder";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListBox lstBxComponents;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnMoveDown;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtBxStrategyName;
        private System.Windows.Forms.Button btnSaveStrategy;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmbBxComponents;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cmbBxStrategies;
        private System.Windows.Forms.Button btnLoadStrategy;
        private System.Windows.Forms.ListView lstVwItems;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.TextBox txtBxParams;
    }
}