﻿using ADCB.DocumentParser.API.BLL.ImageProcessing;
using ADCB.DocumentParser.API.BLL.Interfaces;
using ADCB.DocumentParser.API.DAL.DocumentParser;
//using ADCB.DocumentParser.API.DAL.DocumentParser.OCR;
using ADCB.DocumentParser.API.DAL.DocumentParser.PassportMRZ.Strategies;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADCB.DocumentParser.Consumer.WinForms
{
    public partial class frmImgParser : Form
    {
        DocumentParserFacade _DocumentParserFacade;
        UnityContainer _container = new UnityContainer();

        public frmImgParser()
        {
            InitializeComponent();

            cmbBxImageType.Text = "Passport";
            fillLists();

            foreach (var en in Enum.GetNames(typeof(RotateFlipType)))
            {
                cmbRotate.Items.Add(en);
            }
            cmbRotate.SelectedItem = RotateFlipType.Rotate90FlipNone.ToString();

            //var dir = @"C:\Pramod\Projects\MRZ_Parser\scripts\prod-files\MRZ\MRZ";

            //foreach(var dirTMp in System.IO.Directory.GetDirectories(dir))
            //{
            //    var cid = System.IO.Path.GetFileNameWithoutExtension(dirTMp);
            //}

        }


        private void CmbBxImageType_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void fillLists()
        {
            try
            {
                this.Text = $"Parse : {cmbBxImageType.Text}";

                if (!System.IO.Directory.Exists(SourceFolder))
                {
                    System.IO.Directory.CreateDirectory(SourceFolder);
                }

                if (!System.IO.Directory.Exists(PendingFolder))
                {
                    System.IO.Directory.CreateDirectory(PendingFolder);
                }

                if (!System.IO.Directory.Exists(SuccessFolder))
                {
                    System.IO.Directory.CreateDirectory(SuccessFolder);
                }

                if (!System.IO.Directory.Exists(FailedFolder))
                {
                    System.IO.Directory.CreateDirectory(FailedFolder);
                }
                if (!System.IO.Directory.Exists(ProcessingFolder))
                {
                    System.IO.Directory.CreateDirectory(ProcessingFolder);
                }
                if (!System.IO.Directory.Exists(StrategiesFolder))
                {
                    System.IO.Directory.CreateDirectory(StrategiesFolder);
                }

                //move to pending from source

                fillListWithFileNames(PendingFolder, lstBxPending, tbPagePendingFiles);
                fillListWithFileNames(SuccessFolder, lstBxSucceeded, tbPageSucceeded);
                fillListWithFileNames(FailedFolder, lstBxFailed, tbPageFailed);

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public string SourceFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["SourceFolder"], cmbBxImageType.Text);
            }
        }

        private void fillListWithFileNames(string folder, ListBox listBox, TabPage tbPage)
        {
            var files = System.IO.Directory.GetFiles(folder);
            listBox.Items.Clear();
            foreach (var file in files)
            {
                listBox.Items.Add(System.IO.Path.GetFileName(file));
            }
            tbPage.Text = $"{System.IO.Path.GetFileName(folder)} ({listBox.Items.Count})";
        }

        private void copyFile(string fileName, string destinationFolder)
        {
            var destPath = System.IO.Path.Combine(destinationFolder, System.IO.Path.GetFileName(fileName));
            if (!System.IO.File.Exists(destPath))
            {
                System.IO.File.Copy(fileName, destPath);
            }
        }

        public string DataFile
        {
            get
            {
                return System.IO.Path.Combine(SourceFolder, "data.csv");
            }
        }


        public string PendingFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], cmbBxImageType.Text, "Pending");
            }
        }
        public string StrategiesFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], "StrategiesFolder");
            }
        }
        public string ProcessingFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], cmbBxImageType.Text, "Processing");
            }
        }

        public string SuccessFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], cmbBxImageType.Text, "Success");
            }
        }

        public string FailedFolder
        {
            get
            {
                return System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings["WorkingFolder"], cmbBxImageType.Text, "Failed");
            }
        }

        private void getNewImagesFromSource()
        {
            var files = System.IO.Directory.GetFiles(SourceFolder);

            foreach (var file in files)
            {
                copyFile(file, PendingFolder);
            }
        }

        private void btnGetNewImagesInSource_Click(object sender, EventArgs e)
        {
            getNewImagesFromSource();
            fillLists();
        }

        private void lstBxPending_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadImage(PendingFolder, lstBxPending.SelectedItem.ToString());
        }

        private void lstBxFailed_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadImage(FailedFolder, lstBxPending.SelectedItem.ToString());
        }

        private void lstBxSucceeded_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadImage(SuccessFolder, lstBxPending.SelectedItem.ToString());
        }

        private void loadImage(string folder, string fileName)
        {
            try
            {
                var fileNameFull = System.IO.Path.Combine(folder, fileName);
                if (System.IO.File.Exists(fileNameFull))
                {
                    picBx.ImageLocation = fileNameFull;
                    picBx.SizeMode = PictureBoxSizeMode.StretchImage;

                    var csvFiles = System.IO.Directory.GetFiles(SourceFolder, "*.csv");
                    fillData(fileName, csvFiles);

                    getStrategies();

                    lstBxStrategyResult.Items.Clear();
                    trVwResult.Nodes.Clear();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void getStrategies()
        {
            //AppDomain appDomain = null;
            try
            {
                //string path = @"C:\WF\MRZParser\Dev\Source\ADCB.DocumentParser\ADCB.DocumentParser.API.DAL.DocumentParser\bin\Debug\ADCB.DocumentParser.API.DAL.DocumentParser.dll";
                //byte[] buffer = File.ReadAllBytes(path);

                //appDomain = AppDomain.CreateDomain("StrategiesDomain");
                //Assembly assm = appDomain.Load(buffer);

                var x = new PassportMRZParserStrategyDirect("", null, null);

                var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                   .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();

                lstBxStrategies.Items.Clear();
                foreach (var strategy in strategies)
                {
                    lstBxStrategies.Items.Add(strategy.Name);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                //if (appDomain != null)
                //    AppDomain.Unload(appDomain);
            }
        }

        private void fillData(string fileName, string[] csvFiles)
        {
            _DocumentParserFacade = new DocumentParserFacade(_container);
            string cid = fileName.Substring(0, fileName.IndexOf('.'));
            //var values = _DocumentParserFacade.GetMRZCustomerInformationFromCID(cid);
            var values = getActualData();
            lstBxData.Items.Clear();
            foreach (var item in values)
            {
                lstBxData.Items.Add($"{item.Key.PadRight(5, ' ')}:{item.Value}");
            }
        }

        private IEnumerable<KeyValuePair<string, string>> getActualData()
        {
            string fileName = System.IO.Path.GetFileName(picBx.ImageLocation);
            var csvFiles = System.IO.Directory.GetFiles(SourceFolder, "*.csv");
            foreach (var csvFile in csvFiles)
            {
                var lines = System.IO.File.ReadAllLines(csvFile);
                if (lines.Count() > 0)
                {
                    var header = lines[0].Split(',').ToList();

                    var fileNameIndex = header.IndexOf("FileName");
                    if (fileNameIndex > -1)
                    {
                        var file = System.IO.Path.GetFileName(fileName);
                        var lineOfInterest = lines.Skip(1).Select(l => l.Split(','))
                            .FirstOrDefault(l => l.Count() >= fileNameIndex && l[fileNameIndex].Equals(file, StringComparison.InvariantCultureIgnoreCase));

                        if (lineOfInterest != null)
                        {
                            for (var i = 0; i < header.Count; i++)
                            {
                                yield return new KeyValuePair<string, string>(header[i], lineOfInterest[i]);
                            }
                        }

                    }
                }
            }
            yield break;
        }



        private void btnRotateRight_Click(object sender, EventArgs e)
        {
            try
            {
                var rotate = cmbRotate.SelectedItem;
                if (rotate == null || string.IsNullOrEmpty(rotate.ToString()))
                {
                    return;
                }

                var rotateEn = (RotateFlipType)Enum.Parse(typeof(RotateFlipType), rotate.ToString());
                picBx.Image.RotateFlip(rotateEn);
                picBx.Refresh();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void lnkOpen_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(picBx.ImageLocation);
        }

        public string TempPath
        {
            get
            {
                var image = System.IO.Path.GetFileNameWithoutExtension(picBx.ImageLocation);
                return System.IO.Path.Combine(ProcessingFolder, image, lstBxStrategies.SelectedItem == null ? "" : lstBxStrategies.SelectedItem.ToString());
            }
        }

        private void lstBxStrategies_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                var strategies = AppDomain.CurrentDomain.GetAssemblies().SelectMany(s => s.GetTypes())
                 .Where(p => typeof(IDocumentParserStrategy).IsAssignableFrom(p) && p.IsClass && !p.IsAbstract).ToList();

                var image = System.IO.Path.GetFileNameWithoutExtension(picBx.ImageLocation);
                var ocr = new ImageToTextReaderTessaractMICR();
                var imageProcessor = new ImageProcessor();
                var strategyType = strategies.FirstOrDefault(s => s.Name == lstBxStrategies.SelectedItem.ToString());
                try
                {
                    if (System.IO.Directory.Exists(TempPath))
                    {
                        System.IO.Directory.Delete(TempPath, true);
                    }
                }
                catch
                { }

                if (strategyType != null)
                {
                    var strategy = (IDocumentParserStrategy)Activator.CreateInstance(strategyType, TempPath, imageProcessor, ocr);
                    var result = strategy.Execute(picBx.ImageLocation);

                    lstBxStrategyResult.Items.Clear();

                    foreach (var text in result.Values)
                    {
                        lstBxStrategyResult.Items.Add($"{text.Key} - {text.Value}");
                    }
                    //  var image = System.IO.Path.GetFileNameWithoutExtension(picBx.ImageLocation);             

                    var documentParserFacade = new DocumentParserFacade(_container);
                    string cid = (image.Contains(".")) ? image.Substring(0, image.IndexOf('.')) : image;
                    //var actualData = documentParserFacade.GetMRZCustomerInformationFromCID(cid);
                    var actualData = getActualData();
                    trVwResult.Nodes.Clear();
                    var nodeMatched = trVwResult.Nodes.Add("Matched");
                    var nodeNotMatching = trVwResult.Nodes.Add("NotMatching");
                    //var nodePartialMatch = trVwResult.Nodes.Add("PartialMatching");
                    TreeNode matchedNode = null;
                    TreeNode notMatchedNode = null;

                    foreach (var data in actualData)
                    {
                        if (data.Key == "CID" || data.Key == "FileName" || data.Key == "Comments" || data.Key == "Quality")
                        {
                            continue;
                        }

                        var valueToCompare = data.Value;
                        if (data.Key == "DOB" || data.Key == "Expiry")
                        {
                            DateTime date = DateTime.Today;
                            bool isMainNodeAdded = false;
                            var extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 8 && v.Value.Length <= 12);
                            if (extractedValuesLst.Any())
                            {

                                foreach (var extractedVal in extractedValuesLst)
                                {
                                    string dateExtract = MRZDocumentDateHelper.FormatExtractedDate(extractedVal.Value.ToUpper().Replace(@" ", ""), out string format);
                                    if (!(DateTime.TryParseExact(dateExtract, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime resultExtractedDate)))
                                    {
                                        continue;
                                    }
                                    if (Convert.ToDateTime(valueToCompare).ToString("dd-MMM-yy").Equals(resultExtractedDate.ToString("dd-MMM-yy")))
                                    {
                                        //matched          
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, extractedVal);
                                    }
                                }
                            }

                            if (!isMainNodeAdded)
                            {
                                extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Contains("<"));
                                var matchingvalues = extractedValuesLst.Where(x => x.Value.Replace(@" ", "").Contains(Convert.ToDateTime(valueToCompare).ToString("yyMMdd"))).FirstOrDefault();
                                //  isMainNodeAdded = false;
                                if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                                {
                                    MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalues);
                                }

                                if (!isMainNodeAdded)
                                {
                                    extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]"));
                                    matchingvalues = extractedValuesLst.Where(x => x.Value.Replace(@" ", "").Contains(Convert.ToDateTime(valueToCompare).ToString("yyMMdd"))).FirstOrDefault();
                                    //  isMainNodeAdded = false;
                                    if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                                    {
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalues);
                                    }
                                }
                            }

                            if (data.Key == "DOB" && (matchedNode != null ? matchedNode.Text != "DOB" : true))
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }

                            if (data.Key == "Expiry" && (matchedNode != null ? matchedNode.Text != "Expiry" : true))
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }
                        if (data.Key == "EmiratesId")
                        {
                            var extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                            if (extractedValuesLst.Any())
                            {
                                bool isMainNodeAdded = false;
                                foreach (var extractedVal in extractedValuesLst)
                                {
                                    string emiratesIdExtract = MRZDocumentEIDAHelper.FormatEmiratesId(extractedVal.Value.ToUpper().Replace(@" ", ""));

                                    if (valueToCompare.Equals(emiratesIdExtract))
                                    {
                                        //matched   
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, extractedVal);
                                    }

                                    else if (valueToCompare.Replace("-", "").Equals(emiratesIdExtract.Replace("-", "")))
                                    {
                                        //matched         
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, extractedVal);
                                    }
                                    else
                                    {
                                        var distance = LevenshteinDistance.Compute(valueToCompare.Replace("-", ""), emiratesIdExtract.Replace("-", ""));
                                        if (distance < 4 || distance > 10)
                                        {
                                            var extractedValuesLstMRZ = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length >= 14);
                                            if (extractedValuesLstMRZ.Any())
                                            {
                                                var matchingvalues = extractedValuesLstMRZ.Where(x => x.Value.Replace(" ", "").Trim().Contains(valueToCompare.Replace("-", "").Substring(3)));
                                                if (!string.IsNullOrEmpty(matchingvalues.Select(x => x.Value).FirstOrDefault()))
                                                {
                                                    MatchedEntryFirstValue(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalues);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (matchedNode != null ? matchedNode.Text != "EmiratesId" : true)
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }

                        if (data.Key == "PassportNo")
                        {
                            var extractedValuesLst = result.Values.Where(v => Regex.IsMatch(v.Value, @"[0-9]") && v.Value.Length > 6);

                            bool isMainNodeAdded = false;

                            if (extractedValuesLst.Any())
                            {
                                foreach (var extractedVal in extractedValuesLst)
                                {
                                    if (valueToCompare.ToUpper().Equals(extractedVal.Value.ToUpper().Replace(@" ", "")))
                                    {
                                        //matched    
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, extractedVal);
                                    }
                                }
                            }

                            if (!isMainNodeAdded)
                            {
                                var extractedValuesList = result.Values.Where(v => v.Value.Contains("<"));
                                var matchingvalue = extractedValuesList.Where(x => x.Value.Contains(valueToCompare)).FirstOrDefault();

                                if (!(string.IsNullOrEmpty(matchingvalue.Key)))
                                {
                                    MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalue);
                                }
                            }

                            if (matchedNode != null ? matchedNode.Text != "PassportNo" : true)
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }

                        if (data.Key == "Nationality")
                        {
                            var extractedValuesLst = result;
                            var matchingvalues = extractedValuesLst.Values.Where(x => x.Value.Replace(" ", "").Trim().Contains(valueToCompare)).FirstOrDefault();
                            bool isMainNodeAdded = false;
                            if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                            {
                                MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalues);
                            }

                            if (!isMainNodeAdded)
                            {
                                //string nationalityCode = documentParserFacade.GetNationalityCode(valueToCompare);
                                string nationalityCode = "IND";
                                if (!string.IsNullOrEmpty(nationalityCode))
                                {
                                    var extractedValuesList = result.Values.Where(v => v.Value.Contains("<"));

                                    var matchingvalue = extractedValuesList.Where(x => x.Value.Contains(nationalityCode)).FirstOrDefault();

                                    if (!(string.IsNullOrEmpty(matchingvalue.Key)))
                                    {
                                        MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalue);
                                    }
                                }
                            }

                            if (matchedNode != null ? matchedNode.Text != "Nationality" : true)
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }

                        if (data.Key == "Gender")
                        {
                            var extractedValuesLst = result;
                            var matchingvalues = extractedValuesLst.Values.Where(x => x.Value.Contains(AppConstants.Gender) && x.Value.Contains(valueToCompare)).FirstOrDefault();
                            bool isMainNodeAdded = false;
                            if (!(string.IsNullOrEmpty(matchingvalues.Key)))
                            {
                                MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingvalues);
                            }

                            if (!isMainNodeAdded)
                            {
                                var matchingval = extractedValuesLst.Values.Where(x => x.Value.ToUpper().Equals(valueToCompare.ToUpper())).FirstOrDefault();
                                if (!(string.IsNullOrEmpty(matchingval.Key)))
                                {
                                    MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingval);
                                }
                            }

                            string expirydate = actualData.Where(x => x.Key.Equals("Expiry")).Select(x => x.Value).FirstOrDefault();
                            string genderString = !string.IsNullOrEmpty(expirydate) ? valueToCompare + Convert.ToDateTime(expirydate).ToString("yyMMdd") : string.Empty;

                            if (!isMainNodeAdded)
                            {
                                var matchingval = extractedValuesLst.Values.Where(x => x.Value.Replace(@" ", "").Contains("<") && x.Value.Contains(genderString)).FirstOrDefault();
                                if (!(string.IsNullOrEmpty(matchingval.Key)))
                                {
                                    MatchedEntry(nodeMatched, ref matchedNode, data.Key, ref isMainNodeAdded, matchingval);
                                }
                            }

                            if (matchedNode != null ? matchedNode.Text != "Gender" : true)
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }
                        if (data.Key == "Name")
                        {
                            var actualNameLst = data.Value.Split(' ').ToList();
                            var extractNamesLst = result.Values.Where(x => x.Value.Contains("<")).Select(x => x).ToList();
                            if (extractNamesLst.Count > 0)
                            {
                                List<KeyValuePair<string, string>> extractNameArraySplit = new List<KeyValuePair<string, string>>();
                                List<string> splittedNames = new List<string>();
                                foreach (var name in extractNamesLst)
                                {
                                    if (name.Value[0] == '<')
                                    {
                                        splittedNames = name.Value.Substring(1).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                    }
                                    else
                                    {
                                        if (name.Value.Length > 6 && cmbBxImageType.Text == "Passport")
                                            splittedNames = name.Value.Substring(5).Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();

                                        if (cmbBxImageType.Text == "EmiratesId")
                                            splittedNames = name.Value.Split(new[] { "<" }, StringSplitOptions.RemoveEmptyEntries).ToList();
                                    }
                                    foreach (var nameStr in splittedNames)
                                    {
                                        var keyValPair = new KeyValuePair<string, string>(name.Key, nameStr.Replace(" ", ""));
                                        extractNameArraySplit.Add(keyValPair);
                                    }
                                }
                                int counter = 0;
                                foreach (var nameValueToCompare in actualNameLst)
                                {
                                    var matchesNames = extractNameArraySplit.Where(v => v.Value.ToUpper().Contains(nameValueToCompare.ToUpper()));
                                    if (matchesNames.Any())
                                    {
                                        matchedNode = nodeMatched.Nodes.Add(string.Format("Name {0}:", counter.ToString()));
                                        var imageKeys = matchesNames.
                                                        GroupBy(o => new { o.Value })
                                                        .Select(o => o.FirstOrDefault());
                                        foreach (var imgKey in imageKeys)
                                        {
                                            matchedNode.Nodes.Add(imgKey.Key);
                                        }
                                    }
                                    else
                                    {
                                        notMatchedNode = nodeNotMatching.Nodes.Add(string.Format("Name {0}", counter.ToString()));
                                    }
                                    counter++;
                                }
                                continue;
                            }

                            if (matchedNode != null ? matchedNode.Text != "Name" : true)
                            {
                                notMatchedNode = nodeNotMatching.Nodes.Add(data.Key);
                            }
                        }
                    }
                    nodeNotMatching.Expand();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private static void MatchedEntryFirstValue(TreeNode nodeMatched, ref TreeNode matchedNode, string dataKey, ref bool isMainNodeAdded, IEnumerable<KeyValuePair<string, string>> matchingvalues)
        {
            if (!isMainNodeAdded)
                matchedNode = nodeMatched.Nodes.Add(dataKey);
            isMainNodeAdded = true;
            matchedNode.Nodes.Add(matchingvalues.FirstOrDefault().Key);
        }

        private static void MatchedEntry(TreeNode nodeMatched, ref TreeNode matchedNode, string dataKey, ref bool isMainNodeAdded, KeyValuePair<string, string> matchingvalues)
        {
            if (!isMainNodeAdded)
                matchedNode = nodeMatched.Nodes.Add(dataKey);
            isMainNodeAdded = true;
            matchedNode.Nodes.Add(matchingvalues.Key);
        }

        private void lnkOpenFolder_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(TempPath);
        }

        private void btnRefreshFolders_Click(object sender, EventArgs e)
        {
            fillLists();
        }

        private void lnkLblOpenPendingFolder_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(PendingFolder);

        }

        private void lstBxPending_DoubleClick(object sender, EventArgs e)
        {
            if (lstBxPending.SelectedItem != null)
            {
                openInStrategyBuilder(PendingFolder, lstBxPending.SelectedItem.ToString());
            }
        }

        private void openInStrategyBuilder(string folder, string fileName)
        {
            var fileNameFull = System.IO.Path.Combine(folder, fileName);
            if (System.IO.File.Exists(fileNameFull))
            {
                frmStrategyBuilder strategyBuilder = new frmStrategyBuilder();
                strategyBuilder.FileName = fileNameFull;

                strategyBuilder.Init();
                strategyBuilder.ShowDialog();
            }
        }
    }
}

