﻿namespace ADCB.DocumentParser.Consumer.WinForms
{
    partial class frmImgParser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbPagePendingFiles = new System.Windows.Forms.TabPage();
            this.lstBxPending = new System.Windows.Forms.ListBox();
            this.lnkLblOpenPendingFolder = new System.Windows.Forms.LinkLabel();
            this.tbPageFailed = new System.Windows.Forms.TabPage();
            this.lstBxFailed = new System.Windows.Forms.ListBox();
            this.tbPageSucceeded = new System.Windows.Forms.TabPage();
            this.lstBxSucceeded = new System.Windows.Forms.ListBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.picBx = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lnkOpenFolder = new System.Windows.Forms.LinkLabel();
            this.lnkOpen = new System.Windows.Forms.LinkLabel();
            this.cmbRotate = new System.Windows.Forms.ComboBox();
            this.btnRotateRight = new System.Windows.Forms.Button();
            this.lstBxData = new System.Windows.Forms.ListBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.trVwResult = new System.Windows.Forms.TreeView();
            this.lstBxStrategies = new System.Windows.Forms.ListBox();
            this.lstBxStrategyResult = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnRefreshFolders = new System.Windows.Forms.Button();
            this.cmbBxImageType = new System.Windows.Forms.ComboBox();
            this.btnGetNewImagesInSource = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tbPagePendingFiles.SuspendLayout();
            this.tbPageFailed.SuspendLayout();
            this.tbPageSucceeded.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBx)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 42);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1059, 571);
            this.splitContainer1.SplitterDistance = 353;
            this.splitContainer1.SplitterWidth = 2;
            this.splitContainer1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tbPagePendingFiles);
            this.tabControl1.Controls.Add(this.tbPageFailed);
            this.tabControl1.Controls.Add(this.tbPageSucceeded);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(353, 571);
            this.tabControl1.TabIndex = 0;
            // 
            // tbPagePendingFiles
            // 
            this.tbPagePendingFiles.Controls.Add(this.lstBxPending);
            this.tbPagePendingFiles.Controls.Add(this.lnkLblOpenPendingFolder);
            this.tbPagePendingFiles.Location = new System.Drawing.Point(23, 4);
            this.tbPagePendingFiles.Margin = new System.Windows.Forms.Padding(2);
            this.tbPagePendingFiles.Name = "tbPagePendingFiles";
            this.tbPagePendingFiles.Padding = new System.Windows.Forms.Padding(2);
            this.tbPagePendingFiles.Size = new System.Drawing.Size(326, 563);
            this.tbPagePendingFiles.TabIndex = 0;
            this.tbPagePendingFiles.Text = "Pending Files";
            this.tbPagePendingFiles.UseVisualStyleBackColor = true;
            // 
            // lstBxPending
            // 
            this.lstBxPending.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxPending.FormattingEnabled = true;
            this.lstBxPending.Location = new System.Drawing.Point(2, 2);
            this.lstBxPending.Margin = new System.Windows.Forms.Padding(2);
            this.lstBxPending.Name = "lstBxPending";
            this.lstBxPending.Size = new System.Drawing.Size(322, 546);
            this.lstBxPending.TabIndex = 0;
            this.lstBxPending.SelectedIndexChanged += new System.EventHandler(this.lstBxPending_SelectedIndexChanged);
            this.lstBxPending.DoubleClick += new System.EventHandler(this.lstBxPending_DoubleClick);
            // 
            // lnkLblOpenPendingFolder
            // 
            this.lnkLblOpenPendingFolder.AutoSize = true;
            this.lnkLblOpenPendingFolder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lnkLblOpenPendingFolder.Location = new System.Drawing.Point(2, 548);
            this.lnkLblOpenPendingFolder.Name = "lnkLblOpenPendingFolder";
            this.lnkLblOpenPendingFolder.Size = new System.Drawing.Size(107, 13);
            this.lnkLblOpenPendingFolder.TabIndex = 4;
            this.lnkLblOpenPendingFolder.TabStop = true;
            this.lnkLblOpenPendingFolder.Text = "Open Pending Folder";
            this.lnkLblOpenPendingFolder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkLblOpenPendingFolder_LinkClicked);
            // 
            // tbPageFailed
            // 
            this.tbPageFailed.Controls.Add(this.lstBxFailed);
            this.tbPageFailed.Location = new System.Drawing.Point(23, 4);
            this.tbPageFailed.Margin = new System.Windows.Forms.Padding(2);
            this.tbPageFailed.Name = "tbPageFailed";
            this.tbPageFailed.Padding = new System.Windows.Forms.Padding(2);
            this.tbPageFailed.Size = new System.Drawing.Size(326, 563);
            this.tbPageFailed.TabIndex = 1;
            this.tbPageFailed.Text = "Failed";
            this.tbPageFailed.UseVisualStyleBackColor = true;
            // 
            // lstBxFailed
            // 
            this.lstBxFailed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxFailed.FormattingEnabled = true;
            this.lstBxFailed.Location = new System.Drawing.Point(2, 2);
            this.lstBxFailed.Margin = new System.Windows.Forms.Padding(2);
            this.lstBxFailed.Name = "lstBxFailed";
            this.lstBxFailed.Size = new System.Drawing.Size(322, 559);
            this.lstBxFailed.TabIndex = 0;
            this.lstBxFailed.SelectedIndexChanged += new System.EventHandler(this.lstBxFailed_SelectedIndexChanged);
            // 
            // tbPageSucceeded
            // 
            this.tbPageSucceeded.Controls.Add(this.lstBxSucceeded);
            this.tbPageSucceeded.Location = new System.Drawing.Point(23, 4);
            this.tbPageSucceeded.Margin = new System.Windows.Forms.Padding(2);
            this.tbPageSucceeded.Name = "tbPageSucceeded";
            this.tbPageSucceeded.Padding = new System.Windows.Forms.Padding(2);
            this.tbPageSucceeded.Size = new System.Drawing.Size(326, 563);
            this.tbPageSucceeded.TabIndex = 2;
            this.tbPageSucceeded.Text = "Succeeded";
            this.tbPageSucceeded.UseVisualStyleBackColor = true;
            // 
            // lstBxSucceeded
            // 
            this.lstBxSucceeded.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxSucceeded.FormattingEnabled = true;
            this.lstBxSucceeded.Location = new System.Drawing.Point(2, 2);
            this.lstBxSucceeded.Margin = new System.Windows.Forms.Padding(2);
            this.lstBxSucceeded.Name = "lstBxSucceeded";
            this.lstBxSucceeded.Size = new System.Drawing.Size(322, 559);
            this.lstBxSucceeded.TabIndex = 0;
            this.lstBxSucceeded.SelectedIndexChanged += new System.EventHandler(this.lstBxSucceeded_SelectedIndexChanged);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(704, 571);
            this.splitContainer2.SplitterDistance = 476;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.picBx);
            this.splitContainer3.Panel1.Controls.Add(this.panel2);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.lstBxData);
            this.splitContainer3.Size = new System.Drawing.Size(476, 571);
            this.splitContainer3.SplitterDistance = 374;
            this.splitContainer3.TabIndex = 0;
            // 
            // picBx
            // 
            this.picBx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picBx.Location = new System.Drawing.Point(0, 0);
            this.picBx.Name = "picBx";
            this.picBx.Size = new System.Drawing.Size(476, 341);
            this.picBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picBx.TabIndex = 0;
            this.picBx.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lnkOpenFolder);
            this.panel2.Controls.Add(this.lnkOpen);
            this.panel2.Controls.Add(this.cmbRotate);
            this.panel2.Controls.Add(this.btnRotateRight);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 341);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(476, 33);
            this.panel2.TabIndex = 1;
            // 
            // lnkOpenFolder
            // 
            this.lnkOpenFolder.AutoSize = true;
            this.lnkOpenFolder.Location = new System.Drawing.Point(108, 14);
            this.lnkOpenFolder.Name = "lnkOpenFolder";
            this.lnkOpenFolder.Size = new System.Drawing.Size(65, 13);
            this.lnkOpenFolder.TabIndex = 3;
            this.lnkOpenFolder.TabStop = true;
            this.lnkOpenFolder.Text = "Open Folder";
            this.lnkOpenFolder.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkOpenFolder_LinkClicked);
            // 
            // lnkOpen
            // 
            this.lnkOpen.AutoSize = true;
            this.lnkOpen.Location = new System.Drawing.Point(10, 14);
            this.lnkOpen.Name = "lnkOpen";
            this.lnkOpen.Size = new System.Drawing.Size(65, 13);
            this.lnkOpen.TabIndex = 2;
            this.lnkOpen.TabStop = true;
            this.lnkOpen.Text = "Open Image";
            this.lnkOpen.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkOpen_LinkClicked);
            // 
            // cmbRotate
            // 
            this.cmbRotate.FormattingEnabled = true;
            this.cmbRotate.Location = new System.Drawing.Point(273, 6);
            this.cmbRotate.Name = "cmbRotate";
            this.cmbRotate.Size = new System.Drawing.Size(121, 21);
            this.cmbRotate.TabIndex = 1;
            // 
            // btnRotateRight
            // 
            this.btnRotateRight.Location = new System.Drawing.Point(400, 4);
            this.btnRotateRight.Name = "btnRotateRight";
            this.btnRotateRight.Size = new System.Drawing.Size(75, 23);
            this.btnRotateRight.TabIndex = 0;
            this.btnRotateRight.Text = "Rotate Right";
            this.btnRotateRight.UseVisualStyleBackColor = true;
            this.btnRotateRight.Click += new System.EventHandler(this.btnRotateRight_Click);
            // 
            // lstBxData
            // 
            this.lstBxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxData.FormattingEnabled = true;
            this.lstBxData.Location = new System.Drawing.Point(0, 0);
            this.lstBxData.Name = "lstBxData";
            this.lstBxData.Size = new System.Drawing.Size(476, 193);
            this.lstBxData.TabIndex = 0;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.trVwResult);
            this.splitContainer4.Panel1.Controls.Add(this.lstBxStrategies);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.lstBxStrategyResult);
            this.splitContainer4.Size = new System.Drawing.Size(224, 571);
            this.splitContainer4.SplitterDistance = 376;
            this.splitContainer4.TabIndex = 3;
            // 
            // trVwResult
            // 
            this.trVwResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trVwResult.Location = new System.Drawing.Point(0, 147);
            this.trVwResult.Name = "trVwResult";
            this.trVwResult.Size = new System.Drawing.Size(224, 229);
            this.trVwResult.TabIndex = 3;
            // 
            // lstBxStrategies
            // 
            this.lstBxStrategies.Dock = System.Windows.Forms.DockStyle.Top;
            this.lstBxStrategies.FormattingEnabled = true;
            this.lstBxStrategies.Location = new System.Drawing.Point(0, 0);
            this.lstBxStrategies.Name = "lstBxStrategies";
            this.lstBxStrategies.Size = new System.Drawing.Size(224, 147);
            this.lstBxStrategies.TabIndex = 2;
            this.lstBxStrategies.SelectedIndexChanged += new System.EventHandler(this.lstBxStrategies_SelectedIndexChanged);
            // 
            // lstBxStrategyResult
            // 
            this.lstBxStrategyResult.DisplayMember = "Value";
            this.lstBxStrategyResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstBxStrategyResult.FormattingEnabled = true;
            this.lstBxStrategyResult.Location = new System.Drawing.Point(0, 0);
            this.lstBxStrategyResult.Name = "lstBxStrategyResult";
            this.lstBxStrategyResult.Size = new System.Drawing.Size(224, 191);
            this.lstBxStrategyResult.TabIndex = 3;
            this.lstBxStrategyResult.ValueMember = "Value";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnRefreshFolders);
            this.panel1.Controls.Add(this.cmbBxImageType);
            this.panel1.Controls.Add(this.btnGetNewImagesInSource);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1059, 42);
            this.panel1.TabIndex = 1;
            // 
            // btnRefreshFolders
            // 
            this.btnRefreshFolders.Location = new System.Drawing.Point(517, 9);
            this.btnRefreshFolders.Margin = new System.Windows.Forms.Padding(2);
            this.btnRefreshFolders.Name = "btnRefreshFolders";
            this.btnRefreshFolders.Size = new System.Drawing.Size(145, 20);
            this.btnRefreshFolders.TabIndex = 6;
            this.btnRefreshFolders.Text = "Refresh Folders";
            this.btnRefreshFolders.UseVisualStyleBackColor = true;
            this.btnRefreshFolders.Click += new System.EventHandler(this.btnRefreshFolders_Click);
            // 
            // cmbBxImageType
            // 
            this.cmbBxImageType.FormattingEnabled = true;
            this.cmbBxImageType.Items.AddRange(new object[] {
            "Passport",
            "EmiratesId",
            "PAN"});
            this.cmbBxImageType.Location = new System.Drawing.Point(112, 10);
            this.cmbBxImageType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbBxImageType.Name = "cmbBxImageType";
            this.cmbBxImageType.Size = new System.Drawing.Size(244, 21);
            this.cmbBxImageType.TabIndex = 5;
            this.cmbBxImageType.SelectedIndexChanged += new System.EventHandler(this.CmbBxImageType_SelectedIndexChanged_1);
            // 
            // btnGetNewImagesInSource
            // 
            this.btnGetNewImagesInSource.Location = new System.Drawing.Point(368, 9);
            this.btnGetNewImagesInSource.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetNewImagesInSource.Name = "btnGetNewImagesInSource";
            this.btnGetNewImagesInSource.Size = new System.Drawing.Size(145, 20);
            this.btnGetNewImagesInSource.TabIndex = 1;
            this.btnGetNewImagesInSource.Text = "Get New Images in Source";
            this.btnGetNewImagesInSource.UseVisualStyleBackColor = true;
            this.btnGetNewImagesInSource.Click += new System.EventHandler(this.btnGetNewImagesInSource_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Image Type";
            // 
            // frmImgParser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 613);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmImgParser";
            this.Text = "Image Parser";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tbPagePendingFiles.ResumeLayout(false);
            this.tbPagePendingFiles.PerformLayout();
            this.tbPageFailed.ResumeLayout(false);
            this.tbPageSucceeded.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBx)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGetNewImagesInSource;
        private System.Windows.Forms.ComboBox cmbBxImageType;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.PictureBox picBx;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnRotateRight;
        private System.Windows.Forms.ComboBox cmbRotate;
        private System.Windows.Forms.LinkLabel lnkOpen;
        private System.Windows.Forms.ListBox lstBxData;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.ListBox lstBxStrategies;
        private System.Windows.Forms.ListBox lstBxStrategyResult;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbPagePendingFiles;
        private System.Windows.Forms.ListBox lstBxPending;
        private System.Windows.Forms.TabPage tbPageFailed;
        private System.Windows.Forms.ListBox lstBxFailed;
        private System.Windows.Forms.TabPage tbPageSucceeded;
        private System.Windows.Forms.ListBox lstBxSucceeded;
        private System.Windows.Forms.LinkLabel lnkOpenFolder;
        private System.Windows.Forms.Button btnRefreshFolders;
        private System.Windows.Forms.LinkLabel lnkLblOpenPendingFolder;
        private System.Windows.Forms.TreeView trVwResult;
    }
}

