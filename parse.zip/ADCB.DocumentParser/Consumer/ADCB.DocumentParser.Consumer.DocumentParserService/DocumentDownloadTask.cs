﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class DocumentDownloadTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;
        public DocumentDownloadTask() : base(5000) //In milliseconds
        {
            serviceName = "DocumentDownloadTask";
            SetScheduledTime(AppConstants.DocumentDownloadScheduledTime);
            SetMode(AppConstants.DocumentDownloadMode);
            SetIntervalMinutes(AppConstants.DocumentDownloadIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("DocumentDownloadTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.DownloadProcessCustomersDocument());
                LoggingHelper.LogDebug("DocumentDownloadTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("DocumentDownloadTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("DocumentDownloadTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("DocumentDownloadTask timer reset.");
            base.ResetTimer();
        }
    }
}
