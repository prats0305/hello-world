﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Exceptions;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    internal abstract class TaskBase
    {
        protected DateTime nextScheduledTime = DateTime.MinValue;
        protected Int32 intervalMinutes = 0;
        protected String mode = null;
        protected int TimeRefreshSec { get; private set; }
        protected int TimePassed { get; private set; }
        protected decimal? batchId { get; set; }
        private readonly Timer _timer;
        private bool _isValid = false;
        protected string serviceName = String.Empty;
        static readonly object LockObject = new object();        
        protected DocumentParserFacade _engine;

       
        protected TaskBase(double refreshInterval)
        {
            TimeRefreshSec = (int)refreshInterval / 1000;
            TimePassed = 0;

            _timer = new Timer(refreshInterval) { AutoReset = true };
            _timer.Elapsed += Tick;
        }

        private void Tick(object sender, ElapsedEventArgs e)
        {
            TimePassed += TimeRefreshSec;
            Tick();
        }

        public void Start()
        {
            ResetTimer();

            // Run the task once when starting instead of waiting for a full interval.
            Tick();

            OnStart();
        }

        public void Stop()
        {
            if (_timer.Enabled)
            {
                _timer.Stop();
                OnStop();
            }
        }

        protected void SetScheduledTime(String key)
        {
            //Get the Scheduled Time from AppSettings.
            nextScheduledTime = DateTime.Parse(AppConfigHelper.GetValue(key));
        }

        protected void SetMode(String key)
        {
            //Get the mode from Appsettings.
            mode = AppConfigHelper.GetValue(key).ToUpper();
        }

        protected void SetIntervalMinutes(String key)
        {
            //Get the mode from Appsettings.
            intervalMinutes = Convert.ToInt32(AppConfigHelper.GetValue(key));
        }

        protected virtual void ResetTimer()
        {
            TimePassed = 0;
            if (_timer.Enabled) _timer.Stop();
            _timer.Start();
        }

        /// <summary>
        /// Implement here a specific behavior when task is stopped.
        /// </summary>
        protected abstract void OnStop();

        /// <summary>
        /// Implement here a specific behavior when task is started.
        /// </summary>
        protected abstract void OnStart();

        /// <summary>
        /// This method is executed each time the task's timer has reached the interval specified in the constructor.
        /// Time counters are automatically updated.
        /// </summary>
        protected abstract void Tick();

        /// <summary>
        /// This methods take func and execute the logic present inside.
        /// </summary>
        /// <param name="actionToExecute"></param>
        public void Execute(Action actionToExecute, String methodName = "")
        {
            try
            {
                if (DateTime.Now > nextScheduledTime)
                {
                    //Log start time.
                    DateTime startTime = DateTime.Now;

                    if (mode.Equals(AppConstants.Daily))//Daily
                    {
                        //Set Schedule for the next day.
                        nextScheduledTime = nextScheduledTime.AddDays(1);
                        _isValid = true;
                    }
                    else if (mode.Equals(AppConstants.Interval))//Interval
                    {
                        //Set the Scheduled Time by adding the Interval to Current Time.
                        nextScheduledTime = DateTime.Now.AddMinutes(intervalMinutes);
                        _isValid = true;
                    }
                    else if (mode.Equals(AppConstants.Weekly))//Weekly
                    {
                        //Set Schedule for the next week.
                        nextScheduledTime = DateTime.Now.AddDays(7);
                        _isValid = true;
                    }
                    else if (mode.Equals(AppConstants.SpecificDayOfWeek) && DateTime.Now.DayOfWeek == DayOfWeek.Friday)//Specific Day of Week.
                    {
                        //Set Schedule for the next week specific day.
                        nextScheduledTime = DateTime.Now.AddDays(7);
                        _isValid = true;
                    }

                    //lock object till the time process does not happend. 
                    lock (LockObject)
                    {
                        if (_isValid)
                        {
                            //Reset isValid to gain initial state so that for next day again it will pick it up.
                            _isValid = false;

                            LoggingHelper.LogInformation("Execute method called for Task - " + serviceName);

                            actionToExecute();
                            LogEndStartAndEndTime(methodName, startTime);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingHelper.LogError(DocumentParserExceptionHandler.GetErrorMessage(ex));
            }
            finally
            {

            }
        }

        private static void LogEndStartAndEndTime(String methodName, DateTime startTime)
        {
            //Log end time.
            TimeSpan difference = (DateTime.Now - startTime);
            LoggingHelper.LogInformation(String.Format("Method : {0} || Start Time : {1} || End Time : {2} || Difference : {3}", methodName, startTime, DateTime.Now, difference));
        }
    }
}
