﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class LowPrioritySaveDocumentAttributeTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;
        public LowPrioritySaveDocumentAttributeTask() : base(5000) //In milliseconds
        {
            serviceName = "LowPrioritySaveDocumentAttributeTask";
            SetScheduledTime(AppConstants.LowPrioritySaveDocumentAttributeScheduledTime);
            SetMode(AppConstants.LowPrioritySaveDocumentAttributeMode);
            SetIntervalMinutes(AppConstants.LowPrioritySaveDocumentAttributeIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("LowPrioritySaveDocumentAttributeTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.SaveDocumentAttributeTask(true));
                LoggingHelper.LogDebug("LowPrioritySaveDocumentAttributeTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("LowPrioritySaveDocumentAttributeTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("LowPrioritySaveDocumentAttributeTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("LowPrioritySaveDocumentAttributeTask timer reset.");
            base.ResetTimer();
        }
    }
}
