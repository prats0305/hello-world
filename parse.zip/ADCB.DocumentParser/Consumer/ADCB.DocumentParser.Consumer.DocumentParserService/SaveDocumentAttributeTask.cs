﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class SaveDocumentAttributeTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;

        public SaveDocumentAttributeTask() : base(5000) //In milliseconds
        {
            serviceName = "SaveDocumentAttributeTask";
            SetScheduledTime(AppConstants.SaveDocumentAttributeScheduledTime);
            SetMode(AppConstants.SaveDocumentAttributeMode);
            SetIntervalMinutes(AppConstants.SaveDocumentAttributeIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);
            
            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("SaveDocumentAttributeTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.SaveDocumentAttributeTask());
                LoggingHelper.LogDebug("SaveDocumentAttributeTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("SaveDocumentAttributeTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("SaveDocumentAttributeTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("SaveDocumentAttributeTask timer reset.");
            base.ResetTimer();
        }
    }
}
