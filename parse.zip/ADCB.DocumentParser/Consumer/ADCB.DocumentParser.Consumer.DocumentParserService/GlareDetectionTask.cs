﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class GlareDetectionTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;
        public GlareDetectionTask() : base(5000) //In milliseconds
        {
            serviceName = "GlareDetectionTask";
            SetScheduledTime(AppConstants.GlareDetectionScheduledTime);
            SetMode(AppConstants.GlareDetectionMode);
            SetIntervalMinutes(AppConstants.GlareDetectionIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("GlareDetectionTask Started.");
                
                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.GlareDetectionForPendingCustomers());
                LoggingHelper.LogDebug("GlareDetectionTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("GlareDetectionTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("GlareDetectionTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("GlareDetectionTask timer reset.");
            base.ResetTimer();
        }
    }
}
