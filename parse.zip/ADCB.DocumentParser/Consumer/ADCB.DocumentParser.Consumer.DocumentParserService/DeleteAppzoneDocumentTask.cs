﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Helper;
using ADCB.DocumentParser.DocumentParserService;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class DeleteAppzoneDocumentTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;

        public DeleteAppzoneDocumentTask() : base(5000) //In milliseconds
        {
            serviceName = "DeleteAppzoneDocumentTask";
            SetScheduledTime(AppConstants.DeleteAppzoneDocumentScheduledTime);
            SetMode(AppConstants.DeleteAppzoneDocumentMode);
            SetIntervalMinutes(AppConstants.DeleteAppzoneDocumentIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("DeleteAppzoneDocumentTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.DeleteAppzoneDocumentTask());
                LoggingHelper.LogDebug("DeleteAppzoneDocumentTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("DeleteAppzoneDocumentTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("DeleteAppzoneDocumentTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("DeleteAppzoneDocumentTask timer reset.");
            base.ResetTimer();
        }
    }
}
