﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class EIDAParserTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;
        public EIDAParserTask() : base(5000) //In milliseconds
        {
            serviceName = "EIDAParserTask";
            SetScheduledTime(AppConstants.EIDAParserScheduledTime);
            SetMode(AppConstants.EIDAParserMode);
            SetIntervalMinutes(AppConstants.EIDAParserIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("EIDAParserTask Tick.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.ParseGlarePassedImages(DocumentTypeEnum.EIDA));
                LoggingHelper.LogDebug("EIDAParserTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("EIDAParserTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("EIDAParserTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("EIDAParserTask timer reset.");
            base.ResetTimer();
        }
    }
}
