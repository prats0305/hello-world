﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace ADCB.DocumentParser.DocumentParserService
{
    public partial class DocumentParserService : ServiceBase
    {
        private readonly List<TaskBase> _tasks;
        public DocumentParserService()
        {
            InitializeComponent();

            // Add in this list the tasks to run periodically.
            // Tasks frequencies are set in the corresponding classes.
            _tasks = new List<TaskBase>
            {
                new HayyakDocumentReceiverTask(),
                new NameSplittingDocumentReceiverTask(),
                new DocumentDownloadTask(),
                new GlareDetectionTask(),
                new PassportParserTask(),
                new EIDAParserTask(),
                new LowPriorityPassportParserTask(),
                new LowPriorityEIDAParserTask(),
                new SaveDocumentAttributeTask(),
                new LowPrioritySaveDocumentAttributeTask(),
                new DeleteAppzoneDocumentTask()
            };
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                _tasks.ForEach(t => t.Start());
            }
            catch (Exception)
            {
                Stop();
            }
        }

        protected override void OnStop()
        {
            _tasks.ForEach(t => t.Stop());
        }

        public void Start()
        {
            _tasks.ForEach(t => t.Start());
        }
    }
}
