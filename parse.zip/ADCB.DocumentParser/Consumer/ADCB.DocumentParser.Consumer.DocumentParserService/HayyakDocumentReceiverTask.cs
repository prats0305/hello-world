﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class HayyakDocumentReceiverTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;
        public HayyakDocumentReceiverTask() : base(5000) //In milliseconds
        {
            serviceName = "HayyakDocumentReceiverTask";
            SetScheduledTime(AppConstants.HayyakDocumentReceiverScheduledTime);
            SetMode(AppConstants.HayyakDocumentReceiverMode);
            SetIntervalMinutes(AppConstants.HayyakDocumentReceiverIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("HayyakDocumentReceiverTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.ReceiveAndProcessCustomers(ProcessTypeEnum.Hayaak));
                LoggingHelper.LogDebug("HayyakDocumentReceiverTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("HayyakDocumentReceiverTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("HayyakDocumentReceiverTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("HayyakDocumentReceiverTask timer reset.");
            base.ResetTimer();
        }
    }
}
