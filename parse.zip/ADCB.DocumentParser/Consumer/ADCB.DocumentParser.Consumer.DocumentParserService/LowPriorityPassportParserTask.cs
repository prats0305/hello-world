﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ADCB.DocumentParser.API.Facade;
using ADCB.DocumentParser.Common.Constants;
using ADCB.DocumentParser.Common.Enums;
using ADCB.DocumentParser.Common.Helper;
using Microsoft.Practices.Unity;

namespace ADCB.DocumentParser.DocumentParserService
{
    class LowPriorityPassportParserTask : TaskBase
    {
        Object objForLocking = new Object();
        bool isLockObtained;

        public LowPriorityPassportParserTask() : base(5000) //In milliseconds
        {
            serviceName = "LowPriorityPassportParserTask";
            SetScheduledTime(AppConstants.LowPriorityPassportParserScheduledTime);
            SetMode(AppConstants.LowPriorityPassportParserMode);
            SetIntervalMinutes(AppConstants.LowPriorityPassportParserIntervalMinutes);
        }

        protected override void Tick()
        {
            isLockObtained = false;
            System.Threading.Monitor.TryEnter(objForLocking, ref isLockObtained);

            if (!isLockObtained)
            {
                LoggingHelper.LogDebug("LowPriorityPassportParserTask Started.");

                UnityContainer _container = new UnityContainer();
                _engine = new DocumentParserFacade(_container);

                Execute(() => _engine.ParseGlarePassedImages(DocumentTypeEnum.Passport, true));
                LoggingHelper.LogDebug("LowPriorityPassportParserTask Ended.");
                if (isLockObtained)
                {
                    System.Threading.Monitor.Exit(objForLocking);
                }
            }
        }

        protected override void OnStart()
        {
            LoggingHelper.LogDebug("LowPriorityPassportParserTask started.");
        }

        protected override void OnStop()
        {
            LoggingHelper.LogDebug("LowPriorityPassportParserTask stopped.");
        }

        protected override void ResetTimer()
        {
            LoggingHelper.LogDebug("LowPriorityPassportParserTask timer reset.");
            base.ResetTimer();
        }
    }
}
